
import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster"
import { PT_Sans } from 'next/font/google'
import { cn } from '@/lib/utils';
import { getGlobalSettings } from './super-admin/settings/actions';

export async function generateMetadata(): Promise<Metadata> {
  const globalSettings = await getGlobalSettings();
  const appName = globalSettings.general?.appName || 'QueuePilot';
  const faviconUrl = globalSettings.general?.appFaviconUrl || '/favicon.ico';
 
  return {
    title: {
      default: appName,
      template: `%s | ${appName}`,
    },
    description: 'Smart Queue Management and Booking',
    icons: {
      icon: [faviconUrl],
    }
  }
}

const ptSans = PT_Sans({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-body'
})

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={cn(ptSans.variable)} suppressHydrationWarning>
      <body className="font-body antialiased">
        {children}
        <Toaster />
      </body>
    </html>
  );
}


'use client';

import * as React from 'react';
import { Share2, Users, Building, HardHat, UserCheck, Calendar, Settings, Shield, Clock, Search, Link as LinkIcon, Edit, MessageSquare, List, BarChart, Bot, Tablet, Cpu, Brush, Database, Cloud, GitMerge, History, FileClock, Palette, Megaphone, ArrowRight, Workflow, Globe, ZoomIn, ZoomOut, RefreshCw, Smartphone, Server, ShoppingCart, Mail, BadgeCheck, FileQuestion } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { InteractiveCanvas, useInteractiveCanvas } from '@/components/ui/interactive-canvas';
import { ScrollArea } from '@/components/ui/scroll-area';

function ArchCard({ icon, title, description, className, code }: { icon: React.ReactNode, title: string, description: string, className?: string, code?: string }) {
    return (
        <div className={cn("relative p-4 bg-white border border-slate-200 rounded-lg shadow-sm text-center w-48", className)}>
            {code && <div className="absolute top-2 left-2 text-xs font-mono bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-md">{code}</div>}
            <div className="flex justify-center mb-2 pt-4">{icon}</div>
            <h3 className="font-bold text-slate-900">{title}</h3>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
    );
}

function ArchArrow({ from, to, label }: { from: string, to: string, label: string }) {
    // This is a placeholder for a more complex arrow drawing logic if needed.
    // For now, it shows a simple line between elements in a flex layout.
    return (
         <div className="flex flex-col items-center justify-center text-center mx-4">
            <p className="text-xs text-slate-500 mb-1">{label}</p>
            <ArrowRight className="h-8 w-8 text-slate-400" />
        </div>
    )
}

function ArchitectureDiagram() {
    const { setScale, setPosition } = useInteractiveCanvas();
    return (
        <>
            <div className="absolute top-4 right-4 z-10 flex gap-1">
                <Button size="icon" variant="outline" className="bg-white/80 backdrop-blur-sm" onClick={() => setScale(s => s * 1.2)}><ZoomIn className="h-4 w-4"/></Button>
                <Button size="icon" variant="outline" className="bg-white/80 backdrop-blur-sm" onClick={() => setScale(s => s / 1.2)}><ZoomOut className="h-4 w-4"/></Button>
                <Button size="icon" variant="outline" className="bg-white/80 backdrop-blur-sm" onClick={() => { setScale(1); setPosition({x: 0, y: 0}); }}><RefreshCw className="h-4 w-4"/></Button>
            </div>
             <div className="flex items-center justify-center min-w-max p-8">
                {/* Column 1: Actors */}
                <div className="flex flex-col gap-12 justify-around h-full">
                   <ArchCard code="A1" icon={<HardHat className="h-8 w-8 text-amber-700"/>} title="Super Admin" description="Manages the entire platform" />
                   <ArchCard code="A2" icon={<Users className="h-8 w-8 text-amber-700"/>} title="Business Staff" description="Manages daily operations" />
                   <ArchCard code="A3" icon={<UserCheck className="h-8 w-8 text-amber-700"/>} title="Customer" description="Books services & manages appointments" />
                </div>

                <ArchArrow from="actors" to="interfaces" label="interacts via" />

                {/* Column 2: Interfaces */}
                 <div className="flex flex-col gap-12 justify-around h-full">
                   <ArchCard code="I1" icon={<Building className="h-8 w-8 text-sky-700"/>} title="Admin Panel" description="`/super-admin`" />
                   <ArchCard code="I2" icon={<Tablet className="h-8 w-8 text-sky-700"/>} title="Staff Kiosk" description="`/[id]/staff-screen`" />
                   <ArchCard code="I3" icon={<Globe className="h-8 w-8 text-sky-700"/>} title="Booking Page" description="`/[id]`" />
                </div>
                
                 <ArchArrow from="interfaces" to="core" label="uses" />

               {/* Column 3: Core System */}
                <div className="p-4 bg-slate-100 border border-slate-200 rounded-lg h-full flex flex-col justify-center">
                    <div className="space-y-4">
                       <ArchCard code="C1" icon={<Workflow className="h-8 w-8 text-purple-700"/>} title="Core Application Logic" description="Server Actions, Route Handlers" className="w-full"/>
                       <div className="grid grid-cols-2 gap-4">
                          <ArchCard code="C2" icon={<Database className="h-8 w-8 text-rose-700"/>} title="Data Store" description="Firebase RTDB" />
                          <ArchCard code="C3" icon={<MessageSquare className="h-8 w-8 text-lime-700"/>} title="SMS Service" description="Vonage/Textbee" />
                          <ArchCard code="C4" icon={<Bot className="h-8 w-8 text-teal-700"/>} title="AI Service" description="Genkit" />
                          <ArchCard code="C5" icon={<Cloud className="h-8 w-8 text-indigo-700"/>} title="Hosting" description="Firebase Hosting" />
                       </div>
                    </div>
                </div>
            </div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-wrap gap-4 justify-center text-xs p-2 bg-white/80 rounded-md backdrop-blur-sm border shadow-sm z-10">
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-amber-100 border border-amber-300"></div> Actor</div>
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-sky-100 border border-sky-300"></div> Interface</div>
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-purple-100 border border-purple-300"></div> Core Logic</div>
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-rose-100 border border-rose-300"></div> Data Store</div>
                <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-lime-100 border border-lime-300"></div> External Service</div>
                <div className="flex items-center gap-2"><ArrowRight className="h-3 w-3 text-slate-400" /> Interaction</div>
            </div>
        </>
    )
}

function FlowStepCard({ icon, title, description, code, className, disabled = false }: { icon: React.ReactNode, title: string, description: string, code?: string, className?: string, disabled?: boolean }) {
    return (
        <div className={cn("relative p-4 bg-white border border-slate-200 rounded-lg shadow-sm text-left w-64 transition-opacity", className, disabled && 'opacity-40 grayscale')}>
            <div className="flex items-start gap-4">
                <div className="p-2 bg-slate-100 rounded-lg">{icon}</div>
                <div>
                    <h3 className="font-bold text-slate-800">{title}</h3>
                    <p className="text-xs text-muted-foreground">{description}</p>
                    {code && <p className="text-xs font-mono text-indigo-600 mt-1">{code}</p>}
                </div>
            </div>
        </div>
    );
}

function BookingFlowDiagram() {
     return (
        <div className="flex flex-col items-center p-8 min-w-max">
            <div className="flex items-center">
                 <FlowStepCard
                    icon={<ShoppingCart className="h-6 w-6 text-sky-700" />}
                    title="1. Select Service"
                    description="Customer browses services on Booking Page (I3) and selects one, with optional add-ons."
                    code="<BookingFlow />"
                />
                 <ArchArrow from="1" to="2" label="triggers" />
                <FlowStepCard
                    icon={<FileQuestion className="h-6 w-6 text-purple-700" />}
                    title="2. Check Next Available"
                    description="System immediately finds the next available day to pre-select in the calendar."
                    code="findNextAvailableDay()"
                />
                 <ArchArrow from="2" to="3" label="pre-selects" />
                 <FlowStepCard
                    icon={<Calendar className="h-6 w-6 text-sky-700" />}
                    title="3. Date & Time Selection"
                    description="Customer selects an available date and time. Available slots are calculated in real-time."
                    code="availableSlots (useMemo)"
                />
                 <ArchArrow from="3" to="4" label="on confirm" />
                <FlowStepCard
                    icon={<Users className="h-6 w-6 text-sky-700" />}
                    title="4. Staff Selection (If needed)"
                    description="If multiple staff are available, the customer is prompted to choose one. Otherwise, this step is skipped."
                />
            </div>
            
            <div className="flex w-full justify-center my-4">
                <div className="w-px h-8 bg-slate-300"></div>
            </div>

             <div className="flex w-full items-start justify-center">
                <div className="flex flex-col items-center">
                    <div className="text-sm font-semibold mb-2">New/Logged-Out User</div>
                    <div className="w-px h-4 bg-slate-300"></div>
                     <FlowStepCard
                        icon={<FileQuestion className="h-6 w-6 text-sky-700" />}
                        title="5a. Enter Details"
                        description="New customer provides their name and phone number."
                        code="Step: 'details'"
                    />
                     <ArchArrow from="5a" to="6a" label="then" />
                    <FlowStepCard
                        icon={<Mail className="h-6 w-6 text-lime-700" />}
                        title="6a. Verify SMS"
                        description="A verification code is sent via SMS Service (C3) to confirm the phone number."
                        code="sendVerificationSms()"
                    />
                     <div className="w-px h-4 bg-slate-300 mt-4"></div>
                </div>

                <div className="flex flex-col items-center mx-16">
                     <div className="text-sm font-semibold mb-2">Logged-In User</div>
                    <div className="w-px h-4 bg-slate-300"></div>
                     <FlowStepCard
                        icon={<BadgeCheck className="h-6 w-6 text-sky-700" />}
                        title="5b. Skip Details"
                        description="The system already has the customer's details, so this step is skipped entirely."
                        disabled
                    />
                    <div className="w-px h-4 bg-slate-300 mt-4"></div>
                </div>
            </div>
            
            <div className="w-full border-t border-slate-300 relative my-4">
                <div className="absolute left-1/2 -translate-x-1/2 -top-3 bg-slate-50 px-2 text-xs">merge</div>
            </div>

            <FlowStepCard
                icon={<Server className="h-6 w-6 text-purple-700" />}
                title="7. Confirm & Create"
                description="The final confirmation step. The createBooking server action validates all data and creates the booking."
                code="createBooking(data)"
            />
            <ArchArrow from="7" to="8" label="writes to" />
            <FlowStepCard
                icon={<Database className="h-6 w-6 text-rose-700" />}
                title="8. Save to Schedule"
                description="The new booking is written to the unified `schedules/[businessId]/[staffId]` path in the Data Store (C2)."
            />
        </div>
    );
}



export default function BlueprintPage() {
    const [historyModalOpen, setHistoryModalOpen] = React.useState(false);
    const [selectedFeatureHistory, setSelectedFeatureHistory] = React.useState<any>(null);
    const [searchTerm, setSearchTerm] = React.useState('');
    const [activeTab, setActiveTab] = React.useState('architecture');

    const handleViewHistory = (feature: any) => {
        setSelectedFeatureHistory(feature);
        setHistoryModalOpen(true);
    }

    const features = [
        {
            code: 'F1',
            name: 'Super admin business management',
            description: 'Centralised control for creating, viewing, and managing all business accounts on the platform, ensuring system integrity and oversight.',
            anchor: "Anchored in the I1 Admin Panel, this feature interacts directly with the C2 Data Store to manage business entities.",
            user_story: 'As a super admin, I want to manage all business accounts so that I can maintain platform-wide order and provide support.',
            contract: 'Enabling this feature provides the foundational capability to manage multiple business entities. It modifies the data schema to include a top-level `businesses` node and creates the UI for CRUD operations. Subsequent features like staff and service management will depend on this.',
            status: 'Developed',
            version: '1.0.0',
            history: [
                { version: '1.0.0', date: '2025-07-27', description: 'Initial implementation of CRUD operations for business entities.' },
            ],
            sub_features: [
                {
                    code: 'F1.1',
                    name: 'Create new business accounts',
                    description: 'A dedicated interface to add new businesses to the platform with foundational details, generating a unique system ID for each.',
                    anchor: "Implemented in `/super-admin/businesses/new`, this feature writes a new entry to the `businesses/` node in Firebase (C2).",
                    user_story: 'As a super admin, I want to create new business profiles so that I can onboard new clients efficiently.',
                    contract: 'This adds a form and a corresponding server action. Submitting the form will create a new business record in Firebase with a default data structure. The user will be redirected to the new business\'s edit page upon successful creation.',
                    status: 'Developed',
                    version: '1.0.0',
                    history: [{ version: '1.0.0', date: '2025-07-27', description: 'Form and server action for creating a new business with a default schema established.' }],
                },
                {
                    code: 'F1.2',
                    name: 'View and filter all businesses',
                    description: 'A comprehensive list of all businesses, with tools to search and sort, providing a clear overview of platform activity.',
                    anchor: "The `/super-admin/businesses` page (part of I1) fetches and displays all business entries, with client-side filtering for responsiveness.",
                    user_story: 'As a super admin, I want to view all businesses so that I can monitor the platform\'s growth and status.',
                    contract: 'This feature implements a data table component that fetches and displays all records from the `businesses` node in Firebase. It includes client-side logic for searching and sorting the displayed data without requiring additional server calls.',
                    status: 'Developed',
                    version: '1.0.0',
                    history: [{ version: '1.0.0', date: '2025-07-27', description: 'Data table implemented to list all businesses from Firebase.' }],
                },
                {
                    code: 'F1.3',
                    name: 'Edit business details',
                    description: 'The ability to modify any aspect of a business’s profile, from contact information to feature toggles, ensuring data accuracy.',
                    anchor: "Located at `/super-admin/businesses/[id]/edit` (part of I1), this form updates the specific business entry in Firebase (C2).",
                    user_story: 'As a super admin, I want to edit business details so that I can correct information or adjust settings on behalf of clients.',
                    contract: 'This creates a multi-tabbed form structure for editing various aspects of a business. Each tab\'s form submission triggers a server action that updates the specific business record in Firebase with the new data. This includes handling file uploads for logos or images.',
                    status: 'Developed',
                    version: '1.0.0',
                    history: [{ version: '1.0.0', date: '2025-07-27', description: 'Multi-tabbed edit form created with server actions for updating business data.' }],
                },
                {
                    code: 'F1.4',
                    name: 'Delete business accounts',
                    description: 'A secure function to permanently remove a business and its associated data, including services and staff, from the system.',
                    anchor: "The `deleteBusiness` server action (C1) removes the business entry from Firebase (C2) and associated data from Storage.",
                    user_story: 'As a super admin, I want to delete businesses so that I can manage the platform\'s client roster and remove obsolete accounts.',
                    contract: 'This feature adds a delete button with a confirmation dialog. Upon confirmation, a server action is called that will remove the business record from the Firebase Realtime Database and attempt to delete any associated files (like logos) from Firebase Storage.',
                    status: 'Developed',
                    version: '1.0.0',
                    history: [{ version: '1.0.0', date: '2025-07-27', description: 'Deletion action implemented with a confirmation dialog.' }],
                }
            ]
        },
        {
            code: 'F2',
            name: 'Business-level staff management',
            description: 'Enables business admins to define their team, manage schedules, and assign roles, directly influencing service availability.',
            anchor: "Centered around the `/super-admin/businesses/[id]/staff` route (I1), this feature manages data within the `businesses/[id]/staff/` path and the `schedules/[businessId]/[staffId]` path in C2.",
            user_story: 'As an admin, I want to manage my staff so that their schedules and service assignments are always up-to-date.',
            contract: 'This feature introduces a `staff` node within each business record in the database. It provides a UI for adding, editing, and deleting staff members. A staff member\'s profile will include their schedule, which is critical for the booking system\'s availability calculations.',
            status: 'Developed',
            version: '1.1.0',
            history: [{ version: '1.1.0', date: '2025-07-28', description: 'Staff management module created, allowing for creation, editing, and deletion of staff members.' }],
            sub_features: [
                {
                    code: 'F2.1',
                    name: 'Add and edit staff profiles',
                    description: 'Create and update profiles for each staff member, including their name and contact information.',
                    anchor: "The `StaffSettingsForm` component (I1) handles create/update operations, modifying individual staff records in C2.",
                    user_story: 'As an admin, I want to add staff profiles so that they are available for assignment to services and bookings.',
                    contract: 'Implements a form for staff details. On submission, the data is saved to the corresponding staff member record in the Firebase database under the business\'s `staff` node.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Initial form implementation for staff personal details.' }],
                },
                {
                    code: 'F2.2',
                    name: 'Define staff availability',
                    description: 'Set weekly working hours and breaks for each staff member, which automatically blocks off non-working times in the calendar.',
                    anchor: "Availability is set in the Staff form (I1). This triggers `updateScheduleFromAvailability` (C1) to populate the unified `schedules` path in C2 with `timeOff` and `break` events. The Booking Page (I3) then reads from this single source of truth.",
                    user_story: 'As an admin, I want to set working hours so that the booking system only shows slots when staff are actually working.',
                    contract: 'Adds a section to the staff management form for a 7-day schedule. Saving this form now pre-calculates and writes all non-working days and break times as explicit `timeOff` and `break` events into the main `schedules` node in Firebase for the next 90 days. This makes the `schedules` node the single source of truth for availability.',
                    status: 'Developed',
                    version: '1.3.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Added weekly availability and break management to the staff settings form.' }, { version: '1.3.0', date: '2025-07-30', description: 'Refactored to write availability as events to the main schedule.' }],
                },
                {
                    code: 'F2.3',
                    name: 'Assign services to staff',
                    description: 'Specify which services each staff member is qualified to perform, ensuring customers can only book with the right specialist.',
                    anchor: "Managed in `StaffSettingsForm` (I1), this populates the `assignedServices` array in a staff record in C2.",
                    user_story: 'As an admin, I want to assign services to staff so that bookings are always technically correct.',
                    contract: 'Implements a multi-select feature in the staff form to link staff members to specific services. The booking system will use this information to filter which staff members are available for a selected service.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Service assignment logic and UI added.' }],
                }
            ]
        },
        {
            code: 'F3',
            name: 'Service and add-on management',
            description: 'A flexible system for defining the services a business offers, organised into categories and customisable with optional add-ons.',
            anchor: "Managed in `/super-admin/businesses/[id]/services` (I1), this feature structures data under `businesses/[id]/serviceCategories` and `serviceExtensions` in C2.",
            user_story: 'As an admin, I want to define my service menu so that customers know what I offer and can book accordingly.',
            contract: 'This feature creates new data nodes in Firebase: `serviceCategories` and `serviceExtensions`. It provides the UI for admins to manage their complete service offerings, which are then displayed on the public booking page.',
            status: 'Developed',
            version: '1.1.0',
            history: [{ version: '1.1.0', date: '2025-07-28', description: 'Services, categories, and extensions CRUD implemented.' }],
            sub_features: [
                {
                    code: 'F3.1',
                    name: 'Organise services into categories',
                    description: 'Group services into logical categories (e.g., "Haircuts," "Coloring") to make them easier for customers to browse.',
                    anchor: "The `CategoryFormDialog` (I1) allows creation of categories, stored as parent nodes for services in C2.",
                    user_story: 'As an admin, I want to create service categories so that my booking page is neat and easy to navigate.',
                    contract: 'Implements a UI for creating, editing, and deleting categories. Services will be nested under these categories in the database, affecting how they are retrieved and displayed on the booking page.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Initial implementation of category management.' }],
                },
                {
                    code: 'F3.2',
                    name: 'Define service details',
                    description: 'For each service, specify its name, duration, price, and an optional short description.',
                    anchor: "The `ServiceFormDialog` (I1) captures these details, which are stored as individual service records in the C2 database.",
                    user_story: 'As an admin, I want to set the price and duration for each service so that booking and billing are accurate.',
                    contract: 'Provides a form to manage the core attributes of a service. The `duration` property is a critical input for the slot availability calculation.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Service form dialog created for managing service details.' }],
                },
                {
                    code: 'F3.3',
                    name: 'Create service extensions (add-ons)',
                    description: 'Define optional add-on services that customers can add to their main booking, which adjusts the total time and price.',
                    anchor: "Handled by `ExtensionFormDialog` (I1), these are stored globally for the business in C2 and linked in the service record.",
                    user_story: 'As an admin, I want to offer optional add-ons so that I can upsell and provide more customized services.',
                    contract: 'This adds a separate management area for extensions. When a customer selects an extension during booking, its duration and price are added to the main service, affecting the total booking time and cost.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Extension management dialog and logic implemented.' }],
                }
            ]
        },
        {
            code: 'F4',
            name: 'Booking policy configuration',
            description: 'Allows admins to set rules for how bookings are made, limited, and modified, ensuring compliance and managing calendar flow.',
            anchor: "Policies are configured in `/super-admin/businesses/[id]/edit/booking-page` (I1) and enforced by server actions and client-side logic in `booking-flow.tsx` (C1, I3).",
            user_story: 'As an admin, I want to establish booking rules so that I have control over my calendar and staff time.',
            contract: 'Adds new fields to the business data model in Firebase. The core booking logic will be modified to read and enforce these policy values, directly impacting which time slots are shown to customers.',
            status: 'Developed',
            version: '1.2.0',
            history: [{ version: '1.0.0', date: '2025-07-27', description: 'Initial booking policy fields added to business schema.' }, { version: '1.2.0', date: '2025-07-29', description: 'Policies are now actively enforced in the booking flow.' }],
            sub_features: [
                 {
                    code: 'F4.1',
                    name: 'Set max active bookings',
                    description: 'Limit how many upcoming appointments a single customer can hold at one time.',
                    anchor: "The `maxBookingsPerUser` field in the business schema (C2) is checked in `page-client.tsx` (I3) before allowing a booking.",
                    user_story: 'As an admin, I want to limit active bookings so that no single customer monopolises slots.',
                    contract: 'The booking UI will check a logged-in customer\'s current number of bookings against this value. If the limit is reached, the "Book Now" buttons will be disabled.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Policy check added to the booking interface.' }],
                },
                 {
                    code: 'F4.2',
                    name: 'Define lead time',
                    description: 'Set the minimum amount of advance notice required before an appointment can be booked.',
                    anchor: "The `leadTimeValue` and `leadTimeUnit` fields (C2) are used by the availability calculation logic in `booking-flow.tsx` (I3).",
                    user_story: 'As an admin, I want to enforce lead times so that staff have sufficient preparation notice.',
                    contract: 'The booking flow will use this policy to filter out time slots that are sooner than the defined lead time, preventing them from being displayed on the booking page.',
                    status: 'Developed',
                    version: '1.3.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Lead time calculation integrated into slot availability logic.' }, { version: '1.3.0', date: '2025-07-30', description: 'Fixed lead time calculation for same-day and next-day bookings.' }],
                },
                 {
                    code: 'F4.3',
                    name: 'Establish scheduling window',
                    description: 'Determine the maximum number of days or months in advance that customers are allowed to book.',
                    anchor: "The `schedulingWindowValue` and `schedulingWindowUnit` fields (C2) prevent `booking-flow.tsx` (I3) from showing dates too far in the future.",
                    user_story: 'As an admin, I want to set advance booking limits so that long-term planning is controlled.',
                    contract: 'The booking calendar will not allow navigation or selection of dates beyond the configured scheduling window from the current date.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Scheduling window limit added to slot availability logic.' }],
                },
                 {
                    code: 'F4.4',
                    name: 'Configure cancellation policy',
                    description: 'Define how soon before an appointment a customer is allowed to cancel or reschedule.',
                    anchor: "The `cancellationPolicy` field (C2) will be used in the customer's 'My Bookings' area (I3) to enable/disable cancellation buttons.",
                    user_story: 'As an admin, I want to define cancellation rules so that last-minute changes are minimised.',
                    contract: 'The UI for customer bookings will check this policy before showing the "Cancel" button. If an appointment is within the restricted period, the button will be hidden or disabled.',
                    status: 'Pending',
                    version: '-',
                    history: [],
                },
            ]
        },
         {
            code: 'F5',
            name: 'Admin calendar overview',
            description: 'A visual, interactive dashboard for monitoring and managing all staff schedules and events from a central hub.',
            anchor: "The main interface is at `/super-admin/businesses/[id]/calendar` (I1), powered by `calendar-client.tsx`.",
            user_story: 'As an admin, I want a central calendar so that I can oversee my entire team\'s schedule in one place.',
            contract: 'Implements a new page with a full-week calendar view. This component will fetch and display all schedule items (bookings, time off, etc.) for a selected staff member, providing a comprehensive visual overview.',
            status: 'Developed',
            version: '1.3.0',
            history: [{ version: '1.2.0', date: '2025-07-29', description: 'Full-featured weekly calendar view implemented.' }, { version: '1.3.0', date: '2025-07-31', description: 'Refactored calendar logic to handle breaks correctly and read from unified schedule.' }],
            sub_features: [
                 {
                    code: 'F5.1',
                    name: 'Team-wide calendar view',
                    description: 'Display an aggregated overview of all staff calendars, highlighting busy periods across the team.',
                    anchor: "The calendar client (I1) allows switching between staff members to see their individual schedules stored in C2.",
                    user_story: 'As an admin, I want a team-wide calendar view so that I can spot overall availability trends at a glance.',
                    contract: 'Adds a dropdown to the calendar page allowing the admin to switch between different staff members, dynamically reloading the calendar with the selected person\'s schedule.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Staff selection dropdown implemented.' }],
                },
                {
                    code: 'F5.2',
                    name: 'Drill-down to staff calendars',
                    description: 'Select a specific staff member to view their full, detailed calendar, including all assigned bookings and events.',
                    anchor: "The dropdown in `calendar-client.tsx` (I1) triggers `getStaffSchedule` (C1) to fetch and display data for the selected staff member from C2.",
                    user_story: 'As an admin, I want to inspect a staff calendar so that I can verify their specific schedule.',
                    contract: 'This is the core data-loading mechanism for the calendar, fetching all event types associated with a specific staff member from the `schedules` node in Firebase.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Fetching and displaying events for selected staff member.' }],
                },
                {
                    code: 'F5.3',
                    name: 'Inline calendar management',
                    description: 'Create, edit, or delete non-booking events directly from the calendar view.',
                    anchor: "Clicking on the calendar in I1 opens `event-form-dialog.tsx` to manage manual events in the `schedules` path of C2.",
                    user_story: 'As an admin, I want to manage calendar items inline so that updates are efficient and error-free.',
                    contract: 'Enables creating and editing manual events through a dialog that opens from the calendar view, writing directly to the `schedules` node in Firebase.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Dialog for creating/editing manual events implemented.' }],
                }
            ]
        },
        {
            code: 'F6',
            name: 'Customer booking interface',
            description: 'An intuitive, high-performance front-end for customers to browse services and make reservations.',
            anchor: "The primary component is `/src/app/[id]/booking-flow.tsx` (part of I3), which orchestrates the entire customer journey.",
            user_story: 'As a customer, I want a simple and fast way to book an appointment without any hassle.',
            contract: 'Implements the primary public-facing page (`/[id]`) for a business. This page will display services and contain the multi-step `BookingFlow` component that guides a customer through the entire process, from service selection to confirmation.',
            status: 'Developed',
            version: '1.4.0',
            history: [{ version: '1.2.0', date: '2025-07-29', description: 'Full customer booking flow implemented with multiple steps.' }, { version: '1.3.0', date: '2025-07-30', description: 'Corrected logic for when SMS verification is required during booking.' }, { version: '1.4.0', date: '2025-07-31', description: 'Streamlined booking flow for logged-in users and added a dedicated confirmation step.'}],
            sub_features: [
                 {
                    code: 'F6.1',
                    name: 'Browse service list',
                    description: 'Display all available services, organised by category, with clear pricing and duration information.',
                    anchor: "The `page-client.tsx` (I3) fetches and renders categories and services from Firebase (C2).",
                    user_story: 'As a customer, I want to see service options so that I can select what meets my needs.',
                    contract: 'The main booking page will fetch and display all service categories and their associated services in an accordion layout, allowing customers to easily browse the offerings.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Services are now displayed in an accordion by category.' }],
                },
                {
                    code: 'F6.2',
                    name: 'Intelligent date and time selection',
                    description: 'Present a calendar that only shows dates with available slots, aggregated from all relevant staff schedules.',
                    anchor: "The `booking-flow.tsx` component (I3) performs a real-time calculation against the unified schedule data from `AvailabilityProvider`.",
                    user_story: 'As a customer, I want only viable dates and times shown so that I don\'t waste time on unavailable options.',
                    contract: 'This implements the core client-side logic for checking availability against the pre-fetched schedule data. This includes all staff schedules, breaks, and existing appointments to return a list of times that a given service can be booked.',
                    status: 'Developed',
                    version: '1.3.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Slot aggregation and calendar display logic implemented.' }, { version: '1.3.0', date: '2025-07-30', description: 'Refactored to use a centralized AvailabilityProvider.' }],
                },
                {
                    code: 'F6.3',
                    name: 'SMS-based login and verification',
                    description: 'A secure and simple process for new customers to verify their phone number and for returning customers to sign in.',
                    anchor: "Handled by `customer-auth.tsx` (I3) and the `sendLoginSms` / `verifyLoginCode` server actions (C1), which use the SMS Service (C3).",
                    user_story: 'As a customer, I want an easy way to sign in or verify my number so that my information is pre-filled and secure.',
                    contract: 'This adds a customer authentication system. New customers verify their phone number via an SMS code, while returning customers can sign in. Signed-in customer data is stored in browser local storage for persistence.',
                    status: 'Developed',
                    version: '1.3.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Customer authentication flow via SMS OTP added.' }, { version: '1.3.0', date: '2025-07-30', description: 'Corrected logic for when SMS verification is required during booking.' }],
                },
                {
                    code: 'F6.4',
                    name: 'View and manage my bookings',
                    description: 'A dedicated area for signed-in customers to see their upcoming appointments and cancel them if necessary.',
                    anchor: "The `my-bookings.tsx` component (I3) fetches and displays a customer's specific bookings from C2.",
                    user_story: 'As a customer, I want to see my upcoming appointments so that I can manage my schedule.',
                    contract: 'A new component will be added to the booking page, visible only to signed-in users. It will fetch and display a list of their upcoming bookings and provide an option to cancel, subject to the business\'s cancellation policy.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Component to view and cancel upcoming bookings added for signed-in users.' }],
                }
            ]
        },
        {
            code: 'F7',
            name: 'Unified schedule & availability',
            description: 'A performant, centralized scheduling system where all events (bookings, breaks, time-off) are stored in one place, ensuring a single source of truth.',
            anchor: "The `schedules/` path in the Data Store (C2) is the single source of truth. It is written to by `staff/actions.ts` (C1) and read by the `AvailabilityProvider` (I3).",
            user_story: 'As a developer, I want a single, unified data source for all schedule-related events so that availability calculations are fast, consistent, and reliable.',
            contract: 'This feature establishes a core architectural pattern. All events that affect availability are written to a single `schedules` node in Firebase. Client applications use a real-time provider (`AvailabilityProvider`) to get this data, ensuring consistency across all user interfaces.',
            status: 'Developed',
            version: '1.3.0',
            history: [{ version: '1.3.0', date: '2025-07-30', description: 'Refactored the system to use a single, unified schedule for high performance and consistency.' }],
            sub_features: [
                 {
                    code: 'F7.1',
                    name: 'Real-time Availability Provider',
                    description: 'A client-side context provider that fetches all schedule events and updates in real-time, making availability checks instantaneous.',
                    anchor: "The `AvailabilityProvider` in `src/app/[id]/providers.tsx` fetches data via `getConsolidatedAvailability` (C1) and listens for updates from C2.",
                    user_story: 'As a customer, I want the booking calendar to update instantly so I don\'t book a slot that was just taken.',
                    contract: 'This React context provider fetches the entire schedule for a business and subscribes to real-time updates. All client components, like the booking flow, will consume this context instead of fetching data themselves.',
                    status: 'Developed',
                    version: '1.3.0',
                    history: [{ version: '1.3.0', date: '2025-07-30', description: 'AvailabilityProvider implemented to centralize client-side schedule data.' }],
                },
            ]
        },
        {
            code: 'F8',
            name: 'Staff Live Operations Screen',
            description: 'A tablet-ready dashboard for staff to manage the daily flow of customers, view their schedule, and handle bookings in real-time.',
            anchor: "The primary interface is `staff-screen-client.tsx` (I2), which manages state and interactions with C1 and C2.",
            user_story: 'As a staff member, I need a simple screen to manage my daily appointments and the queue so that I can stay organised and efficient.',
            contract: 'Creates a new page at `/[id]/staff-screen` designed for in-store use. This page will listen for real-time updates from Firebase to keep the queue and booking information constantly up-to-date without needing manual refreshes.',
            status: 'Developed',
            version: '1.4.0',
            history: [{ version: '1.1.0', date: '2025-07-28', description: 'Staff screen created with live data and real-time updates.' }, { version: '1.4.0', date: '2025-07-31', description: 'Major overhaul of Staff Kiosk UI and scheduling dialog.' }],
            sub_features: [
                {
                    code: 'F8.1',
                    name: 'Live Queue Dashboard',
                    description: 'Shows a clear view of who is currently being served ("Now Serving") and who is next in line ("Upcoming Queue").',
                    anchor: "The dashboard in I2 polls for data using `getLiveQueueData` (C1) and updates in real-time through a Firebase (C2) listener.",
                    user_story: 'As a staff member, I want to see the live queue so that I know who to serve next and can manage customer flow.',
                    contract: 'This component fetches all of today\'s bookings and separates them into two lists: "in-progress" and "waiting". It uses a real-time listener to automatically update the UI when a booking status changes.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Initial implementation of the live queue display.' }],
                },
                {
                    code: 'F8.2',
                    name: 'Kiosk Automation Rules',
                    description: 'Admins can configure the kiosk to automatically complete finished bookings or start the next person in the queue.',
                    anchor: "Settings are configured in `/edit/kiosk` (I1). The logic is executed in `staff-screen-client.tsx` (I2).",
                    user_story: 'As an admin, I want to automate the kiosk so my staff can focus more on customers and less on the tablet.',
                    contract: 'Adds a new settings page for kiosk automation. A `useEffect` hook in the staff screen client will periodically check if conditions are met to auto-complete or auto-start bookings based on these settings.',
                    status: 'Developed',
                    version: '1.4.0',
                    history: [{ version: '1.4.0', date: '2025-07-31', description: 'Added kiosk automation settings and client-side logic.' }],
                },
                 {
                    code: 'F8.3',
                    name: 'Manual Booking & Rescheduling',
                    description: 'A powerful dialog for staff to manually book or reschedule appointments, mirroring the customer flow logic.',
                    anchor: "The `ScheduleDialog` component in I2 allows staff to create/update bookings by calling `createBooking` or `rescheduleBooking` (C1).",
                    user_story: 'As a staff member, I want an easy way to book for walk-ins or reschedule customers so the calendar is always up to date.',
                    contract: 'Adds a "Schedule" button to the staff screen that opens a booking dialog. This dialog is a step-by-step flow similar to the customer\'s, allowing for quick creation or modification of appointments.',
                    status: 'Developed',
                    version: '1.4.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Basic manual booking dialog integrated.' }, { version: '1.4.0', date: '2025-07-31', description: 'Complete overhaul of scheduling dialog to match customer flow.' }],
                },
            ]
        },
        {
            code: 'F9',
            name: 'AI-Powered Wait Time Estimation',
            description: 'Utilises a Genkit AI flow to provide intelligent wait time estimations based on real-time and historical data.',
            anchor: "The `estimateWaitTime` flow (C4) is defined in `/src/ai/flows/estimate-wait-time.ts` and can be integrated into customer-facing UIs (I3).",
            user_story: 'As a business owner, I want to provide accurate wait times so that customer expectations are managed effectively and they feel informed.',
            contract: 'Creates a Genkit AI flow that takes queue length, service time, and historical trends as input and returns an estimated wait time. This flow can be called from any part of the application to provide this estimation.',
            status: 'Developed',
            version: '1.0.0',
            history: [{ version: '1.0.0', date: '2025-07-27', description: 'Initial AI flow created with Genkit to estimate wait times based on several input factors.' }],
            sub_features: []
        },
        {
            code: 'F10',
            name: 'Automated SMS Communication',
            description: 'A robust notification system that uses SMS to communicate with customers at key points in their journey.',
            anchor: "SMS logic (C1/C3) is handled by server actions, using providers configured in business records in C2 and triggered by I1, I2, and I3.",
            user_story: 'As a customer, I want to receive timely SMS updates so that I am always informed about my booking status.',
            contract: 'This feature establishes the core infrastructure for sending SMS messages. It includes server actions for sending different types of notifications (e.g., confirmation, cancellation) and logic for selecting the correct SMS provider based on business settings.',
            status: 'Developed',
            version: '1.2.0',
            history: [{ version: '1.2.0', date: '2025-07-29', description: 'Implemented a full suite of SMS notifications for the booking lifecycle.' }],
            sub_features: [
                 {
                    code: 'F10.1',
                    name: 'Multi-Provider SMS Gateway',
                    description: 'Supports multiple SMS providers (Vonage, TextBee) with a fallback to global credentials for flexibility.',
                    anchor: "The `getSmsClient` action (C1) dynamically instantiates the correct SMS client (C3) based on business settings in C2.",
                    user_story: 'As an admin, I want to choose my SMS provider so that I can use the service that best fits my needs and budget.',
                    contract: 'The `getSmsClient` server action will be updated to read the `smsProvider` field from a business\'s settings and instantiate the appropriate client class (Vonage or TextBee). This allows for flexible, per-business SMS routing.',
                    status: 'Developed',
                    version: '1.1.0',
                    history: [{ version: '1.1.0', date: '2025-07-28', description: 'Added support for Vonage and TextBee SMS providers.' }],
                },
                {
                    code: 'F10.2',
                    name: 'Customizable SMS Templates',
                    description: 'Admins can customize the content of each type of SMS message in multiple languages.',
                    anchor: "Templates are stored in the business record (C2) and accessed by server actions (C1) before sending an SMS.",
                    user_story: 'As an admin, I want to customize SMS messages so that they reflect my brand\'s tone of voice.',
                    contract: 'The business data model will be updated to store a set of SMS templates. The admin UI will provide text areas for editing these templates, which are then used by the SMS-sending server actions.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Added UI for editing SMS templates in the business settings.' }],
                },
                {
                    code: 'F10.3',
                    name: 'Lifecycle Notifications',
                    description: 'Automated messages are sent for booking confirmation, rescheduling, cancellation, and reminders.',
                    anchor: "Server actions like `sendConfirmationSms` (C1) are called at appropriate points in the booking process from I2 and I3.",
                    user_story: 'As a customer, I want to receive confirmations and reminders so that I don\'t miss my appointment.',
                    contract: 'Specific server actions (e.g., `createBooking`, `cancelBooking`) will be modified to include a call to the relevant SMS notification action, ensuring messages are sent automatically at key points in the booking lifecycle.',
                    status: 'Developed',
                    version: '1.2.0',
                    history: [{ version: '1.2.0', date: '2025-07-29', description: 'Implemented various SMS notification triggers.' }],
                },
            ]
        },
    ];

    const technologies = [
        { name: 'Next.js & React', description: 'The core web framework, utilizing the App Router for server components and optimized routing.', icon: <Cpu /> },
        { name: 'TypeScript', description: 'Provides static typing for improved code quality and developer experience.', icon: <div className="font-bold text-base bg-blue-600 text-white rounded-sm w-5 h-5 flex items-center justify-center">TS</div> },
        { name: 'Tailwind & ShadCN', description: 'A utility-first CSS framework combined with a beautifully designed component library for rapid UI development.', icon: <Brush /> },
        { name: 'Firebase', description: 'The backend platform providing Realtime Database for our single source of truth, plus file Storage.', icon: <Database /> },
        { name: 'Genkit', description: 'The AI framework used for all generative AI features, including wait time estimation.', icon: <Bot /> },
        { name: 'Firebase App Hosting', description: 'Provides scalable, secure, and fully-managed hosting for the web application.', icon: <Cloud /> },
    ];

     const releases = [
         {
            version: '1.4.0',
            date: '2025-07-31',
            title: 'Staff Kiosk Overhaul & Booking Flow Finalization',
            features: [
                'F8: Complete UI and functional overhaul of the Staff Kiosk (I2) for improved usability on tablets.',
                'F8.2: Added Kiosk Automation settings for auto-completing and auto-starting bookings.',
                'F8.3: Rebuilt the staff scheduling dialog to be a step-by-step flow, mirroring the customer experience for consistency.',
                'F6: Finalized the customer booking flow by adding a dedicated confirmation step and streamlining the process for logged-in users.',
                'Fixed multiple hydration and build errors across the application.'
            ]
        },
         {
            version: '1.3.0',
            date: '2025-07-30',
            title: 'Performance & Booking Flow Optimization',
            features: [
                'F7: Major performance refactor of the availability checking logic by implementing a unified schedule.',
                'F2.2: Staff availability and time-off are now pre-processed and written directly to the unified `schedules` calendar.',
                'F6.2, F6.3: Booking flow now correctly handles SMS verification and lead time policies.',
                'Updated the Blueprint "Booking Flow" diagram to reflect the new, optimized architecture.'
            ]
        },
        {
            version: '1.2.0',
            date: '2025-07-29',
            title: 'Intelligent Booking & Admin Calendar',
            features: [
                'F5: Admin Calendar Overview and Management',
                'F6: Customer Booking Interface',
                'F10.2, F10.3: SMS Template editing and lifecycle notifications',
                'F13: SEO & Social Sharing options',
                'Added "Week starts on" booking policy.',
                'Refined Lead Time policy implementation in the UI.',
            ]
        },
        {
            version: '1.1.0',
            date: '2025-07-28',
            title: 'Staff & Service Management',
            features: [
                'F2: Business-level staff management',
                'F3: Service and add-on management',
                'F8: Staff Live Operations Screen',
                'F10.1: Multi-provider SMS gateway support',
            ]
        },
        {
            version: '1.0.0',
            date: '2025-07-27',
            title: 'Initial Platform Setup',
            features: [
                'F1: Super admin business management',
                'F4: Booking policy configuration',
                'F9: AI-Powered Wait Time Estimation',
                'F11: Customizable Business Branding',
                'F12: Custom Domain & URL Management',
                'Initial setup of the application architecture and database.',
            ]
        }
    ];

    const StatusBadge = ({ status }: { status: 'Developed' | 'Pending' | 'Excluded' }) => {
        const statusClasses = {
            Developed: 'bg-green-100 text-green-800 border-green-200',
            Pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
            Excluded: 'bg-red-100 text-red-800 border-red-200',
        };
        return <Badge variant="outline" className={cn('font-mono', statusClasses[status])}>{status}</Badge>;
    };

    const filteredFeatures = features.filter(feature => {
        const term = searchTerm.toLowerCase();
        if (!term) return true;

        const inName = feature.name.toLowerCase().includes(term);
        const inCode = feature.code.toLowerCase().includes(term);
        const inDescription = feature.description.toLowerCase().includes(term);
        const inSubFeatures = feature.sub_features.some(sub => 
            sub.name.toLowerCase().includes(term) ||
            sub.code.toLowerCase().includes(term) ||
            sub.description.toLowerCase().includes(term)
        );

        return inName || inCode || inDescription || inSubFeatures;
    });
    
    const tabs = [
        { id: 'architecture', label: 'Architecture' },
        { id: 'booking-flow', label: 'Booking Flow' },
        { id: 'tech-stack', label: 'Technology' },
        { id: 'releases', label: 'Releases' },
        { id: 'features', label: 'Features' },
    ];

  return (
    <>
    <div className="bg-slate-50 min-h-screen flex flex-col">
      <div className="w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col min-h-screen">
            <div className="flex justify-between items-center border-b px-4 md:px-8">
                <TabsList className="bg-transparent p-0">
                    {tabs.map(tab => (
                         <TabsTrigger 
                            key={tab.id}
                            value={tab.id} 
                            className="text-sm bg-transparent text-muted-foreground data-[state=active]:text-primary data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-3 pb-2"
                        >
                            {tab.label}
                        </TabsTrigger>
                    ))}
                </TabsList>
                 <div className="py-4 text-right">
                    <h1 className="text-xl font-bold text-slate-800">System Blueprint</h1>
                </div>
            </div>

            <TabsContent value="architecture" className="flex-1 overflow-hidden">
                 <InteractiveCanvas className="w-full h-full bg-slate-100/50">
                    <ArchitectureDiagram />
                </InteractiveCanvas>
            </TabsContent>
            
            <TabsContent value="booking-flow" className="flex-1 overflow-hidden">
                 <InteractiveCanvas className="w-full h-full bg-slate-100/50">
                    <BookingFlowDiagram />
                </InteractiveCanvas>
            </TabsContent>

            <TabsContent value="tech-stack" className="p-4 md:p-8">
                <h2 className="text-2xl font-bold text-center text-slate-800 mb-6">Technology Stack</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {technologies.map((tech) => (
                        <div key={tech.name} className="flex items-start gap-4 p-4 bg-white rounded-lg shadow-sm border">
                            <div className="flex-shrink-0 p-2 bg-slate-100 rounded-full">{tech.icon}</div>
                            <div>
                                <h3 className="font-bold text-slate-800">{tech.name}</h3>
                                <p className="text-sm text-slate-600">{tech.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </TabsContent>

            <TabsContent value="releases" className="p-4 md:p-8">
                 <h2 className="text-2xl font-bold text-center text-slate-800 mb-6">Release History</h2>
                <div className="relative pl-6 after:absolute after:inset-y-0 after:w-px after:bg-slate-200 after:left-0">
                    {releases.map((release) => (
                        <div key={release.version} className="relative grid grid-cols-1 md:grid-cols-5 gap-x-8 pb-12">
                            <div className="md:col-span-1 text-right pt-1">
                                <p className="font-mono font-semibold text-slate-700">{release.version}</p>
                                <p className="text-sm text-slate-500">{release.date}</p>
                            </div>
                            <div className="md:col-span-4 mt-2 md:mt-0">
                                <span className="absolute -left-[calc(0.5rem+1px)] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-slate-200 ring-4 ring-slate-50">
                                    <GitMerge className="h-4 w-4 text-slate-500" />
                                </span>
                                <div className="p-4 rounded-lg bg-white shadow-sm border">
                                    <h3 className="font-semibold text-slate-800">{release.title}</h3>
                                    <ul className="mt-2 list-disc list-inside text-sm text-slate-600 space-y-1">
                                        {release.features.map((feature, i) => (
                                            <li key={i}>{feature}</li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </TabsContent>

            <TabsContent value="features" className="flex-1 grid md:grid-cols-[280px_1fr] gap-8 p-4 md:p-8">
                <aside className="hidden md:block sticky top-[8.5rem] self-start">
                    <div className="space-y-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input 
                                placeholder="Search features..."
                                className="pl-9"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <ScrollArea className="h-[calc(100vh-12rem)]">
                            <nav className="flex flex-col gap-1 pr-4">
                                {features.map((feature) => (
                                    <a 
                                        key={feature.code} 
                                        href={`#${feature.code}`}
                                        className="text-sm text-muted-foreground hover:text-primary p-2 rounded-md transition-colors"
                                    >
                                        <span className="font-mono bg-slate-200 text-slate-600 rounded px-1.5 py-0.5 mr-2">{feature.code}</span>
                                        {feature.name}
                                    </a>
                                ))}
                            </nav>
                        </ScrollArea>
                    </div>
                </aside>

                <main className="space-y-10">
                    {filteredFeatures.map((feature) => (
                        <div key={feature.code} id={feature.code} className="scroll-mt-24">
                        <div className="p-4 rounded-t-lg -mx-4 px-4">
                            <div className="flex justify-between items-center">
                                <h3 className="text-xl font-bold text-slate-800">
                                    <span className="font-mono bg-slate-200 text-slate-600 rounded-md px-2 py-1 mr-3">{feature.code}</span>
                                    {feature.name}
                                </h3>
                                <div className="flex items-center gap-2">
                                    <StatusBadge status={feature.status as any} />
                                    <Badge variant="secondary">v{feature.version}</Badge>
                                </div>
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-b-lg shadow-md">
                            <p className="text-slate-600 mb-2">{feature.description}</p>
                            <blockquote className="border-l-4 border-slate-200 pl-4 my-4 text-sm">
                                <p className="font-semibold text-slate-700">User Story:</p>
                                <p className="text-slate-600 italic">"{feature.user_story}"</p>
                            </blockquote>
                             <blockquote className="border-l-4 border-sky-200 pl-4 my-4 text-sm bg-sky-50/50 py-2">
                                <p className="font-semibold text-sky-800">Contract:</p>
                                <p className="text-sky-700">{feature.contract}</p>
                            </blockquote>
                            <p className="text-xs text-slate-400">
                                <strong>Anchor:</strong> {feature.anchor}
                            </p>

                            <div className="mt-6 space-y-6">
                                {feature.sub_features && feature.sub_features.map(sub => (
                                    <div key={sub.code} className="p-4 border border-slate-100 rounded-lg bg-slate-50/50">
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-semibold text-slate-700 max-w-[80%]">
                                                <span className="font-mono text-xs bg-slate-200 text-slate-500 rounded px-1.5 py-0.5 mr-2">{sub.code}</span>
                                                {sub.name}
                                            </h4>
                                            <div className="flex items-center gap-2 flex-shrink-0">
                                                <StatusBadge status={sub.status as any} />
                                                <Badge variant="secondary">v{sub.version}</Badge>
                                            </div>
                                        </div>
                                        <p className="text-sm text-slate-600 mt-1">{sub.description}</p>
                                        <blockquote className="border-l-2 border-slate-200 pl-3 my-3 text-sm">
                                             <p className="font-semibold text-slate-700">User Story:</p>
                                             <p className="text-slate-600 italic">"{sub.user_story}"</p>
                                        </blockquote>
                                        <blockquote className="border-l-2 border-sky-200 pl-3 my-3 text-sm bg-sky-50/50 py-2">
                                            <p className="font-semibold text-sky-800">Contract:</p>
                                            <p className="text-sky-700">{sub.contract}</p>
                                        </blockquote>
                                        <p className="text-xs text-slate-400">
                                            <strong>Anchor:</strong> {sub.anchor}
                                        </p>
                                        <Button variant="outline" size="sm" className="mt-2" onClick={() => handleViewHistory(sub)}>
                                            <History className="h-4 w-4 mr-2" />
                                            View History
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        </div>
                        </div>
                    ))}
                    {filteredFeatures.length === 0 && (
                        <div className="text-center py-16 text-muted-foreground border rounded-lg bg-white">
                            <p className="font-semibold">No features found for "{searchTerm}"</p>
                            <p className="text-sm">Try a different search term.</p>
                        </div>
                    )}
                </main>
            </TabsContent>
        </Tabs>
      </div>
    </div>
    
    <Dialog open={historyModalOpen} onOpenChange={setHistoryModalOpen}>
        <DialogContent className="sm:max-w-xl">
            <DialogHeader>
                <DialogTitle>
                    History for: <span className="font-mono bg-muted text-muted-foreground rounded px-1.5 py-0.5">{selectedFeatureHistory?.code}</span> {selectedFeatureHistory?.name}
                </DialogTitle>
                <DialogDescription>
                    A log of changes and updates for this feature.
                </DialogDescription>
            </DialogHeader>
            <div className="max-h-[60vh] overflow-y-auto p-1">
                {selectedFeatureHistory?.history && selectedFeatureHistory.history.length > 0 ? (
                     <div className="relative pl-6 after:absolute after:inset-y-0 after:w-px after:bg-slate-200 after:left-1 dark:after:bg-slate-700">
                        {selectedFeatureHistory.history.map((item: any, index: number) => (
                           <div key={index} className="grid grid-cols-1 gap-x-8 pb-8">
                                <div className="mt-2 md:mt-0">
                                    <span className="absolute -left-[calc(0.12rem+1px)] top-1 flex h-2 w-2 items-center justify-center rounded-full bg-slate-200 ring-8 ring-slate-50 dark:bg-slate-700 dark:ring-slate-900"></span>
                                    <div className="p-4 rounded-lg bg-white shadow-sm border">
                                        <div className="flex justify-between items-center mb-1">
                                            <p className="font-mono font-semibold text-slate-700 text-sm">v{item.version}</p>
                                            <p className="text-xs text-slate-500">{item.date}</p>
                                        </div>
                                        <p className="text-sm text-slate-600">{item.description}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-center text-muted-foreground py-8">No history available for this feature.</p>
                )}
            </div>
            <DialogFooter>
                <DialogClose asChild>
                    <Button type="button" variant="outline">Close</Button>
                </DialogClose>
            </DialogFooter>
        </DialogContent>
    </Dialog>
    </>
  );
}

    

'use client';

import * as React from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { getAuth, verifyPasswordResetCode, confirmPasswordReset } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { getGlobalSettings } from '@/app/super-admin/settings/actions';
import Image from 'next/image';

const auth = getAuth(app);

const passwordResetSchema = z.object({
  password: z.string().min(6, 'Password must be at least 6 characters.'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type PasswordResetFormData = z.infer<typeof passwordResetSchema>;

export default function AuthActionClientPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  
  const [globalSettings, setGlobalSettings] = React.useState<any>({});
  const [step, setStep] = React.useState<'loading' | 'form' | 'success' | 'error'>('loading');
  const [email, setEmail] = React.useState('');
  const [error, setError] = React.useState('');
  const [title, setTitle] = React.useState('Loading...');

  const form = useForm<PasswordResetFormData>({
    resolver: zodResolver(passwordResetSchema),
    defaultValues: { password: '', confirmPassword: '' },
  });

  React.useEffect(() => {
    async function fetchSettings() {
        const settings = await getGlobalSettings();
        setGlobalSettings(settings.general || {});
    }
    fetchSettings();
  }, []);

  React.useEffect(() => {
    const mode = searchParams.get('mode');
    const oobCode = searchParams.get('oobCode');

    if (!oobCode || (mode !== 'resetPassword' && mode !== 'signIn' && mode !== 'recoverEmail')) {
      setError('Invalid action link. Please request a new one.');
      setStep('error');
      return;
    }

    const verifyCode = async () => {
      try {
        const userEmail = await verifyPasswordResetCode(auth, oobCode);
        setEmail(userEmail);
        setTitle(mode === 'resetPassword' ? 'Reset Your Password' : "You're Invited! Set Up Your Account");
        setStep('form');
      } catch (e) {
        setError('The link is invalid or has expired. Please request a new one.');
        setStep('error');
      }
    };
    if (mode === 'resetPassword') {
        verifyCode();
    } else {
        setError('Unsupported action mode.');
        setStep('error');
    }
  }, [searchParams]);
  
  const onSubmit = async (data: PasswordResetFormData) => {
    const oobCode = searchParams.get('oobCode');
    if (!oobCode) return;
    try {
        await confirmPasswordReset(auth, oobCode, data.password);
        toast({ title: 'Password Set Successfully!', description: 'You will be redirected to the login page.' });
        setStep('success');
        setTimeout(() => {
            router.push('/super-admin/login');
        }, 3000);
    } catch (e: any) {
        let errorMessage = 'Failed to set password. The link may have expired.';
        if (e.code === 'auth/expired-action-code') {
            errorMessage = 'This password reset link has expired. Please request a new one.';
        } else if (e.code === 'auth/invalid-action-code') {
            errorMessage = 'This password reset link is invalid. It may have already been used.';
        }
        toast({ variant: 'destructive', title: 'Error', description: errorMessage });
        setError(errorMessage);
        setStep('error');
    }
  }
  
  const appName = globalSettings.appName || 'Bestiller.com';
  const appLogoUrl = globalSettings.appLogoUrl;

  const renderContent = () => {
    switch (step) {
      case 'loading':
        return (
             <div className="flex flex-col items-center gap-4">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                <p className="text-muted-foreground">Verifying link...</p>
            </div>
        );
      case 'form':
        return (
          <Card className="w-full max-w-sm">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <CardHeader>
                  <CardTitle>{title}</CardTitle>
                  <CardDescription>Enter a new password for {email}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>New Password</FormLabel>
                        <FormControl><Input type="password" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm New Password</FormLabel>
                        <FormControl><Input type="password" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                 <CardFooter>
                    <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                        {form.formState.isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Set Password & Continue
                    </Button>
                 </CardFooter>
              </form>
            </Form>
          </Card>
        );
      case 'success':
        return (
          <div className="text-center space-y-4">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
            <h2 className="text-2xl font-bold">Success!</h2>
            <p className="text-muted-foreground">Your password has been set. Redirecting you to the login page...</p>
          </div>
        );
      case 'error':
         return (
          <Card className="w-full max-w-sm text-center border-destructive">
            <CardHeader>
              <CardTitle>Action Failed</CardTitle>
              <CardDescription className="text-destructive">{error}</CardDescription>
            </CardHeader>
             <CardContent>
              <Button asChild variant="secondary"><Link href="/super-admin/login">Back to Login</Link></Button>
            </CardContent>
          </Card>
        );
    }
  };
  
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted p-4">
      <div className="mb-8">
        <Link href="/" className="relative h-12 w-60">
          {appLogoUrl ? (
              <Image src={appLogoUrl} alt={`${appName} logo`} fill className="object-contain"/>
          ) : (
              <h1 className="text-3xl font-bold">{appName}</h1>
          )}
        </Link>
      </div>
      {renderContent()}
    </div>
  );
}

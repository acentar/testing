
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';
import { Loader2, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { login } from './actions';
import Link from 'next/link';
import type { Business } from '@/app/super-admin/businesses/actions';
import { getGlobalSettings } from '@/app/super-admin/settings/actions';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { PhoneInput } from '@/components/phone-input';

const translations = {
  bs: {
    description: "Prijavite se na svoju aplikaciju za osoblje da upravljate svojim kalendarom, pregledate zakazane termine s klijentima i pristupite svim svojim alatima.",
    phoneLabel: "Broj telefona",
    pinLabel: "4-cifreni PIN",
    signInButton: "Prijavi se",
    errorPhoneRequired: "Broj telefona je obavezan.",
    errorPinLength: "PIN mora imati 4 cifre.",
    signInSuccess: "Prijava uspješna!",
    signInFailed: "Prijava nije uspjela",
    checkCredentials: "Molimo provjerite svoje podatke i pokušajte ponovo.",
    invalidCredentials: "Nevažeći broj telefona ili PIN.",
  },
  en: {
    description: "Sign in to your staff application to manage your calendar, view scheduled appointments with clients, and access all your tools.",
    phoneLabel: "Phone Number",
    pinLabel: "4-Digit PIN",
    signInButton: "Sign In",
    errorPhoneRequired: "Phone number is required.",
    errorPinLength: "PIN must be 4 digits.",
    signInSuccess: "Sign-in successful!",
    signInFailed: "Sign-in Failed",
    checkCredentials: "Please check your credentials and try again.",
    invalidCredentials: "Invalid phone number or PIN.",
  },
  da: {
    description: "Log ind på din personaleapplikation for at administrere din kalender, se planlagte aftaler med kunder og få adgang til alle dine værktøjer.",
    phoneLabel: "Telefonnummer",
    pinLabel: "4-cifret PIN",
    signInButton: "Log ind",
    errorPhoneRequired: "Telefonnummer er påkrævet.",
    errorPinLength: "PIN-koden skal være på 4 cifre.",
    signInSuccess: "Login vellykket!",
    signInFailed: "Login mislykkedes",
    checkCredentials: "Kontroller venligst dine oplysninger og prøv igen.",
    invalidCredentials: "Ugyldigt telefonnummer eller PIN.",
  }
};

const getLoginSchema = (t: (typeof translations)['en']) => z.object({
  phone: z.string().min(8, t.errorPhoneRequired),
  pinCode: z.string().length(4, t.errorPinLength),
});


type LoginFormData = z.infer<ReturnType<typeof getLoginSchema>>;


export function StaffLoginPageClient() {
  const router = useRouter();
  const { toast } = useToast();
  const [globalSettings, setGlobalSettings] = React.useState<any>({});
  const [loading, setLoading] = React.useState(true);
  const [language, setLanguage] = React.useState<'en' | 'bs' | 'da'>('bs');

  const t = translations[language] || translations.bs;

  const form = useForm<LoginFormData>({
    resolver: zodResolver(getLoginSchema(t)),
    defaultValues: {
      phone: '',
      pinCode: '',
    },
  });

  React.useEffect(() => {
    form.trigger();
  }, [language, form]);

  React.useEffect(() => {
    const fetchInitialData = async () => {
        setLoading(true);
        const settings = await getGlobalSettings();
        setGlobalSettings(settings.general || {});
        setLoading(false);
    };
    
    fetchInitialData();
  }, []);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: LoginFormData) => {
    const result = await login(data);
    if (result.success && result.businessId) {
        sessionStorage.setItem('justLoggedIn', 'true');
        if (result.fullName) {
          sessionStorage.setItem('staffFullName', result.fullName);
        }
        toast({ title: t.signInSuccess });
        router.push(`/${result.businessId}/staff-app`);
    } else {
        let errorMessage = result.error || t.checkCredentials;
        if (errorMessage.includes('Invalid') || errorMessage.includes('not found')) {
            errorMessage = t.invalidCredentials;
        }

        toast({
            variant: 'destructive',
            title: t.signInFailed,
            description: errorMessage,
        });
    }
  };
  
  const logoUrl = globalSettings.staffAppSettingsLogoUrl || globalSettings.appLogoUrl;
  const appName = globalSettings.appName || 'QueuePilot';
  const bgImageUrl = globalSettings.staffAppSettingsBgImageUrl || 'https://images.unsplash.com/photo-1542202277-341225364954?q=80&w=1964&auto=format&fit=crop';

  return (
    <div className="w-full min-h-screen bg-white lg:grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-4">
        <div className="mx-auto grid w-[350px] gap-6">
          <div className="absolute top-4 right-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  {language === 'bs' ? '🇧🇦' : language === 'da' ? '🇩🇰' : '🇬🇧'}
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLanguage('bs')}>
                  <span className="mr-2 text-xl">🇧🇦</span> Bosanski
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('da')}>
                  <span className="mr-2 text-xl">🇩🇰</span> Dansk
                </DropdownMenuItem>
                 <DropdownMenuItem onClick={() => setLanguage('en')}>
                  <span className="mr-2 text-xl">🇬🇧</span> English
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="grid gap-2 text-center">
             <Link href="/" className="mb-4 inline-block relative h-12 w-60 mx-auto">
                {loading ? (
                     <div className="h-12 w-48 bg-gray-200 animate-pulse rounded-md mx-auto" />
                ) : logoUrl ? (
                    <Image src={logoUrl} alt={`${appName} logo`} fill style={{objectFit: 'contain'}} priority unoptimized />
                ) : (
                    <h1 className="text-3xl font-bold">{appName}</h1>
                )}
            </Link>
            <p className="text-muted-foreground">
                {t.description}
            </p>
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4">
                <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>{t.phoneLabel}</FormLabel>
                        <FormControl>
                          <PhoneInput {...field} allowedCountries={['DK', 'BA']} defaultCountry="BA" />
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="pinCode"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>{t.pinLabel}</FormLabel>
                        <FormControl>
                        <Input
                            type="password"
                            inputMode="numeric"
                            maxLength={4}
                            placeholder="••••"
                            {...field}
                            className="text-center text-lg tracking-[0.5em]"
                            autoComplete="one-time-code"
                        />
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {t.signInButton}
                </Button>
            </form>
          </Form>
        </div>
      </div>
      <div className="hidden lg:block">
        <Image
          src={bgImageUrl ?? ''}
          alt="A beautiful cityscape at sunrise"
          width={1200}
          height={1800}
          className="h-screen w-full object-cover"
          data-ai-hint="cityscape sunrise"
          priority
        />
      </div>
    </div>
  );
}

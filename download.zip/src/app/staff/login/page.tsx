
import * as React from 'react';
import type { Metadata } from 'next';
import { StaffLoginPageClient } from './client-page';

export const metadata: Metadata = {
  title: "Staff app. - Login",
};

export default function StaffLoginPage() {
    return (
        <React.Suspense fallback={<div>Loading...</div>}>
            <StaffLoginPageClient />
        </React.Suspense>
    );
}

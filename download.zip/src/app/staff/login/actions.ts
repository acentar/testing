
'use server';

import { z } from 'zod';
import { cookies } from 'next/headers';
import admin from '@/lib/firebase-admin';
import bcrypt from 'bcryptjs';
import type { StaffKioskUser } from '@/app/super-admin/businesses/new/schema';

const loginSchema = z.object({
  phone: z.string().min(8, 'Phone number is required.'),
  pinCode: z.string().length(4, 'PIN must be 4 digits.'),
});

export async function login(data: z.infer<typeof loginSchema>): Promise<{ success: boolean; businessId?: string; fullName?: string; error?: string }> {
    const validationResult = loginSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, error: 'Invalid data provided. Please check your inputs.' };
    }

    const { phone, pinCode } = validationResult.data;

    try {
        const businessesRef = admin.database().ref('businesses');
        const businessesSnapshot = await businessesRef.once('value');

        if (!businessesSnapshot.exists()) {
            return { success: false, error: 'Invalid phone number or PIN.' };
        }
        
        const businessesData = businessesSnapshot.val();
        let validUser = null;
        let userId = null;
        let businessId: string | null = null;
        
        for (const bId in businessesData) {
            const business = businessesData[bId];
            if (business.staffKioskUsers) {
                const userEntry = Object.entries(business.staffKioskUsers).find(([id, user]) => (user as StaffKioskUser).phone === phone);

                if (userEntry) {
                    const [uId, user] = userEntry;
                    const isMatch = await bcrypt.compare(pinCode, (user as StaffKioskUser).pin);
                    if (isMatch) {
                        validUser = user as StaffKioskUser;
                        userId = uId;
                        businessId = bId;
                        break;
                    }
                }
            }
            if (validUser) break;
        }

        if (!validUser || !businessId) {
             return { success: false, error: 'Invalid phone number or PIN.' };
        }

        const sessionData = {
            businessId: businessId,
            userId: userId,
            authenticatedAt: new Date().toISOString(),
        };
        
        const sessionValue = btoa(JSON.stringify(sessionData));
        
        cookies().set('staff-session', sessionValue, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 60 * 60 * 24 * 30, // 30 days
            path: '/',
        });

        return { success: true, businessId: businessId, fullName: (validUser as any).fullName };

    } catch (error) {
        console.error("Error during staff login:", error);
        return { success: false, error: "An internal server error occurred." };
    }
}

export async function logout() {
    cookies().delete('staff-session');
}


import { type NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  const options = {
    name: 'firebase-auth-token',
    value: '',
    maxAge: -1,
    path: '/', // Path is required for deletion to work correctly
  };

  // Set the cookie to expire before creating the response
  cookies().set(options);
  
  return NextResponse.json({ status: 'success' }, { status: 200 });
}

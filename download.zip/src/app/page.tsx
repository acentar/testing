
'use client';

import * as React from 'react';
import { Handshake, Clock, Users, Scissors, Calendar, Sparkles, BrainCircuit, Tablet, Globe, Search, ArrowRight, Phone, Target, MessageSquare, Eye, Check, ChevronDown, Info, Loader2, Award, Star, CheckCircle } from 'lucide-react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import Link from 'next/link';
import { PrivacyPolicyModal } from '@/components/legal/privacy-policy-modal';
import { TermsOfServiceModal } from '@/components/legal/terms-of-service-modal';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { getGlobalSettings } from './super-admin/settings/actions';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel"
import Autoplay from "embla-carousel-autoplay"


const translations = {
  en: {
    navFeatures: 'Features',
    navPricing: 'Pricing',
    navGoogle: 'Google Business',
    navContact: 'Contact',
    navStaffApp: 'Staff App',
    getStarted: 'Get started',
    heroTitle: 'A scheduling system which helps you earn more and work less',
    heroSubtitle: 'Our platform gives your service business a complete professional scheduling system. Customers book themselves online 24/7 → every appointment appears instantly in your staff calendar. Zero phone tag. Zero double bookings. Hours saved every single week. Perfect for salons, beauty clinics, gyms, car workshops, cleaning companies and more.',
    googleFeatureTitle: 'Be found on Google – turn searches into bookings',
    googleFeatureDesc: 'We manage your Google Business Profile for you at no extra cost – everything is included in your subscription.',
    googleFeaturePoints: [
      'Your business appears correctly on Google Search and Maps',
      'We add your services, photos, opening hours and a professional booking button',
      'Customers see your listing, tap a few times and book directly into your calendar',
      'All handled by us, all included in the one simple price.'
    ],
    bookingFeatureTitle: 'Online booking that works 24/7',
    bookingFeatureDesc: 'Give your clients a beautiful, mobile-friendly booking page branded with your logo and colours.',
    bookingFeaturePoints: [
        'They pick the service, staff member and time that suits them – any time, day or night',
        'No more back-and-forth messages or losing customers on missed calls',
        'Bookings are sent directly to your Staff app, so you dont need to do much'
    ],
    staffFeatureTitle: 'Staff web app your team will actually love',
    staffFeatureDesc: 'No downloads needed – just log in from phone, tablet or computer.',
    staffFeaturePoints: [
        'The entire day’s schedule at a glance – no more paper calendars or scribbled notes',
        'Every new booking (from the website, Google or walk-ins) appears instantly and automatically',
        'Easy appointment creator: your staff can book clients in seconds when someone calls or walks in',
        'All digital, all automatic, zero chaos.'
    ],
    smsFeatureTitle: 'Automatic SMS messages that customers love (and that protect your income)',
    smsFeatureDesc: 'Smart, friendly messages sent exactly when needed:',
    smsFeaturePoints: [
        'Verification SMS stops fake bookings',
        'Instant confirmation with all details',
        'Reschedule & Cancellation SMS – customers stay informed if plans change',
        'Reminder SMS so customers never forget',
        'SMS is opened by almost everyone much more effective than email.',
        'All SMS messages are fully included in your subscription.',
        'No extra cost per message, no limits, nothing hidden.',
        'Every text can be customised to sound just like you.'
    ],
    pricingTitle: 'Simple, transparent pricing',
    pricingDesc: `One plan, everything included.`,
    price: '€25',
    pricePer: '/ month',
    priceVat: '(incl. VAT)',
    priceBase: 'For up to 3 staff members',
    priceExtra: 'Each additional staff member only €9/month.',
    cancelAnytime: 'Cancel anytime',
    noSetupFees: 'No setup fees',
    noHiddenCosts: 'No hidden costs',
    footerCompany: 'Company',
    footerContact: 'Contact',
    footerDevelopedBy: 'by Sigma Development',
    footerRights: 'All rights reserved.',
    footerLegal: 'Legal',
    footerPrivacy: 'Privacy Policy',
    footerTerms: 'Terms of Service',
    footerTagline: 'Smart Queue Management and Booking',
    marqueePoints: [
      "Get more clients",
      "Rely less on phone calls",
      "Get found on Google maps",
      "Allow customer booking 24/7",
      "Get fewer no-shows",
      "Get full SMS service",
      "Get happier staff",
      "One clear price",
      "Get all this for €25 a month"
    ]
  },
  bs: {
    navFeatures: 'Mogućnosti',
    navPricing: 'Cijene',
    navGoogle: 'Google Business',
    navContact: 'Kontakt',
    navStaffApp: 'Aplikacija za osoblje',
    getStarted: 'Započni',
    heroTitle: 'Sistem za zakazivanje koji vam pomaže da zarađujete više i radite manje',
    heroSubtitle: 'Naša platforma daje vašem uslužnom poslovanju kompletan profesionalni sistem za zakazivanje. Klijenti sami rezervišu online 24/7 → svaki termin se odmah pojavljuje u kalendaru vašeg osoblja. Nema više propuštenih poziva. Nema duplih rezervacija. Sati ušteđeni svake sedmice. Savršeno za salone, kozmetičke klinike, teretane, automehaničarske radnje, firme za čišćenje i još mnogo toga.',
    googleFeatureTitle: 'Budite pronađeni na Googleu – pretvorite pretrage u rezervacije',
    googleFeatureDesc: 'Mi upravljamo vašim Google Business profilom for vas bez dodatnih troškova – sve je uključeno u vašu pretplatu.',
     googleFeaturePoints: [
      'Vaš posao se ispravno prikazuje na Google pretrazi i mapama',
      'Dodajemo vaše usluge, fotografije, radno vrijeme i profesionalno dugme za rezervaciju',
      'Kupci vide vaš oglas, kliknu nekoliko puta i rezervišu direktno u vaš kalendar',
      'Sve rješavamo mi, sve je uključeno u jednu jednostavnu cijenu.'
    ],
    bookingFeatureTitle: 'Online rezervacije koje rade 24/7',
    bookingFeatureDesc: 'Dajte svojim klijentima prelijepu, mobilno prilagođenu stranicu za rezervacije s vašim logotipom i bojama.',
    bookingFeaturePoints: [
        'Oni biraju uslugu, člana osoblja i vrijeme koje im odgovara – bilo kada, danju ili noću',
        'Nema više poruka naprijed-nazad ili gubljenja klijenata zbog propuštenih poziva',
        'Rezervacije se šalju direktno u vašu aplikaciju za osoblje, tako da ne morate puno raditi'
    ],
    staffFeatureTitle: 'Web aplikacija za osoblje koju će vaš tim zaista voljeti',
    staffFeatureDesc: 'Nije potrebno preuzimanje – samo se prijavite s telefona, tableta ili računara.',
    staffFeaturePoints: [
        'Pregled cijelog dnevnog rasporeda na prvi pogled – nema više papirnih kalendara ili zabilješki',
        'Svaka nova rezervacija (s web stranice, Googlea ili od klijenata koji dođu) pojavljuje se trenutno i automatski',
        'Jednostavan kreator termina: vaše osoblje može rezervisati klijente u sekundama kada neko nazove ili uđe',
        'Sve digitalno, sve automatski, nula haosa.'
    ],
    smsFeatureTitle: 'Automatske SMS poruke koje klijenti vole (i koje štite vaš prihod)',
    smsFeatureDesc: 'Pametne, prijateljske poruke poslane tačno kada je potrebno:',
    smsFeaturePoints: [
        'Verifikacijski SMS zaustavlja lažne rezervacije',
        'Trenutna potvrda sa svim detaljima',
        'SMS o promjeni i otkazivanju klijenti ostaju informisani ako se planovi promijene',
        'SMS podsjetnik tako da klijenti nikada ne zaborave',
        'SMS poruke otvara skoro svako mnogo efikasnije od emaila.',
        'Sve SMS poruke su u potpunosti uključene u vašu pretplatu.',
        'Nema dodatnih troškova po poruci, nema ograničenja, ništa skriveno.',
        'Svaki tekst se može prilagoditi da zvuči baš kao vi.'
    ],
    pricingTitle: 'Jednostavna, transparentna cijena',
    pricingDesc: 'Jedan plan, sve uključeno.',
    price: '45 BAM',
    pricePer: '/ mjesečno',
    priceVat: '(sa uključenim PDV-om 17%)',
    priceBase: 'Za do 3 zaposlena',
    priceExtra: 'Svaki dodatni zaposleni košta 15 BAM mjesečno.',
    cancelAnytime: 'Otkažite bilo kada',
    noSetupFees: 'Bez naknade za postavljanje',
    noHiddenCosts: 'Bez skrivenih troškova',
    footerCompany: 'Kompanija',
    footerContact: 'Kontakt',
    footerDevelopedBy: 'by Sigma Development',
    footerRights: 'Sva prava zadržana.',
    footerLegal: 'Pravno',
    footerPrivacy: 'Politika privatnosti',
    footerTerms: 'Uslovi korištenja',
    footerTagline: 'Pametno upravljanje redovima i rezervacijama',
    marqueePoints: [
      "Pridobijte više klijenata",
      "Manje se oslanjajte na telefonske pozive",
      "Pojavite se na Google mapama",
      "Omogućite klijentima rezervaciju 24/7",
      "Smanjite broj nedolazaka",
      "Dobijte potpunu SMS uslugu",
      "Učinite osoblje sretnijim",
      "Jedna jasna cijena",
      "Sve ovo za 45 BAM mjesečno"
    ]
  },
  da: {
    navFeatures: 'Funktioner',
    navPricing: 'Priser',
    navGoogle: 'Google Business',
    navContact: 'Kontakt',
    navStaffApp: 'Personale App',
    getStarted: 'Start',
    heroTitle: 'Et planlægningssystem, der hjælper dig med at tjene mere og arbejde mindre',
    heroSubtitle: 'Vores platform giver din serviceforretning et komplet professionelt planlægningssystem. Kunder booker selv online 24/7 → hver aftale vises øjeblikkeligt i din personales kalender. Nul telefonfis. Nul dobbeltbookinger. Timer sparet hver eneste uge. Perfekt til saloner, skønhedsklinikker, fitnesscentre, autoværksteder, rengøringsfirmaer og mere.',
    googleFeatureTitle: 'Bliv fundet på Google – omdan søgninger til bookinger',
    googleFeatureDesc: 'Vi administrerer din Google Business-profil for dig uden ekstra omkostninger – alt er inkluderet i dit abonnement.',
     googleFeaturePoints: [
        'Din virksomhed vises korrekt på Google Søgning og Maps',
        'Vi tilføjer dine ydelser, billeder, åbningstider og en professionel bookingknap',
        'Kunder ser din profil, trykker et par gange og booker direkte i din kalender',
        'Alt håndteret af os, alt inkluderet i den ene simple pris.'
    ],
    bookingFeatureTitle: 'Online booking der virker 24/7',
    bookingFeatureDesc: 'Giv dine kunder en smuk, mobilvenlig bookingside med dit logo og farver.',
    bookingFeaturePoints: [
        'De vælger den service, medarbejder og tid, der passer dem – når som helst, dag eller nat',
        'Ikke flere frem og tilbage beskeder eller tabte kunder på grund af ubesvarede opkald',
        'Bookinger sendes direkte til din Personale app, så du ikke behøver at gøre meget'
    ],
    staffFeatureTitle: 'Personale-webapp, dit team rent faktisk vil elske',
    staffFeatureDesc: 'Ingen downloads nødvendige – bare log ind fra telefon, tablet eller computer.',
    staffFeaturePoints: [
        'Hele dagens tidsplan på et øjeblik – ikke flere papirkalendere eller krusedullede noter',
        'Hver ny booking (fra hjemmesiden, Google eller walk-ins) vises øjeblikkeligt og automatisk',
        'Nem aftaleopretter: dit personale kan booke kunder på sekunder, når nogen ringer eller kommer ind',
        'Alt digitalt, alt automatisk, nul kaos.'
    ],
    smsFeatureTitle: 'Automatiske SMS-beskeder som kunder elsker (og som beskytter din indkomst)',
    smsFeatureDesc: 'Smarte, venlige beskeder sendt præcis, når det er nødvendigt:',
    smsFeaturePoints: [
        'Verifikations-SMS – stopper falske bookinger',
        'Øjeblikkelig bekræftelse med alle detaljer',
        'Ombooking & Aflysning SMS – kunder holdes informeret, hvis planer ændres',
        'Påmindelses-SMS så kunderne aldrig glemmer',
        'SMS åbnes af næsten alle – meget mere effektivt end e-mail.',
        'Alle SMS-beskeder er fuldt inkluderet i dit abonnement.',
        'Ingen ekstra omkostninger pr. besked, ingen grænser, intet skjult.',
        'Hver tekst kan tilpasses, så den lyder præcis som dig.'
    ],
    pricingTitle: 'Én simpel pris, ingen overraskelser',
    pricingDesc: 'Én plan, alt inkluderet.',
    price: '249 DKK',
    pricePer: '/ måned',
    priceVat: '(inkl. 25% MOMS)',
    priceBase: 'For op til 3 medarbejdere',
    priceExtra: 'Hver ekstra medarbejder koster kun 69 DKK/måned.',
    cancelAnytime: 'Annuller når som helst',
    noSetupFees: 'Ingen oprettelsesgebyrer',
    noHiddenCosts: 'Ingen skjulte omkostninger',
    footerCompany: 'Firma',
    footerContact: 'Kontakt',
    footerDevelopedBy: 'by Sigma Development',
    footerRights: 'Alle rettigheder forbeholdes.',
    footerLegal: 'Juridisk',
    footerPrivacy: 'Privatlivspolitik',
    footerTerms: 'Servicevilkår',
    footerTagline: 'Smart køstyring og booking',
    marqueePoints: [
      "Få flere kunder",
      "Vær mindre afhængig af telefonopkald",
      "Bliv fundet på Google Maps",
      "Tillad kundebooking 24/7",
      "Få færre udeblivelser",
      "Få fuld SMS-service",
      "Få gladere medarbejdere",
      "Én klar pris",
      "Få alt dette for 249 kr. om måneden"
    ]
  }
};

const FeatureSection = ({ title, description, points, image, imagePosition = 'right' }: { title: string, description: string, points: string[], image: string | string[], imagePosition?: 'left' | 'right' }) => {
    const plugin = React.useRef(
        Autoplay({ delay: 2000, stopOnInteraction: true })
    )
    
    return (
    <div className="container py-16 md:py-20">
        <div className={cn("grid md:grid-cols-2 gap-12 items-center", imagePosition === 'left' && 'md:[&>*:last-child]:-order-1')}>
            <div>
                <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
                <p className="mt-4 text-muted-foreground">{description}</p>
                <ul className="mt-6 space-y-3">
                    {points.map((point, index) => (
                        <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
                            <span className="text-muted-foreground" dangerouslySetInnerHTML={{ __html: point.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                        </li>
                    ))}
                </ul>
            </div>
            <div className="relative aspect-[4/3] mt-8 md:mt-0">
               {Array.isArray(image) ? (
                    <Carousel
                        plugins={[plugin.current]}
                        className="w-full"
                        onMouseEnter={plugin.current.stop}
                        onMouseLeave={plugin.current.reset}
                    >
                        <CarouselContent>
                            {image.map((src, index) => (
                            <CarouselItem key={index}>
                                <div className="relative aspect-[4/3]">
                                     <Image 
                                        src={src}
                                        alt={`${title} - screenshot ${index + 1}`}
                                        fill 
                                        className="rounded-lg object-cover object-top shadow-lg"
                                        data-ai-hint="application interface"
                                    />
                                </div>
                            </CarouselItem>
                            ))}
                        </CarouselContent>
                        <CarouselPrevious className="left-4" />
                        <CarouselNext className="right-4"/>
                    </Carousel>
                ) : (
                    <Image 
                        src={image}
                        alt={title}
                        fill 
                        className="rounded-lg object-cover object-top shadow-lg"
                        data-ai-hint="application interface"
                        priority
                    />
                )}
            </div>
        </div>
    </div>
)};


export default function Home() {
  const [privacyModalOpen, setPrivacyModalOpen] = React.useState(false);
  const [termsModalOpen, setTermsModalOpen] = React.useState(false);
  const [language, setLanguage] = React.useState<'en' | 'bs' | 'da'>('bs');
  const [globalSettings, setGlobalSettings] = React.useState<any>({});
  const [loadingSettings, setLoadingSettings] = React.useState(true);
  const [currentYear, setCurrentYear] = React.useState<number | null>(null);

  React.useEffect(() => {
    // This effect runs only on the client, preventing hydration mismatch.
    setCurrentYear(new Date().getFullYear());
    
    async function fetchSettings() {
        setLoadingSettings(true);
        const settings = await getGlobalSettings();
        setGlobalSettings(settings.general || {});
        setLoadingSettings(false);
    }
    
    // Set language from browser preference on initial load
    const browserLang = navigator.language.split('-')[0];
    if (browserLang === 'da') setLanguage('da');
    else if (browserLang === 'bs' || browserLang === 'hr' || browserLang === 'sr') setLanguage('bs');
    else setLanguage('en');

    fetchSettings();
  }, []);

  const t = translations[language];
  const appName = globalSettings.appName || 'QueuePilot';
  const appLogoUrl = globalSettings.appLogoUrl;
  const appVersion = globalSettings.appVersion || '1.4.0';

  const features = [
    { title: t.bookingFeatureTitle, description: t.bookingFeatureDesc, points: t.bookingFeaturePoints, image: "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764867915131_Screenshot%202025-12-04%20at%2017.webp?alt=media&token=07ba3908-cfb7-4150-8d5b-d6a2f51dc21d", imagePosition: 'left' as const },
    { title: t.staffFeatureTitle, description: t.staffFeatureDesc, points: t.staffFeaturePoints, image: [
        "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866564995_Screenshot%202025-12-04%20at%2017.webp?alt=media&token=2b524c34-f4a7-4ec6-93d1-ad3318eaa38c",
        "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866563553_2.webp?alt=media&token=dca29646-c511-4120-8207-8e121e798d3b",
        "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866562217_3.webp?alt=media&token=920e0185-f635-4a9b-a86c-6e80cbb79d5d",
        "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866561019_4.webp?alt=media&token=fc6b96b7-b781-4489-9104-eb2f0625cfcb",
        "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866557858_5.webp?alt=media&token=cc77dd91-c6b7-4f86-8897-58fa53d5c257"
      ]},
    { title: t.smsFeatureTitle, description: t.smsFeatureDesc, points: t.smsFeaturePoints, image: "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764871666852_Frame%202.webp?alt=media&token=f7f27788-5baa-46b5-b9bf-2d43cd1ef954", imagePosition: 'left' as const },
    { title: t.googleFeatureTitle, description: t.googleFeatureDesc, points: t.googleFeaturePoints, image: "https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764869142935_Frame%201.webp?alt=media&token=422ebbdf-5b36-4e3e-944b-bfdaa5281da"},
  ];
  
  const marqueeContent = t.marqueePoints.map((point, i) => (
    <span key={i} className="flex items-center" style={{ marginRight: '120px' }}>
      <CheckCircle className="h-4 w-4 mr-2" />
      {point}
    </span>
  ));

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PrivacyPolicyModal open={privacyModalOpen} onOpenChange={setPrivacyModalOpen} />
      <TermsOfServiceModal open={termsModalOpen} onOpenChange={setTermsModalOpen} />

      <div className="bg-primary text-primary-foreground py-2 text-sm overflow-hidden whitespace-nowrap">
        <div className="flex animate-marquee hover:[animation-play-state:paused]">
            <div className="flex shrink-0 items-center">{marqueeContent}</div>
            <div className="flex shrink-0 items-center" aria-hidden="true">{marqueeContent}</div>
        </div>
      </div>

      <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-20 items-center justify-between">
          <div className="flex items-center">
             <Link href="/" className="relative flex items-center h-10 w-36">
                {loadingSettings ? (
                    <Skeleton className="h-full w-full" />
                ) : appLogoUrl ? (
                    <Image src={appLogoUrl ?? ''} alt={`${appName} logo`} fill className="object-contain object-left" unoptimized />
                ) : (
                    <span className="text-xl font-bold">{appName}</span>
                )}
            </Link>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button asChild variant="ghost" className="hidden md:inline-flex">
                <a href="tel:+38761189860">
                    <Phone className="mr-2 h-4 w-4" />
                    +387 61 189 860
                </a>
            </Button>
            <Button asChild variant="outline">
                <Link href="/staff/login">{t.navStaffApp}</Link>
            </Button>
            <Button asChild>
                <Link href="/order">{t.getStarted}</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="bg-muted/50 border-b">
          <div className="container py-20 md:py-28">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6 text-center md:text-left">
                <h1 className="text-3xl md:text-4xl font-bold tracking-tighter">
                  {t.heroTitle}
                </h1>
                <p className="max-w-xl text-muted-foreground text-lg mx-auto md:mx-0">
                  {t.heroSubtitle.replace('Our platform', appName)}
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                  <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                    <Link href="/order">{t.getStarted} <ArrowRight className="ml-2 h-5 w-5" /></Link>
                  </Button>
                </div>
              </div>
              <div className="relative h-64 md:h-auto md:aspect-[4/3]">
                <Image 
                  src="https://firebasestorage.googleapis.com/v0/b/queuepilot-hmh2j.firebasestorage.app/o/media%2F1764866555267_1.webp?alt=media&token=0c73f0eb-b70d-4cbf-bf5c-589c683712bc" 
                  alt="Scheduling system interface" 
                  fill 
                  className="rounded-lg object-cover object-top shadow-xl"
                  data-ai-hint="scheduling system interface"
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="divide-y border-y">
            {features.map((feature, index) => (
              <FeatureSection key={feature.title} {...feature} imagePosition={index % 2 === 1 ? 'left' : 'right'} />
            ))}
        </section>
        
        <section id="pricing" className="py-20 md:py-28 bg-muted/50">
            <div className="container max-w-4xl mx-auto text-center">
                <h2 className="text-3xl md:text-4xl font-bold">{t.pricingTitle}</h2>
                 <Card className="max-w-sm mx-auto mt-8 text-left shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-center">
                            <span className="text-4xl font-bold">{t.price}</span>
                            <span className="text-lg text-muted-foreground">{t.pricePer}</span>
                        </CardTitle>
                        <CardDescription className="text-center">{t.priceVat}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Separator />
                        <ul className="space-y-3 text-sm">
                           <li className="flex items-center gap-3">
                                <CheckCircle className="h-5 w-5 text-primary" />
                                <span>{t.priceBase}</span>
                            </li>
                             <li className="flex items-center gap-3">
                                <CheckCircle className="h-5 w-5 text-primary" />
                                <span>{t.priceExtra}</span>
                            </li>
                             <li className="flex items-center gap-3">
                                <CheckCircle className="h-5 w-5 text-green-500" />
                                <span>{t.cancelAnytime}</span>
                            </li>
                             <li className="flex items-center gap-3">
                                <CheckCircle className="h-5 w-5 text-green-500" />
                                <span>{t.noSetupFees}</span>
                            </li>
                            <li className="flex items-center gap-3">
                                <CheckCircle className="h-5 w-5 text-green-500" />
                                <span>{t.noHiddenCosts}</span>
                            </li>
                        </ul>
                        <Button asChild size="lg" className="w-full">
                            <Link href="/order">{t.getStarted}</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </section>

      </main>

      <footer className="bg-card text-card-foreground border-t">
        <div className="container py-12 px-4 md:px-8">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                <div className="col-span-2 md:col-span-1">
                     <Link href="/" className="relative flex items-center h-10 w-36">
                        {loadingSettings ? (
                            <Skeleton className="h-full w-full" />
                        ) : appLogoUrl ? (
                            <Image src={appLogoUrl ?? ''} alt={`${appName} logo`} fill className="object-contain object-left" unoptimized />
                        ) : (
                            <span className="text-xl font-bold">{appName}</span>
                        )}
                    </Link>
                    <p className="mt-4 text-xs text-muted-foreground">{t.footerDevelopedBy}</p>
                </div>
                <div>
                    <h4 className="font-semibold text-foreground tracking-wider uppercase">{t.footerCompany}</h4>
                    <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                        <li>Sigma Development</li>
                        <li>Alije izetbegovica 35</li>
                        <li>72240 Kakanj</li>
                        <li>Bosnia & Herzegovina</li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-semibold text-foreground tracking-wider uppercase">{t.footerContact}</h4>
                    <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                        <li><a href="tel:+38761189860" className="hover:text-primary transition-colors">+387 61 189 860</a></li>
                        <li><a href="mailto:mail@dovo.ba" className="hover:text-primary transition-colors">mail@dovo.ba</a></li>
                    </ul>
                </div>
            </div>
            <Separator className="my-8" />
            <div className="flex flex-col-reverse md:flex-row items-center justify-between gap-4 text-center md:text-left">
                <p className="text-xs text-muted-foreground">&copy; {currentYear || new Date().getFullYear()} {appName}. {t.footerRights}</p>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">
                            <span className="text-xl">{language === 'bs' ? '🇧🇦' : language === 'da' ? '🇩🇰' : '🇬🇧'}</span>
                            <span className="ml-2">{language === 'bs' ? 'Bosanski' : language === 'da' ? 'Dansk' : 'English'}</span>
                            <ChevronDown className="ml-2 h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setLanguage('en')}>
                            <span className="mr-2 text-xl">🇬🇧</span> English
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setLanguage('bs')}>
                            <span className="mr-2 text-xl">🇧🇦</span> Bosnian
                        </DropdownMenuItem>
                         <DropdownMenuItem onClick={() => setLanguage('da')}>
                            <span className="mr-2 text-xl">🇩🇰</span> Danish
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </div>
      </footer>
    </div>
  );
}

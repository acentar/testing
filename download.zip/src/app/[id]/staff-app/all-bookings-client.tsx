
'use client';

import * as React from 'react';
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { ArrowUpDown, ChevronDown, MoreHorizontal, XCircle, Undo2 } from "lucide-react"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { addMinutes, format, formatDistanceStrict, parse, parseISO, type Locale } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from '@/lib/utils';
import { type AggregatedBooking } from '@/app/super-admin/businesses/[id]/types';
import { updateBookingStatus } from '@/app/[id]/client-app/actions';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useStaffScreen } from './staff-screen-context';
import { enUS, bs, da } from 'date-fns/locale';
import { useRouter } from 'next/navigation';

const translations = {
  en: {
    allBookings: "All bookings",
    allBookingsDesc: "A complete history of all bookings.",
    filterPlaceholder: "Filter by customer, service, staff...",
    columns: "Columns",
    previous: "Previous",
    next: "Next",
    noResults: "No results.",
    actionsFor: "Actions for",
    actionsDesc: "Select an action for the booking of \"{{serviceName}}\" at {{time}}.",
    cancelBooking: "Cancel booking",
    rescheduleBooking: "Reschedule booking",
    areYouSure: "Are you sure?",
    cancelBookingDesc: "This will cancel the booking for {{customerName}}. This action cannot be undone.",
    goBack: "Go back",
    yesCancel: "Yes, cancel",
    close: "Close",
    statusUpdated: "Booking status updated!",
    statusUpdatedDesc: "The booking has been marked as {{status}}.",
    error: "Error",
    errorUpdate: "Failed to update booking status.",
    customerService: "Customer & service",
    scheduled: "Scheduled",
    staff: "Staff",
    statusTimings: "Status & timings",
    booked: "Booked",
  },
  bs: {
    allBookings: "Sve rezervacije",
    allBookingsDesc: "Kompletna historija svih rezervacija.",
    filterPlaceholder: "Filtriraj po klijentu, usluzi, osoblju...",
    columns: "Kolone",
    previous: "Prethodna",
    next: "Sljedeća",
    noResults: "Nema rezultata.",
    actionsFor: "Akcije za",
    actionsDesc: "Odaberite akciju za rezervaciju \"{{serviceName}}\" u {{time}}.",
    cancelBooking: "Otkaži rezervaciju",
    rescheduleBooking: "Promijeni termin",
    areYouSure: "Jeste li sigurni?",
    cancelBookingDesc: "Ovo će otkazati rezervaciju za {{customerName}}. Ova radnja se ne može poništiti.",
    goBack: "Nazad",
    yesCancel: "Da, otkaži",
    close: "Zatvori",
    statusUpdated: "Status rezervacije ažuriran!",
    statusUpdatedDesc: "Rezervacija je označena kao {{status}}.",
    error: "Greška",
    errorUpdate: "Ažuriranje statusa rezervacije nije uspjelo.",
    customerService: "Klijent i usluga",
    scheduled: "Zakazano",
    staff: "Osoblje",
    statusTimings: "Status i vremena",
    booked: "Rezervisano",
  },
  da: {
    allBookings: "Alle bookinger",
    allBookingsDesc: "En komplet historik over alle bookinger.",
    filterPlaceholder: "Filtrer efter kunde, service, personale...",
    columns: "Kolonner",
    previous: "Forrige",
    next: "Næste",
    noResults: "Ingen resultater.",
    actionsFor: "Handlinger for",
    actionsDesc: "Vælg en handling for bookingen af \"{{serviceName}}\" kl. {{time}}.",
    cancelBooking: "Annuller booking",
    rescheduleBooking: "Ombook aftale",
    areYouSure: "Er du sikker?",
    cancelBookingDesc: "Dette vil annullere bookingen for {{customerName}}. Denne handling kan ikke fortrydes.",
    goBack: "Gå tilbage",
    yesCancel: "Ja, annuller",
    close: "Luk",
    statusUpdated: "Bookingstatus opdateret!",
    statusUpdatedDesc: "Bookingen er blevet markeret som {{status}}.",
    error: "Fejl",
    errorUpdate: "Kunne ikke opdatere bookingstatus.",
    customerService: "Kunde & service",
    scheduled: "Planlagt",
    staff: "Personale",
    statusTimings: "Status & tider",
    booked: "Booket",
  }
};

type Language = keyof typeof translations;

const statusVariantMap: Record<AggregatedBooking['status'], 'default' | 'secondary' | 'destructive'> = {
    'waiting': 'secondary',
    'in-progress': 'default',
    'completed': 'default',
    'cancelled': 'destructive',
};

const statusClassMap: Record<AggregatedBooking['status'], string> = {
    'waiting': 'bg-yellow-500/80',
    'in-progress': 'bg-blue-500/80',
    'completed': 'bg-green-600/80',
    'cancelled': '',
};


interface AllBookingsClientProps {
  initialData: AggregatedBooking[];
  businessId: string;
  onBookingUpdate: () => void;
  language: Language;
}


export function AllBookingsClient({ initialData, businessId, onBookingUpdate, language = 'bs' }: AllBookingsClientProps) {
  const [data, setData] = React.useState(initialData);
  const [sorting, setSorting] = React.useState<SortingState>([{ id: 'dateTime', desc: true }]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({})
  const [globalFilter, setGlobalFilter] = React.useState('')
  const [actionsModalOpen, setActionsModalOpen] = React.useState(false);
  const [selectedBooking, setSelectedBooking] = React.useState<AggregatedBooking | null>(null);
  const { toast } = useToast();
  const { business } = useStaffScreen();
  const t = translations[language] || translations.bs;
  const locale: Locale = language === 'da' ? da : language === 'en' ? enUS : bs;
  const router = useRouter();

  const statusTranslations = React.useMemo(() => ({
    en: { 'waiting': 'Waiting', 'in-progress': 'In progress', 'completed': 'Completed', 'cancelled': 'Cancelled' },
    bs: { 'waiting': 'Čekanje', 'in-progress': 'U toku', 'completed': 'Završeno', 'cancelled': 'Otkazano' },
    da: { 'waiting': 'Venter', 'in-progress': 'I gang', 'completed': 'Fuldført', 'cancelled': 'Annulleret' },
  }), [language]);

  React.useEffect(() => {
    setData(initialData);
  }, [initialData]);

  const handleStatusChange = async (bookingId: string, staffId: string, status: 'cancelled') => {
    setActionsModalOpen(false);
    const result = await updateBookingStatus(businessId, bookingId, staffId, status);
    if (result.success) {
      toast({
        title: t.statusUpdated,
        description: t.statusUpdatedDesc.replace('{{status}}', statusTranslations[language][status] || status),
      });
      onBookingUpdate();
    } else {
      toast({
        variant: 'destructive',
        title: t.error,
        description: result.error || t.errorUpdate,
      });
    }
  };
  
  const openRescheduleDialog = (booking: AggregatedBooking) => {
    const query = new URLSearchParams({ booking: JSON.stringify(booking) }).toString();
    router.push(`/${business.id}/staff-app/schedule?${query}`);
    setActionsModalOpen(false);
  }

  const columns: ColumnDef<AggregatedBooking>[] = [
    {
      accessorKey: "customerName",
      header: t.customerService,
      cell: ({ row }) => (
          <div className="text-lg">
              <div>{row.original.customerName}</div>
              <div className="text-base text-muted-foreground">{row.original.serviceName}</div>
              <div className="text-sm text-muted-foreground">{row.original.customerPhone}</div>
          </div>
      )
    },
    {
      accessorKey: "dateTime",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            {t.scheduled}
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        )
      },
      cell: ({ row }) => {
        const { date, time, totalDuration } = row.original;
        const startTime = parse(`${date} ${time}`, 'yyyy-MM-dd HH:mm', new Date());
        const endTime = addMinutes(startTime, totalDuration);
        return (
            <div className="text-base">
                <div>{format(startTime, 'dd MMM, yyyy', { locale })}</div>
                <div className="text-sm text-muted-foreground">
                    {format(startTime, 'HH:mm')} - {format(endTime, 'HH:mm')} ({totalDuration} min)
                </div>
            </div>
        )
      },
    },
    {
      accessorKey: "status",
      header: t.statusTimings,
      cell: ({ row }) => {
          const { status, createdAt } = row.original;
          const statusNode = (
            <Badge 
                variant={statusVariantMap[status] || 'secondary'} 
                className={cn('capitalize text-lg', statusClassMap[status])}
            >
                {statusTranslations[language][status] || status.replace('-', ' ')}
            </Badge>
          );

           if (createdAt) {
                const createdDate = typeof createdAt === 'number' ? new Date(createdAt) : parseISO(createdAt);
                return <div className="text-base flex flex-col items-start gap-1">
                    {statusNode}
                    <span className="text-sm text-muted-foreground">{t.booked} {format(createdDate, 'dd MMM, yyyy HH:mm', { locale })}</span>
                </div>
          }
          
          return statusNode;
      },
    },
    {
      accessorKey: "staffName",
      header: t.staff,
       cell: ({ row }) => <div className="text-lg">{row.getValue("staffName")}</div>,
    },
     {
      id: "actions",
      cell: ({ row }) => {
        const booking = row.original
        
        return (
            <Button variant="ghost" className="h-12 w-12 p-0" onClick={() => {
                setSelectedBooking(booking);
                setActionsModalOpen(true);
            }}>
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-6 w-6" />
            </Button>
        )
      },
    }
  ]

  const table = useReactTable({
    data: data,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onGlobalFilterChange: setGlobalFilter,
    globalFilterFn: (row, columnId, filterValue) => {
        const safeValue = (value: any) => String(value ?? '').toLowerCase();
        const customerName = safeValue(row.original.customerName);
        const serviceName = safeValue(row.original.serviceName);
        const staffName = safeValue(row.original.staffName);
        return customerName.includes(filterValue) || serviceName.includes(filterValue) || staffName.includes(filterValue);
    },
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      globalFilter
    },
  })


  return (
    <>
    <Card>
        <CardHeader>
             <CardTitle className="text-2xl">{t.allBookings}</CardTitle>
            <CardDescription>{t.allBookingsDesc}</CardDescription>
        </CardHeader>
      <CardContent>
        <div className="flex items-center py-4">
            <Input
            placeholder={t.filterPlaceholder}
            value={globalFilter}
            onChange={(event) => setGlobalFilter(event.target.value)}
            className="max-w-sm h-12 text-lg"
            />
            <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto h-12 text-lg">
                {t.columns} <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                {table
                .getAllColumns()
                .filter((column) => column.getCanHide())
                .map((column) => {
                    return (
                    <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                        column.toggleVisibility(!!value)
                        }
                    >
                        {column.id}
                    </DropdownMenuCheckboxItem>
                    )
                })}
            </DropdownMenuContent>
            </DropdownMenu>
        </div>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className="text-lg">
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center text-lg"
                >
                  {t.noResults}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
         <div className="flex items-center justify-end space-x-2 py-4">
            <Button
            variant="outline"
            size="lg"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
            >
            {t.previous}
            </Button>
            <Button
            variant="outline"
            size="lg"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
            >
            {t.next}
            </Button>
        </div>

        <Dialog open={actionsModalOpen} onOpenChange={setActionsModalOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{t.actionsFor} {selectedBooking?.customerName}</DialogTitle>
                    <DialogDescription>
                        {t.actionsDesc.replace('{{serviceName}}', selectedBooking?.serviceName || '').replace('{{time}}', selectedBooking?.time || '')}
                    </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                     <Button 
                        size="lg" 
                        className="h-16 text-xl"
                        variant="secondary"
                        onClick={() => openRescheduleDialog(selectedBooking!)}
                        disabled={!selectedBooking || selectedBooking.status === 'completed' || selectedBooking.status === 'cancelled'}
                    >
                        <Undo2 className="mr-2 h-6 w-6"/>
                        {t.rescheduleBooking}
                    </Button>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button size="lg" variant="destructive" className="h-16 text-xl">
                               <XCircle className="mr-2 h-6 w-6"/> {t.cancelBooking}
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                             <AlertDialogHeader>
                                <AlertDialogTitle>{t.areYouSure}</AlertDialogTitle>
                                <AlertDialogDescription>
                                    {t.cancelBookingDesc.replace('{{customerName}}', selectedBooking?.customerName || '')}
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>{t.goBack}</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleStatusChange(selectedBooking!.id, selectedBooking!.staffId, 'cancelled')} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                                    {t.yesCancel}
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
                <DialogFooter>
                    <DialogClose asChild>
                        <Button type="button" variant="outline">
                            {t.close}
                        </Button>
                    </DialogClose>
                </DialogFooter>
            </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
    </>
  );
}

    
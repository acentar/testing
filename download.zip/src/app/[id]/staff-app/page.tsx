
'use client';

import * as React from 'react';
import { StaffScreenClient } from "./client";
import { useSearchParams } from 'next/navigation';
import SchedulePage from './schedule/page';

export default function StaffAppPage() {
    const searchParams = useSearchParams();
    const isScheduling = searchParams.has('booking');
    
    // This is a temporary check to see if the page should render the scheduling flow.
    // A more robust solution might use a different route.
    if (isScheduling) {
        return <SchedulePage />;
    }
    
    return (
        <StaffScreenClient />
    );
}

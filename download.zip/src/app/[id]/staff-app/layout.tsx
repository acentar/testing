
'use client';

import * as React from 'react';
import { StaffScreenProvider } from './staff-screen-context.tsx';

interface StaffAppLayoutProps {
    children: React.ReactNode;
}

export default function StaffAppLayout({ children }: StaffAppLayoutProps) {
    return (
        <StaffScreenProvider>
            {children}
        </StaffScreenProvider>
    );
}

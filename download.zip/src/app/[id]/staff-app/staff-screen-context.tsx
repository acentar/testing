
'use client';

import * as React from 'react';
import { type Business, getBusiness } from '@/app/super-admin/businesses/actions';
import { type Extension, type Service, type Category } from '@/app/super-admin/businesses/[id]/services/schema';
import { getServicesAndExtensions, getBusinessBookings, getBusinessCustomers } from '@/app/[id]/client-app/actions';
import { type Staff, getStaff as fetchStaff } from '@/app/super-admin/businesses/[id]/staff/actions';
import { type AggregatedBooking, type BusinessCustomer } from '@/app/super-admin/businesses/[id]/types';
import { useParams } from 'next/navigation';
import { onValue, ref } from 'firebase/database';
import { rtdb } from '@/lib/firebase';
import { Loader2 } from 'lucide-react';
import { AvailabilityProvider } from '@/app/[id]/client-app/providers';

interface StaffScreenContextType {
    business: Business;
    services: Service[];
    extensions: Extension[];
    categories: Category[];
    allStaff: Staff[];
    bookings: AggregatedBooking[];
    customers: BusinessCustomer[];
    refreshData: () => Promise<void>;
    loadingStaff: boolean;
}

const StaffScreenContext = React.createContext<StaffScreenContextType | null>(null);

export const useStaffScreen = () => {
    const context = React.useContext(StaffScreenContext);
    if (!context) {
        throw new Error("useStaffScreen must be used within a StaffScreenProvider");
    }
    return context;
};

interface StaffScreenProviderProps {
    children: React.ReactNode;
}

export function StaffScreenProvider({ children }: StaffScreenProviderProps) {
    const params = useParams();
    const businessId = params.id as string;
    
    const [business, setBusiness] = React.useState<Business | null>(null);
    const [bookings, setBookings] = React.useState<AggregatedBooking[]>([]);
    const [customers, setCustomers] = React.useState<BusinessCustomer[]>([]);
    const [services, setServices] = React.useState<Service[]>([]);
    const [extensions, setExtensions] = React.useState<Extension[]>([]);
    const [categories, setCategories] = React.useState<Category[]>([]);
    const [allStaff, setAllStaff] = React.useState<Staff[]>([]);
    const [loadingStaff, setLoadingStaff] = React.useState(true);


    const refreshData = React.useCallback(async () => {
        if (!businessId) return;
        setLoadingStaff(true);
        const businessData = await getBusiness(businessId);
        if (!businessData) {
            setLoadingStaff(false);
            return;
        };

        setBusiness(businessData);

        const [bookingsData, customersData, servicesAndExtensions, staffData] = await Promise.all([
            getBusinessBookings(businessId),
            getBusinessCustomers(businessId),
            getServicesAndExtensions(businessId),
            fetchStaff(businessId),
        ]);

        setBookings(bookingsData);
        setCustomers(customersData);
        setServices(servicesAndExtensions.services);
        setExtensions(servicesAndExtensions.extensions);
        setCategories(servicesAndExtensions.categories);
        setAllStaff(staffData);
        setLoadingStaff(false);
    }, [businessId]);

    React.useEffect(() => {
        refreshData();
    }, [refreshData]);

    React.useEffect(() => {
        if (!businessId) return;
        const scheduleLastUpdatedRef = ref(rtdb, `businesses/${businessId}/scheduleLastUpdated`);
        const unsubscribe = onValue(scheduleLastUpdatedRef, async () => {
            await refreshData();
        });

        return () => unsubscribe();
    }, [businessId, refreshData]);

    const providerValue = React.useMemo(() => ({
        business: business!,
        bookings,
        customers,
        services,
        extensions,
        categories,
        allStaff,
        refreshData,
        loadingStaff,
    }), [business, bookings, customers, services, extensions, categories, allStaff, refreshData, loadingStaff]);

    if (!business) {
        return <div className="h-screen w-full flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    return (
        <StaffScreenContext.Provider value={providerValue}>
            <AvailabilityProvider businessId={business.id}>
                {children}
            </AvailabilityProvider>
        </StaffScreenContext.Provider>
    );
};

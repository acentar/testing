
import { getBusinessBySlug, getBusiness } from "@/app/super-admin/businesses/actions";
import { type NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: businessIdOrSlug } = await params;
  let business = await getBusinessBySlug(businessIdOrSlug);
  if (!business) {
    business = await getBusiness(businessIdOrSlug);
  }


  if (!business || !business.enablePwa) {
    return new NextResponse("Not Found", { status: 404 });
  }

  const manifest = {
    name: `${business.businessName} - Staff App`,
    short_name: business.pwaShortName ? `${business.pwaShortName} Staff` : `${business.businessName} Staff`,
    description: `Staff application for ${business.businessName}.`,
    start_url: `/${businessIdOrSlug}/staff-app`,
    display: "standalone",
    background_color: business.pwaBackgroundColor || "#ffffff",
    theme_color: business.pwaThemeColor || "#000000",
    icons: [
      {
        src: business.pwaIcon192Url || "/icons/icon-192x192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: business.pwaIcon512Url || "/icons/icon-512x512.png",
        sizes: "512x512",
        type: "image/png",
      },
      business.pwaMaskableIconUrl ? {
        src: business.pwaMaskableIconUrl,
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      } : undefined,
    ].filter(Boolean),
  };

  return new NextResponse(JSON.stringify(manifest), {
    headers: {
      "Content-Type": "application/manifest+json",
    },
  });
}

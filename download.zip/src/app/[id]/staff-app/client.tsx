
'use client';

import * as React from 'react';
import Image from 'next/image';
import { rtdb } from '@/lib/firebase';
import { onValue, ref, onDisconnect, set } from 'firebase/database';
import { format, isToday, isTomorrow, parseISO, addMinutes, isAfter, parse, startOfMonth, endOfMonth, eachMonthOfInterval, startOfYear, endOfYear, isSameMonth, type Locale } from 'date-fns';
import { enUS, bs, da } from 'date-fns/locale';
import {
  Users,
  Clock,
  UserCheck,
  PlayCircle,
  CheckCircle2,
  XCircle,
  MoreVertical,
  LogIn,
  Eye,
  LogOut,
  ListOrdered,
  Loader2,
  LayoutDashboard,
  Book,
  Contact,
  Activity,
  PlusCircle,
  Menu,
  Bell,
  KeyRound,
  Undo2,
  Calendar as CalendarIcon,
  Download,
  PartyPopper,
  Search,
  Phone,
  Share2,
  ExternalLink,
  MessageCircle,
  Mail,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Settings,
  Scissors,
  Trash2,
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { updateBookingStatus, sendYourTurnSoonSms, deleteBooking } from '@/app/[id]/client-app/actions';
import { useToast } from '@/hooks/use-toast';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { type AggregatedBooking } from '@/app/super-admin/businesses/[id]/types';
import { useStaffScreen } from './staff-screen-context.tsx';
import { logout } from '@/app/staff/login/actions';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { getGlobalSettings } from '@/app/super-admin/settings/actions';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { StaffKioskUser } from '@/app/super-admin/businesses/new/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const translations = {
  en: {
    dashboard: "Dashboard",
    appointment: "Appointment",
    staffDashboard: "Staff dashboard",
    todaysAppointments: "Today's Appointments",
    noAppointmentsToday: "No appointments scheduled for today.",
    with: "with",
    notify: "Notify",
    notified: "Notified",
    rescheduleBooking: "Reschedule",
    cancelBooking: "Cancel booking",
    deleteBooking: "Delete Booking",
    areYouSure: "Are you sure?",
    cancelBookingDesc: "This will cancel the booking for {{customerName}}. This action cannot be undone.",
    deleteBookingDesc: "This action is permanent and cannot be undone. The booking will be completely removed from the system.",
    goBack: "Go back",
    yesCancel: "Yes, cancel",
    notificationSent: "Notification sent!",
    notificationSentDesc: "The customer has been notified their turn is soon.",
    notificationError: "Notification error",
    notificationErrorDesc: "Failed to send the notification.",
    signOut: "Sign Out",
    installApp: "Install App",
    install: "Install",
    installPwaDescription: "Install the app for a better experience",
    welcome: "Welcome",
    whatsNew: "What's new?",
    newAppointmentsSince: "New appointments since your last visit.",
    noNewAppointments: "No new appointments since your last visit.",
    searchPlaceholder: "Search by customer name or phone...",
    awesome: "Awesome!",
    shareTitle: "Share your booking page",
    shareDesc: "Copy the link and send it to your customers.",
    copy: "Copy",
    copied: "Copied!",
    open: "Open",
    share: "Share",
    shareOnSocial: "Share on social media",
    close: "Close",
  },
  bs: {
    dashboard: "Kontrolna ploča",
    appointment: "Zakaži",
    staffDashboard: "Kontrolna ploča za osoblje",
    todaysAppointments: "Današnji termini",
    noAppointmentsToday: "Nema zakazanih termina za danas.",
    with: "kod",
    notify: "Obavijesti",
    notified: "Obaviješten",
    rescheduleBooking: "Promijeni termin",
    cancelBooking: "Otkaži rezervaciju",
    deleteBooking: "Obriši Rezervaciju",
    areYouSure: "Jeste li sigurni?",
    cancelBookingDesc: "Ovo će otkazati rezervaciju za {{customerName}}. Ova radnja se ne može poništiti.",
    deleteBookingDesc: "Ova radnja je trajna i ne može se poništiti. Rezervacija će biti potpuno uklonjena iz sistema.",
    goBack: "Nazad",
    yesCancel: "Da, otkaži",
    notificationSent: "Obavijest poslana!",
    notificationSentDesc: "Klijent je obaviješten da je uskoro na redu.",
    notificationError: "Greška pri obavještavanju",
    notificationErrorDesc: "Slanje obavijesti nije uspjelo.",
    signOut: "Odjavi se",
    installApp: "Instaliraj aplikaciju",
    install: "Instaliraj",
    installPwaDescription: "Instalirajte aplikaciju za bolje iskustvo",
    welcome: "Dobrodošli",
    whatsNew: "Šta ima novo?",
    newAppointmentsSince: "Novi termini od vaše posljednje posjete.",
    noNewAppointments: "Nema novih termina od vaše posljednje posjete.",
    searchPlaceholder: "Pretraži po imenu klijenta ili telefonu...",
    awesome: "Super!",
    shareTitle: "Podijelite stranicu za rezervacije",
    shareDesc: "Kopirajte link i pošaljite ga svojim klijentima.",
    copy: "Kopiraj",
    copied: "Kopirano!",
    open: "Otvori",
    share: "Podijeli",
    shareOnSocial: "Podijelite na društvenim mrežama",
    close: "Zatvori",
  },
  da: {
    dashboard: "Dashboard",
    appointment: "Planlæg",
    staffDashboard: "Personale dashboard",
    todaysAppointments: "Dagens aftaler",
    noAppointmentsToday: "Ingen aftaler planlagt for i dag.",
    with: "med",
    notify: "Giv besked",
    notified: "Besked sendt",
    rescheduleBooking: "Ombook aftale",
    cancelBooking: "Annuller booking",
    deleteBooking: "Slet booking",
    areYouSure: "Er du sikker?",
    cancelBookingDesc: "Dette vil annullere bookingen for {{customerName}}. Handlingen kan ikke fortrydes.",
    deleteBookingDesc: "Denne handling er permanent og kan ikke fortrydes. Bookingen vil blive fjernet helt fra systemet.",
    goBack: "Tilbage",
    yesCancel: "Ja, annuller",
    notificationSent: "Besked sendt!",
    notificationSentDesc: "Kunden er blevet underrettet om, at det snart er deres tur.",
    notificationError: "Fejl ved afsendelse af besked",
    notificationErrorDesc: "Kunne ikke sende beskeden.",
    signOut: "Log ud",
    installApp: "Installer App",
    install: "Installer",
    installPwaDescription: "Installer appen for en bedre oplevelse",
    welcome: "Velkommen",
    whatsNew: "Hvad er nyt?",
    newAppointmentsSince: "Nye aftaler siden dit sidste besøg.",
    noNewAppointments: "Ingen nye aftaler siden dit sidste besøg.",
    searchPlaceholder: "Søg efter kundenavn eller telefon...",
    awesome: "Fedt!",
    shareTitle: "Del din booking-side",
    shareDesc: "Kopier linket og send det til dine kunder.",
    copy: "Kopier",
    copied: "Kopieret!",
    open: "Åbn",
    share: "Del",
    shareOnSocial: "Del på sociale medier",
    close: "Luk",
  }
};


interface StaffScreenClientProps {
  children?: React.ReactNode;
}

function PwaInstallBanner({ business, language }: { business: any, language: 'en' | 'bs' | 'da' }) {
    const [installPrompt, setInstallPrompt] = React.useState<any>(null);
    const t = translations[language] || translations.bs;

    React.useEffect(() => {
        const handleBeforeInstallPrompt = (e: Event) => {
            e.preventDefault();
            setInstallPrompt(e);
        };

        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        return () => {
            window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        };
    }, []);

    const handleInstallClick = () => {
        if (!installPrompt) return;
        installPrompt.prompt();
        installPrompt.userChoice.then(() => {
            setInstallPrompt(null);
        });
    };
    
    if (!installPrompt) return null;

    return (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-md z-50">
             <div className="bg-card p-3 rounded-lg shadow-2xl flex items-center gap-4 animate-in slide-in-from-bottom-10 fade-in-50">
                 <Image 
                    src={business.pwaIcon192Url || '/icons/icon-192x192.png'}
                    alt="App Icon"
                    width={48}
                    height={48}
                    className="rounded-lg"
                 />
                 <div className="flex-1">
                    <p className="font-bold text-sm">{business.pwaShortName || business.businessName}</p>
                    <p className="text-xs text-muted-foreground">{t.installPwaDescription}</p>
                 </div>
                 <Button onClick={handleInstallClick} size="sm">{t.install}</Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setInstallPrompt(null)}>
                    <XCircle className="h-4 w-4" />
                 </Button>
            </div>
        </div>
    )
}

type DynamicStatus = 'completed' | 'in-progress' | 'waiting' | 'cancelled';

export function StaffScreenClient() {
  const { business, bookings, loadingStaff, refreshData } = useStaffScreen();
  
  const [loading, setLoading] = React.useState(true);
  const [currentTime, setCurrentTime] = React.useState<Date | null>(null);
  const { toast } = useToast();
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [globalSettings, setGlobalSettings] = React.useState<any>({});
  const [staffFullName, setStaffFullName] = React.useState('');
  const [selectedBookingForModal, setSelectedBookingForModal] = React.useState<AggregatedBooking | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [whatsNewModalOpen, setWhatsNewModalOpen] = React.useState(false);
  const [newAppointments, setNewAppointments] = React.useState<AggregatedBooking[]>([]);
  const router = useRouter();
  
  const language: 'en' | 'bs' | 'da' = (business?.language as 'en' | 'bs' | 'da') || 'bs';
  const t = translations[language];
  const locale: Locale = language === 'da' ? da : language === 'en' ? enUS : bs;

  React.useEffect(() => {
    const name = sessionStorage.getItem('staffFullName');
    if (name) {
      setStaffFullName(name);
    }
    
    const justLoggedIn = sessionStorage.getItem('justLoggedIn') === 'true';
    if (justLoggedIn && business) {
        const lastVisited = localStorage.getItem(`lastVisited_${business.id}`);
        const newBookings = bookings.filter(booking => {
            const createdAt = (booking.createdAt && typeof booking.createdAt === 'string')
                ? parseISO(booking.createdAt).getTime()
                : (booking.createdAt || 0) as number;
            return lastVisited ? createdAt > parseInt(lastVisited, 10) : false;
        });

        if (newBookings.length > 0) {
            setNewAppointments(newBookings);
            setWhatsNewModalOpen(true);
        }
        sessionStorage.removeItem('justLoggedIn');
    }
    
    const handleUnload = () => {
        if(business) {
            localStorage.setItem(`lastVisited_${business.id}`, Date.now().toString());
        }
    };
    window.addEventListener('beforeunload', handleUnload);

    if (business) {
        const presenceRef = ref(rtdb, `presence/kiosk_${business.id}`);
        const disconnectRef = onDisconnect(presenceRef);
        set(presenceRef, {
            businessName: business.businessName,
            businessId: business.id,
            page: 'Staff Kiosk (I2)',
            timestamp: new Date().toISOString()
        });
        disconnectRef.remove();
        return () => {
            disconnectRef.cancel();
            window.removeEventListener('beforeunload', handleUnload);
        };
    }
  }, [business, bookings]);

  React.useEffect(() => {
    async function fetchInitialData() {
        const settings = await getGlobalSettings();
        setGlobalSettings(settings.general || {});
        setLoading(false);
    }
    fetchInitialData();
  }, []);

   React.useEffect(() => {
    setCurrentTime(new Date());
    const timer = setInterval(() => {
        setCurrentTime(new Date());
    }, 1000);
    
    return () => {
      clearInterval(timer);
    };
  }, []);
  
  const handleStatusChange = async (bookingId: string, staffId: string, status: 'cancelled') => {
    setModalOpen(false);
    const result = await updateBookingStatus(business.id, bookingId, staffId, status);
    if (!result.success) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: result.error || 'Failed to update booking status.',
      });
    } else {
      toast({
        title: 'Status updated!',
        description: `Booking marked as ${status}`,
      });
    }
  };
  
  const handleDeleteBooking = async (booking: AggregatedBooking) => {
    setModalOpen(false);
    const result = await deleteBooking(business.id, booking.staffId, booking.id);
    if (result.success) {
      toast({
        title: "Booking Deleted",
        description: "The appointment has been permanently removed.",
      });
    } else {
       toast({
        variant: 'destructive',
        title: "Error",
        description: result.error || "Failed to delete booking.",
      });
    }
  }

  const openRescheduleDialog = (booking: AggregatedBooking) => {
    const query = new URLSearchParams({ booking: JSON.stringify(booking) }).toString();
    router.push(`/${business.id}/staff-app/schedule?${query}`);
  };

  const handleNotify = async (bookingId: string, staffId: string) => {
    setModalOpen(false);
    const result = await sendYourTurnSoonSms(business.id, bookingId, staffId);
    if (result.success) {
      toast({
        title: t.notificationSent,
        description: t.notificationSentDesc,
      });
    } else {
      toast({
        variant: "destructive",
        title: t.notificationError,
        description: result.error || t.notificationErrorDesc,
      });
    }
    setLoading(false);
  };
  
  const getDynamicStatus = (booking: AggregatedBooking): DynamicStatus => {
    if (booking.status === 'cancelled') return 'cancelled';
    if (!currentTime) return 'waiting';

    const startTime = parse(`${booking.date} ${booking.time}`, 'yyyy-MM-dd HH:mm', new Date());
    const endTime = addMinutes(startTime, booking.totalDuration);

    if (isAfter(currentTime, endTime)) return 'completed';
    if (isAfter(currentTime, startTime) && !isAfter(currentTime, endTime)) return 'in-progress';

    return 'waiting';
  };

  const handleSignOut = async () => {
    await logout();
    router.push('/staff/login');
  };

  const handleMenuAction = (action: 'schedule' | 'signout') => {
    setMenuOpen(false);
    if (action === 'schedule') {
        router.push(`/${business.id}/staff-app/schedule`);
    } else if (action === 'signout') {
        handleSignOut();
    }
  }
    
  const bookingPageUrl = business.slug ? `${window.location.origin}/${business.slug}` : `${window.location.origin}/${business.id}`;
  const [copied, setCopied] = React.useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(bookingPageUrl).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    });
  };

  const filteredBookings = React.useMemo(() => {
    let filtered = bookings;
  
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(booking =>
        booking.customerName.toLowerCase().includes(term) ||
        booking.customerPhone.toLowerCase().includes(term)
      );
    }
  
    return filtered;
  }, [bookings, searchTerm]);

  const todaysBookings = filteredBookings.filter(b => isToday(parseISO(b.date)));
  
  if (loadingStaff || !business) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  const renderAppointmentList = (appointments: AggregatedBooking[]) => {
    if (loading) {
        return (
            <div className="space-y-4">
                <Card><CardHeader><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-1/2 mt-1" /></CardHeader></Card>
                <Card><CardHeader><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-1/2 mt-1" /></CardHeader></Card>
                <Card><CardHeader><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-1/2 mt-1" /></CardHeader></Card>
            </div>
        )
    }

    if (appointments.length === 0) {
      return (
        <div className="text-center py-12 text-muted-foreground">
          <p>{t.noAppointmentsToday}</p>
        </div>
      );
    }
    
    return (
        <div className="space-y-4">
            {appointments.sort((a,b) => a.time.localeCompare(b.time)).map(booking => {
              const dynamicStatus = getDynamicStatus(booking);
              const startTime = parse(`${booking.date} ${booking.time}`, 'yyyy-MM-dd HH:mm', new Date());
              const endTime = format(addMinutes(startTime, booking.totalDuration), 'HH:mm');

              return (
                <div 
                    key={booking.id} 
                    className={cn(
                        'overflow-hidden border rounded-lg relative p-4 transition-all duration-200 cursor-pointer hover:shadow-md hover:border-primary/50',
                        dynamicStatus === 'in-progress' && 'bg-blue-500/10 border-blue-500/30',
                        dynamicStatus === 'waiting' && 'bg-background',
                        dynamicStatus === 'completed' && 'opacity-50 bg-gray-500/10',
                        dynamicStatus === 'cancelled' && 'opacity-50 bg-red-500/10',
                    )}
                    onClick={() => {
                        setSelectedBookingForModal(booking);
                        setModalOpen(true);
                    }}
                >
                    <div className="flex items-center gap-4">
                         <div className="flex flex-col items-center justify-center bg-muted/50 rounded-md p-2 w-16">
                            <span className="font-bold text-lg leading-none">{booking.time}</span>
                            <span className="text-xs text-muted-foreground leading-none">{endTime}</span>
                        </div>
                        <div className="flex-1">
                             <p className="font-bold text-md">{booking.customerName} {t.with} {booking.staffName}</p>
                             <p className="text-sm text-muted-foreground">{booking.serviceName}</p>
                        </div>
                    </div>
                </div>
            )})}
        </div>
    );
  }

  const renderDashboardView = () => {
    return (
      <div className="space-y-4">
          <div className="space-y-4 mb-6">
              <div className="grid grid-cols-1 gap-4">
                  <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input
                          placeholder={t.searchPlaceholder}
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 h-10"
                      />
                  </div>
              </div>
          </div>
          {renderAppointmentList(todaysBookings)}
      </div>
    )
  }
  
  const users = business.staffKioskUsers ? Object.values(business.staffKioskUsers) as StaffKioskUser[] : [];
  const staffUser = users.find(u => u.fullName === staffFullName);

  return (
    <>
      <div className="bg-muted/40 min-h-screen">
        <header className="bg-background shadow-sm sticky top-0 z-40">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-2">
                  <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
                      <SheetTrigger asChild>
                          <Button variant="secondary" size="icon" className="h-10 w-10">
                              <Menu className="h-5 w-5"/>
                          </Button>
                      </SheetTrigger>
                      <SheetContent side="left" className="p-0 sm:max-w-xs w-full flex flex-col">
                          <SheetHeader className="p-4 pb-0">
                                <SheetTitle className="sr-only">Menu</SheetTitle>
                          </SheetHeader>
                          <div className="flex flex-col h-full py-4 space-y-4">
                                <div className="px-4">
                                    <p className="font-semibold text-lg">{staffFullName}</p>
                                    <p className="text-sm text-muted-foreground">{staffUser?.phone}</p>
                                </div>
                                <div className="flex-1 space-y-1 px-2">
                                     <Button variant="ghost" size="lg" className="h-12 text-base md:text-lg justify-start w-full" asChild>
                                        <div onClick={() => setMenuOpen(false)}>
                                            <LayoutDashboard className="mr-4 h-5 w-5" /> {t.dashboard}
                                        </div>
                                    </Button>
                                </div>
                                <div className="mt-auto px-4 pb-2 space-y-4">
                                    <div className="bg-muted/80 p-3 rounded-lg text-center space-y-2">
                                        <h4 className="font-semibold text-sm">{t.shareTitle}</h4>
                                        <p className="text-xs text-muted-foreground">{t.shareDesc}</p>
                                        <div className="flex gap-2">
                                            <Input
                                                readOnly
                                                value={bookingPageUrl}
                                                className="h-8 text-xs bg-background"
                                            />
                                            <Button size="sm" className="h-8" onClick={copyToClipboard}>
                                                {copied ? t.copied : t.copy}
                                            </Button>
                                             <Dialog>
                                                <DialogTrigger asChild>
                                                     <Button size="icon" className="h-8 w-8" variant="secondary">
                                                        <Share2 className="h-4 w-4" />
                                                    </Button>
                                                </DialogTrigger>
                                                <DialogContent className="sm:max-w-md">
                                                    <DialogHeader>
                                                        <DialogTitle>{t.shareOnSocial}</DialogTitle>
                                                    </DialogHeader>
                                                    <div className="grid grid-cols-2 gap-4 py-4">
                                                        <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`https://wa.me/?text=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <MessageCircle className="mr-2 h-6 w-6"/> WhatsApp
                                                            </a>
                                                        </Button>
                                                         <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`mailto:?subject=${encodeURIComponent('Check out our booking page!')}&body=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <Mail className="mr-2 h-6 w-6"/> Email
                                                            </a>
                                                        </Button>
                                                         <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <Facebook className="mr-2 h-6 w-6"/> Facebook
                                                            </a>
                                                        </Button>
                                                         <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`fb-messenger://share?link=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <MessageCircle className="mr-2 h-6 w-6"/> Messenger
                                                            </a>
                                                        </Button>
                                                        <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(bookingPageUrl)}&text=${encodeURIComponent('Check out our booking page!')}`} target="_blank" rel="noopener noreferrer">
                                                                <Twitter className="mr-2 h-6 w-6"/> Twitter
                                                            </a>
                                                        </Button>
                                                         <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <Linkedin className="mr-2 h-6 w-6"/> LinkedIn
                                                            </a>
                                                        </Button>
                                                         <Button asChild variant="outline" className="h-16 text-lg">
                                                            <a href={`https://www.instagram.com/?url=${encodeURIComponent(bookingPageUrl)}`} target="_blank" rel="noopener noreferrer">
                                                                <Instagram className="mr-2 h-6 w-6"/> Instagram
                                                            </a>
                                                        </Button>
                                                    </div>
                                                    <DialogFooter>
                                                        <DialogClose asChild>
                                                            <Button type="button" variant="secondary">{t.close}</Button>
                                                        </DialogClose>
                                                    </DialogFooter>
                                                </DialogContent>
                                            </Dialog>
                                        </div>
                                    </div>
                                    <Separator />
                                </div>
                                <div className="space-y-1 px-2">
                                    <Button variant="ghost" size="lg" className="h-12 text-base md:text-lg justify-start w-full text-destructive hover:text-destructive" onClick={() => handleSignOut()}>
                                        <LogOut className="mr-4 h-5 w-5" /> {t.signOut}
                                    </Button>
                                </div>
                          </div>
                      </SheetContent>
                  </Sheet>
                  <Button size="sm" className="h-10 text-base" onClick={() => handleMenuAction('schedule')}>
                     <PlusCircle className="mr-2 h-4 w-4" /> {t.appointment}
                  </Button>
              </div>
              
               <div className="flex items-center justify-end">
                {business.logoUrl ? (
                    <div className="relative h-12 w-36">
                        <Image 
                            src={business.logoUrl} 
                            alt={`${business.businessName} logo`} 
                            fill
                            className="object-contain"
                            priority
                            unoptimized
                        />
                    </div>
                ) : (
                    <h1 className="text-lg font-bold truncate max-w-40">{business.businessName}</h1>
                )}
              </div>
            </div>
          </div>
        </header>
        
        <main className="container mx-auto px-4 md:px-4 py-4">
          <h2 className="text-2xl font-bold tracking-tight mb-4">{t.todaysAppointments}</h2>
          {renderDashboardView()}
        </main>
        {business.enablePwa && <PwaInstallBanner business={business} language={language} />}
      </div>
      
       <Dialog open={whatsNewModalOpen} onOpenChange={setWhatsNewModalOpen}>
        <DialogContent className="sm:max-w-2xl bg-transparent border-none shadow-none !p-0">
          <div className="relative isolate">
             <div className="absolute inset-0 bg-background/80 backdrop-blur-md -z-10" />
            <div className="p-8 sm:p-12 text-center">
              <div className="flex justify-center items-center gap-4 mb-4">
                  <PartyPopper className="h-10 w-10 text-primary" />
                  <h2 className="text-3xl font-bold tracking-tight text-foreground">{t.welcome}, {staffFullName}!</h2>
              </div>
              <p className="text-muted-foreground mb-8">
                {newAppointments.length > 0 ? t.newAppointmentsSince : t.noNewAppointments}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[50vh] overflow-y-auto pr-2">
                 {newAppointments.map((booking, index) => (
                      <div
                        key={booking.id}
                        className="bg-card/80 border rounded-lg p-4 text-left animate-in fade-in-0 slide-in-from-bottom-5"
                        style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'both' }}
                      >
                         <p className="font-semibold">{booking.customerName}</p>
                         <p className="text-sm text-muted-foreground">{booking.serviceName}</p>
                         <p className="text-xs text-muted-foreground mt-2">{format(parseISO(booking.date), 'EEE, LLL d')} @ {booking.time}</p>
                      </div>
                 ))}
              </div>

               <Button 
                size="lg" 
                className="mt-8"
                onClick={() => setWhatsNewModalOpen(false)}>
                  {t.awesome}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>


      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
            <DialogHeader>
                 {selectedBookingForModal && <DialogTitle>Booking: {selectedBookingForModal.customerName}</DialogTitle>}
            </DialogHeader>
            {selectedBookingForModal && (
                <div className="py-4 space-y-4">
                    <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Service</span>
                        <span className="font-medium">{selectedBookingForModal.serviceName}</span>
                    </div>
                     <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Staff</span>
                        <span className="font-medium">{selectedBookingForModal.staffName}</span>
                    </div>
                    <Separator/>
                    <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Date</span>
                        <span className="font-medium">{format(parseISO(selectedBookingForModal.date), 'EEE, LLL d, yyyy')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Time</span>
                        <span className="font-medium">{selectedBookingForModal.time}</span>
                    </div>
                     <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Phone</span>
                        <a href={`tel:${selectedBookingForModal.customerPhone}`} className="font-medium hover:underline flex items-center gap-1">
                            <Phone className="h-4 w-4" />
                            {selectedBookingForModal.customerPhone}
                        </a>
                    </div>
                </div>
            )}
            <DialogFooter className="grid grid-cols-1 gap-2 pt-4">
                {selectedBookingForModal && (
                    <>
                         <Button
                            size="lg" className="h-14 text-lg"
                            onClick={() => handleNotify(selectedBookingForModal.id, selectedBookingForModal.staffId)}
                            disabled={loading || getDynamicStatus(selectedBookingForModal) !== 'waiting' || !!('yourTurnSoonSmsSentAt' in selectedBookingForModal && selectedBookingForModal.yourTurnSoonSmsSentAt)}
                        >
                            <Bell className="mr-2 h-5 w-5" />
                            {('yourTurnSoonSmsSentAt' in selectedBookingForModal && selectedBookingForModal.yourTurnSoonSmsSentAt) ? t.notified : t.notify}
                        </Button>
                         <Button
                            size="lg" className="h-14 text-lg"
                            variant="secondary"
                            onClick={() => { setModalOpen(false); openRescheduleDialog(selectedBookingForModal); }}
                        >
                            <Undo2 className="mr-2 h-5 w-5" /> {t.rescheduleBooking}
                        </Button>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                 <Button
                                    size="lg"
                                    className="h-14 text-lg"
                                    variant="outline"
                                >
                                    <XCircle className="mr-2 h-5 w-5" /> {t.cancelBooking}
                                </Button>
                            </AlertDialogTrigger>
                             <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>{t.areYouSure}</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        {t.cancelBookingDesc.replace("{{customerName}}", selectedBookingForModal.customerName)}
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Go back</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleStatusChange(selectedBookingForModal.id, selectedBookingForModal.staffId, 'cancelled')} >
                                        Yes, cancel
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                         <AlertDialog>
                            <AlertDialogTrigger asChild>
                                 <Button
                                    size="lg"
                                    className="h-14 text-lg"
                                    variant="destructive"
                                >
                                    <Trash2 className="mr-2 h-5 w-5" /> {t.deleteBooking}
                                </Button>
                            </AlertDialogTrigger>
                             <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>{t.areYouSure}</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        {t.deleteBookingDesc}
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Go back</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDeleteBooking(selectedBookingForModal)} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                                        Yes, delete
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </>
                )}
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}


'use server';

import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { getBusiness } from '@/app/super-admin/businesses/actions';
import admin from '@/lib/firebase-admin';

const changePinSchema = z.object({
  newPin: z.string().length(4, 'New PIN must be 4 digits.'),
  confirmNewPin: z.string().length(4, 'Confirmation PIN must be 4 digits.'),
}).refine(data => data.newPin === data.confirmNewPin, {
  message: "New PINs do not match.",
  path: ['confirmNewPin'],
});

export async function changePin(businessId: string, data: z.infer<typeof changePinSchema>) {
    const validationResult = changePinSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    const { newPin } = validationResult.data;

    const business = await getBusiness(businessId);
    if (!business) {
        return { success: false, error: 'Business not found.' };
    }

    const kioskSettings = business.staffKioskSettings;
    if (!kioskSettings?.pinCode) {
        return { success: false, error: 'Kiosk login is not configured for this business.' };
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPin = await bcrypt.hash(newPin, salt);

        const db = admin.database();
        const settingsRef = db.ref(`businesses/${businessId}/staffKioskSettings/pinCode`);
        await settingsRef.set(hashedPin);

        return { success: true };
    } catch (error) {
        console.error('Error changing PIN:', error);
        return { success: false, error: 'Failed to update PIN due to a server error.' };
    }
}


'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  ArrowLeft,
  Calendar,
  Loader2,
  Phone,
  User,
  Users,
  X,
} from 'lucide-react';
import { type Service, type Category } from '@/app/super-admin/businesses/[id]/(edit-business)/services/schema';
import { useToast } from '@/hooks/use-toast';
import { createBooking, rescheduleBooking } from '@/app/[id]/client-app/actions';
import { bookingSchema, type BookingFormData } from '@/app/[id]/client-app/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { add, format, type Locale } from 'date-fns';
import { type Staff } from '@/app/super-admin/businesses/[id]/(edit-business)/staff/schema';
import { Input } from '@/components/ui/input';
import { PhoneInput } from '@/components/phone-input';
import { FormattedPrice } from '@/components/formatted-price';
import { useStaffScreen } from '../staff-screen-context';
import { type AggregatedBooking } from '@/app/super-admin/businesses/[id]/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { enUS, bs, da } from 'date-fns/locale';
import { useMediaQuery } from '@/hooks/use-media-query';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';
import { Checkbox } from '@/components/ui/checkbox';
import { useScheduler } from '@/hooks/use-scheduler';

const translations = {
  en: {
    back: "Back",
    newBooking: "New Booking",
    rescheduleBooking: "Reschedule Booking",
    step1: "Select a service",
    step2: "Select date & time",
    step3: "Choose specialist",
    step4: "Customer details",
    step5: "Confirm booking",
    noServicesFound: "No services found.",
    chooseDate: "Choose a date",
    next: "Next",
    bookNow: "Book now",
    noSlotsForDay: "No available slots for this day.",
    customerName: "Full name",
    customerNamePlaceholder: "e.g., John Doe",
    phoneNumber: "Phone number",
    confirmBooking: "Confirm booking",
    service: "Service",
    with: "With",
    dateTime: "Date & time",
    customerNameLabel: "Customer name",
    phoneLabel: "Phone",
    bookingCreated: "Booking created!",
    bookingCreatedDesc: "Appointment for {{customerName}} has been scheduled.",
    bookingRescheduled: "Booking rescheduled!",
    bookingRescheduledDesc: "The appointment has been successfully moved.",
    errorCreatingBooking: "Error creating booking",
    errorUnexpected: "An unexpected error occurred.",
    chooseSpecialist: "Choose your specialist",
    expertStylist: "Expert stylist",
    cancel: "Cancel",
    allStaff: "All staff"
  },
  bs: {
    back: "Nazad",
    newBooking: "Nova rezervacija",
    rescheduleBooking: "Promijeni termin rezervacije",
    step1: "Odaberite uslugu",
    step2: "Odaberite datum i vrijeme",
    step3: "Odaberite stručnjaka",
    step4: "Detalji o klijentu",
    step5: "Potvrdite rezervaciju",
    noServicesFound: "Nema pronađenih usluga.",
    chooseDate: "Odaberite datum",
    next: "Dalje",
    bookNow: "Rezerviši sada",
    noSlotsForDay: "Nema dostupnih termina za ovaj dan.",
    customerName: "Puno ime",
    customerNamePlaceholder: "npr., John Doe",
    phoneNumber: "Broj telefona",
    confirmBooking: "Potvrdi rezervaciju",
    service: "Usluga",
    with: "Sa",
    dateTime: "Datum i vrijeme",
    customerNameLabel: "Ime klijenta",
    phoneLabel: "Telefon",
    bookingCreated: "Rezervacija kreirana!",
    bookingCreatedDesc: "Termin za {{customerName}} je zakazan.",
    bookingRescheduled: "Rezervacija promijenjena!",
    bookingRescheduledDesc: "Termin je uspješno pomjeren.",
    errorCreatingBooking: "Greška pri kreiranju rezervacije",
    errorUnexpected: "Došlo je do neočekivane greške.",
    chooseSpecialist: "Odaberite svog stručnjaka",
    expertStylist: "Stručni stilist",
    cancel: "Otkaži",
    allStaff: "Svi zaposleni"
  },
  da: {
    back: "Tilbage",
    newBooking: "Ny Booking",
    rescheduleBooking: "Ombook aftale",
    step1: "Vælg en service",
    step2: "Vælg dato & tid",
    step3: "Vælg specialist",
    step4: "Kundeoplysninger",
    step5: "Bekræft booking",
    noServicesFound: "Ingen services fundet.",
    chooseDate: "Vælg en dato",
    next: "Næste",
    bookNow: "Book nu",
    noSlotsForDay: "Ingen ledige tider for denne dag.",
    customerName: "Fulde navn",
    customerNamePlaceholder: "f.eks., John Doe",
    phoneNumber: "Telefonnummer",
    confirmBooking: "Bekræft booking",
    service: "Service",
    with: "Med",
    dateTime: "Dato & tid",
    customerNameLabel: "Kundens navn",
    phoneLabel: "Telefon",
    bookingCreated: "Booking oprettet!",
    bookingCreatedDesc: "Aftale for {{customerName}} er blevet planlagt.",
    bookingRescheduled: "Booking ombooket!",
    bookingRescheduledDesc: "Aftalen er blevet flyttet.",
    errorCreatingBooking: "Fejl ved oprettelse af booking",
    errorUnexpected: "Der opstod en uventet fejl.",
    chooseSpecialist: "Vælg din specialist",
    expertStylist: "Ekspert stylist",
    cancel: "Annuller",
    allStaff: "Alt personale"
  },
};

type Language = keyof typeof translations;
type Step = 'service' | 'datetime' | 'staff' | 'details' | 'confirm';

interface ScheduleFlowProps {
  business: any;
  language: Language;
  categories: Category[];
  allStaff: Staff[];
}

export function ScheduleFlow({ business, language, categories, allStaff }: ScheduleFlowProps) {
    const { refreshData } = useStaffScreen();
    const { toast } = useToast();
    const router = useRouter();
    const searchParams = useSearchParams();
    
    const existingBookingJSON = searchParams.get('booking');
    const existingBooking: AggregatedBooking | null = existingBookingJSON ? JSON.parse(existingBookingJSON) : null;
    const isRescheduleMode = !!existingBooking;

    const [step, setStep] = React.useState<Step>(isRescheduleMode ? 'datetime' : 'service');
    const [selectedService, setSelectedService] = React.useState<Service | null>(null);
    const [selectedTime, setSelectedTime] = React.useState<string | undefined>(undefined);
    const t = translations[language] || translations.bs;
    const locale: Locale = language === 'da' ? da : language === 'en' ? enUS : bs;
    const [availableStaffForSlot, setAvailableStaffForSlot] = React.useState<Staff[]>([]);
    const [selectedStaffId, setSelectedStaffId] = React.useState<string | undefined>(undefined);

    const totalDuration = selectedService ? selectedService.duration : (existingBooking && 'totalDuration' in existingBooking ? existingBooking.totalDuration : 0);

    const {
        selectedDate,
        setSelectedDate,
        currentMonth,
        setCurrentMonth,
        availableSlots,
        isLoadingAvailability,
        noSlotsFound
    } = useScheduler({ 
        business, 
        allStaff, 
        totalDuration, 
        existingBookingId: existingBooking?.id 
    });
  
    const currentBookingSchema = bookingSchema(business?.allowedPhoneCountries || [], true);
    const form = useForm<BookingFormData & { sendSms: boolean }>({
        resolver: zodResolver(currentBookingSchema.extend({ sendSms: z.boolean() })),
        defaultValues: {
            extensions: [],
            customerName: '',
            customerPhone: '',
            sendSms: true,
        },
    });

    const { isSubmitting } = form.formState;
    const isMobile = useMediaQuery("(max-width: 768px)");
    const [accordionValue, setAccordionValue] = React.useState<string>("date-picker");

    React.useEffect(() => {
        if (isRescheduleMode && existingBooking) {
            const allServices = categories.flatMap(c => c.services || []);
            const serviceId = 'serviceId' in existingBooking ? existingBooking.serviceId : undefined;
            const serviceName = 'serviceName' in existingBooking ? existingBooking.serviceName : undefined;
            const service = allServices.find(s => s.id === serviceId || s.name === serviceName);
            
            if (service) {
                setSelectedService(service);
                form.reset({
                    serviceId: service.id,
                    serviceName: service.name,
                    totalDuration: 'totalDuration' in existingBooking ? existingBooking.totalDuration : service.duration,
                    totalPrice: 'totalPrice' in existingBooking ? existingBooking.totalPrice : service.price,
                    customerName: 'customerName' in existingBooking ? existingBooking.customerName : '',
                    customerPhone: 'customerPhone' in existingBooking ? existingBooking.customerPhone : '',
                    sendSms: true,
                });
            }
        }
    }, [isRescheduleMode, existingBooking, categories, form]);
    
    React.useEffect(() => {
        if (selectedDate) {
            setSelectedTime(undefined);
            setSelectedStaffId(undefined);
        }
    }, [selectedDate]);

    const handleServiceSelected = (service: Service) => {
        setSelectedService(service);
        form.setValue('serviceId', service.id);
        form.setValue('serviceName', service.name);
        form.setValue('totalDuration', service.duration);
        form.setValue('totalPrice', service.price);
        setStep('datetime');
    };

    const handleStaffSelected = (staff: Staff) => {
        setSelectedStaffId(staff.id);
        form.setValue('staffId', staff.id);
        form.setValue('staffName', staff.fullName);
        setStep(isRescheduleMode ? 'confirm' : 'details');
    };
    
    const handleTimeSelected = (time: string) => {
        const slot = availableSlots.find(s => s.time === time);
        if (!slot) return;

        setSelectedTime(time);
        form.setValue('date', format(selectedDate!, 'yyyy-MM-dd'));
        form.setValue('time', time);

        if (slot.staffIds.length === 1) {
            const staffId = slot.staffIds[0];
            const staffMember = allStaff.find(s => s.id === staffId);
            if (staffMember) {
                form.setValue('staffId', staffMember.id);
                form.setValue('staffName', staffMember.fullName);
                setStep(isRescheduleMode ? 'confirm' : 'details');
            }
        } else {
            const availableStaff = allStaff.filter(s => slot.staffIds.includes(s.id));
            setAvailableStaffForSlot(availableStaff);
            setStep('staff');
        }
    }

    const handleNextStep = async () => {
        switch (step) {
            case 'details': {
                const isValid = await form.trigger(['customerName', 'customerPhone']);
                if (isValid) setStep('confirm');
                break;
            }
            default:
                break;
        }
    };
    
    const handlePrevStep = () => {
        if(isRescheduleMode) {
            if (step === 'confirm') setStep('datetime');
            else router.push(`/${business.id}/staff-app`);
            return;
        }
        
        switch (step) {
            case 'datetime':
                setStep('service');
                setSelectedService(null);
                break;
            case 'staff':
                setStep('datetime');
                setSelectedTime(undefined);
                break;
            case 'details':
                 if(availableStaffForSlot.length > 1) {
                    setStep('staff');
                } else {
                    setStep('datetime');
                }
                setSelectedStaffId(undefined);
                break;
            case 'confirm':
                setStep('details');
                break;
            default:
                 router.push(`/${business.id}/staff-app`);
        }
    };

    const onFinalSubmit = async (data: BookingFormData) => {
      const result = isRescheduleMode && existingBooking && 'staffId' in existingBooking
        ? await rescheduleBooking(business.id, existingBooking.id, existingBooking.staffId, {
            date: data.date,
            time: data.time,
            staffId: data.staffId,
            staffName: data.staffName,
            })
        : await createBooking(business.id, data, true);

        if(result.success) {
            toast({ title: isRescheduleMode ? t.bookingRescheduled : t.bookingCreated, description: isRescheduleMode ? t.bookingRescheduledDesc : t.bookingCreatedDesc.replace('{{customerName}}', data.customerName) });
            refreshData();
            router.push(`/${business.id}/staff-app`);
        } else {
             const errorMessage = 'errors' in result ? (result.errors as any)?._root?.[0] : ('error' in result ? result.error : null);
            toast({
                variant: 'destructive',
                title: isRescheduleMode ? "Error rescheduling" : t.errorCreatingBooking,
                description: errorMessage || t.errorUnexpected,
            });
        }
    }

    const getStepTitle = () => {
        if (isRescheduleMode) return t.rescheduleBooking;
        const titles: Record<Step, string> = {
            service: t.step1,
            datetime: t.step2,
            staff: t.step3,
            details: t.step4,
            confirm: t.step5,
        };
        return titles[step] || '';
    }

  const renderContent = () => {
    switch (step) {
      case 'service':
        return (
            <>
                {categories.length > 0 ? (
                    <Accordion type="multiple" defaultValue={categories.map(c => c.id)} className="w-full space-y-4">
                        {categories.map((category) => (
                            <AccordionItem value={category.id} key={category.id} className="border-b-0">
                                <AccordionTrigger className="py-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                                    {category.name}
                                </AccordionTrigger>
                                <AccordionContent className="p-0 border-t-0">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 py-4">
                                        {category.services?.map((s: any) => (
                                            <Card 
                                            key={s.id} 
                                            className={cn('cursor-pointer transition-all', selectedService?.id === s.id ? 'border-primary ring-2 ring-primary' : 'hover:border-primary/50')}
                                            onClick={() => handleServiceSelected(s)}
                                            >
                                            <CardHeader className="p-4">
                                                <CardTitle className="text-base">{s.name}</CardTitle>
                                            </CardHeader>
                                            <CardContent className="p-4 pt-0 flex justify-between items-center text-sm">
                                                <span className="font-semibold"><FormattedPrice price={s.price} currency={business.currency || 'DKK'} /></span>
                                                <span className="text-muted-foreground">{s.duration} min</span>
                                            </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                ) : (
                <p className="text-center text-muted-foreground py-8 col-span-full">{t.noServicesFound}</p>
                )}
            </>
        );
      case 'datetime':
        return (
            <div className="py-4 grid md:grid-cols-2 gap-6">
                <div className="flex flex-col items-center">
                {isMobile ? (
                        <Accordion type="single" value={accordionValue} onValueChange={setAccordionValue} collapsible className="w-full">
                            <AccordionItem value="date-picker">
                                <AccordionTrigger className="text-lg font-semibold w-full">
                                    {selectedDate ? format(selectedDate, 'PPP', { locale }) : t.chooseDate}
                                </AccordionTrigger>
                                <AccordionContent>
                                    <CalendarComponent
                                        mode="single"
                                        selected={selectedDate}
                                        onSelect={(date) => {
                                            setSelectedDate(date as Date);
                                            if (date) setAccordionValue(''); // Collapse on selection
                                        }}
                                        month={currentMonth}
                                        onMonthChange={setCurrentMonth}
                                        fromDate={add(new Date(), {days: -1})}
                                        toDate={add(new Date(), { months: 2 })}
                                        weekStartsOn={business.weekStartsOn === 0 ? 0 : 1}
                                        locale={locale}
                                    />
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    ) : (
                        <CalendarComponent
                            mode="single"
                            selected={selectedDate}
                            onSelect={(date) => {
                                setSelectedDate(date as Date);
                            }}
                            month={currentMonth}
                            onMonthChange={setCurrentMonth}
                            fromDate={add(new Date(), {days: -1})}
                            toDate={add(new Date(), { months: 2 })}
                            weekStartsOn={business.weekStartsOn === 0 ? 0 : 1}
                            locale={locale}
                        />
                    )}
                </div>
                <div className="space-y-2">
                    <h4 className="font-semibold mb-2 text-center text-lg">
                        {selectedDate ? format(selectedDate, 'eeee, dd MMM, yyyy', { locale }) : t.chooseDate}
                    </h4>
                    {isLoadingAvailability ? (
                        <div className="flex justify-center items-center h-48">
                            <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        </div>
                    ) : selectedDate && availableSlots.length > 0 ? (
                        <div className="grid grid-cols-3 gap-2">
                            {availableSlots.map(slot => (
                                <Button size="lg" key={slot.time} variant={selectedTime === slot.time ? 'default' : 'outline'} onClick={() => handleTimeSelected(slot.time)}>
                                    {slot.time}
                                </Button>
                            ))}
                        </div>
                    ) : (
                        <p className="text-center text-muted-foreground pt-10">{noSlotsFound ? 'No slots available in the near future.' : t.noSlotsForDay}</p>
                    )}
                </div>
            </div>
        );
      case 'staff':
        return (
            <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto">
                {availableStaffForSlot.map(staff => (
                    <Card key={staff.id} 
                        className={cn('cursor-pointer transition-all', selectedStaffId === staff.id ? 'border-primary ring-2 ring-primary' : 'hover:border-primary/50')}
                        onClick={() => handleStaffSelected(staff)}
                    >
                        <CardHeader className="flex flex-row items-center gap-4">
                            <Avatar className="h-14 w-14">
                                <AvatarImage src={staff.imageUrl ?? undefined} className="object-cover" />
                                <AvatarFallback>{staff.fullName.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <CardTitle className="text-lg">{staff.fullName}</CardTitle>
                                <CardDescription>{t.expertStylist}</CardDescription>
                            </div>
                        </CardHeader>
                    </Card>
                ))}
            </div>
        );
      case 'details':
        const template = business.smsConfirmationTemplate?.[language] || 'Your booking is confirmed.';
        const smsContent = template
            .replace(/{{businessName}}/g, business.businessName)
            .replace(/{{serviceName}}/g, selectedService?.name || '')
            .replace(/{{date}}/g, selectedDate ? format(selectedDate, 'dd MMM yy', { locale }) : '')
            .replace(/{{time}}/g, selectedTime || '');
        return (
            <div className="py-4 space-y-6">
                <Card>
                    <CardContent className="p-6 space-y-6">
                         <FormField
                            control={form.control}
                            name="customerName"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel className="text-lg">{t.customerName}</FormLabel>
                                <FormControl>
                                    <Input placeholder={t.customerNamePlaceholder} {...field} className="h-12 text-lg"/>
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="customerPhone"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel className="text-lg">{t.phoneNumber}</FormLabel>
                                <FormControl>
                                    <PhoneInput {...field} allowedCountries={business.allowedPhoneCountries || []} className="h-12 text-lg"/>
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                </Card>
                 <FormField
                    control={form.control}
                    name="sendSms"
                    render={({ field }) => (
                        <FormItem>
                            <Card className={cn(field.value && 'border-primary ring-2 ring-primary')}>
                                <CardContent className="p-4">
                                    <div className="flex items-start gap-4">
                                        <Checkbox 
                                            id="sendSms"
                                            checked={field.value}
                                            onCheckedChange={field.onChange}
                                            className="h-6 w-6 mt-1"
                                        />
                                        <div className="flex-1">
                                            <FormLabel htmlFor="sendSms" className="text-base cursor-pointer">Send SMS notification</FormLabel>
                                            <FormDescription>Confirm with the customer via SMS.</FormDescription>
                                            {field.value && (
                                                 <div className="mt-4 p-3 bg-muted rounded-md text-sm text-muted-foreground italic">
                                                    "{smsContent}"
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </FormItem>
                    )}
                />
            </div>
        );
        case 'confirm':
            const formData = form.getValues();
            return (
                <div className="py-4">
                    <Card className="my-6 text-lg">
                        <CardHeader>
                            <CardTitle className="text-xl">{t.confirmBooking}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-between items-center">
                                <span className="text-muted-foreground flex items-center gap-2"><User /> {t.service}</span>
                                <span className="font-semibold">{formData.serviceName}</span>
                            </div>
                            <Separator/>
                            <div className="flex justify-between items-center">
                                <span className="text-muted-foreground flex items-center gap-2"><Users /> {t.with}</span>
                                <span className="font-semibold">{formData.staffName}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-muted-foreground flex items-center gap-2"><Calendar /> {t.dateTime}</span>
                                <span className="font-semibold">{format(new Date(formData.date), 'dd MMM, yyyy', {locale})} at {formData.time}</span>
                            </div>
                            <Separator/>
                                <div className="flex justify-between items-center">
                                <span className="text-muted-foreground flex items-center gap-2"><User /> {t.customerNameLabel}</span>
                                <span className="font-semibold">{formData.customerName}</span>
                            </div>
                                <div className="flex justify-between items-center">
                                <span className="text-muted-foreground flex items-center gap-2"><Phone /> {t.phoneLabel}</span>
                                <span className="font-semibold">{formData.customerPhone}</span>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )
      default:
        return null;
    }
  };

  const nextButtonDisabled = 
    (step === 'service' && !selectedService) ||
    (step === 'datetime' && !selectedTime) ||
    (step === 'staff' && !selectedStaffId);

  return (
        <div className="flex flex-col min-h-screen bg-muted/40">
            <header className="bg-background border-b sticky top-0 z-10">
                <div className="container mx-auto px-4 md:px-8 flex items-center justify-between h-16">
                     <h3 className="font-semibold text-base">{getStepTitle()}</h3>
                     <Button variant="ghost" size="lg" asChild>
                        <Link href={`/${business.id}/staff-app`}>
                            <X className="mr-2 h-4 w-4" />
                            {t.cancel}
                        </Link>
                    </Button>
                </div>
            </header>

            <main className="container mx-auto py-8 px-4 md:px-8 flex-1">
                 <Form {...form}>
                    <form onSubmit={(e) => { e.preventDefault(); }}>
                        <Card key={step}>
                            <CardContent className="p-6">
                                {renderContent()}
                            </CardContent>
                        </Card>
                    </form>
                </Form>
            </main>
            
             <footer className="sticky bottom-0 bg-background border-t z-10">
                <div className="container mx-auto px-4 md:px-8 flex items-center justify-between h-20">
                     <Button type="button" variant="ghost" size="lg" onClick={handlePrevStep} >
                        <ArrowLeft className="mr-2 h-5 w-5" />{t.back}
                    </Button>
                    {step !== 'confirm' ? (
                         <Button type="button" size="lg" onClick={handleNextStep} disabled={nextButtonDisabled}>
                            {t.next}
                        </Button>
                    ) : (
                        <Button type="button" size="lg" onClick={form.handleSubmit(onFinalSubmit)} disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
                            {isRescheduleMode ? t.rescheduleBooking : t.bookNow}
                        </Button>
                    )}
                </div>
            </footer>
        </div>
    );
}


'use client';

import * as React from 'react';
import { Loader2 } from "lucide-react";
import { useStaffScreen } from "../staff-screen-context.tsx";
import { ScheduleFlow } from "./schedule-flow.tsx";

export default function SchedulePage() {
    const { business, categories, allStaff, loadingStaff } = useStaffScreen();

    if (loadingStaff || !business || !categories || !allStaff) {
         return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    return (
        <ScheduleFlow
            business={business}
            language={business.language || 'bs'}
            categories={categories}
            allStaff={allStaff}
        />
    )
}

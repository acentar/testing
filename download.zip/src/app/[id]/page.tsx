
import { redirect } from "next/navigation";

export default async function BusinessRootPage({ params }: { params: { id: string } }) {
    const { id } = params;
    redirect(`/${id}/client-app`);
}

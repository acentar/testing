
'use server';

import admin from '@/lib/firebase-admin'; 
import { revalidatePath } from 'next/cache';
import { type BookingFormData, bookingSchema } from './schema';
import { type Staff } from '@/app/super-admin/businesses/[id]/staff/actions';
import { add, format, isAfter, isBefore, isSameDay, parse, startOfToday, getDay, getMinutes, getHours, startOfDay, addDays, addMinutes, addHours, addMonths, endOfDay } from 'date-fns';
import { Customer, customerSchema } from './customer-schema';
import { z } from 'zod';
import { toZonedTime } from 'date-fns-tz';
import { bs, enUS, da } from 'date-fns/locale';
import { getSmsClient, getGlobalSettings } from '@/app/super-admin/settings/actions';
import { AggregatedBooking, BusinessCustomer } from '@/app/super-admin/businesses/[id]/types';
import { getCategories, getExtensions } from '@/app/super-admin/businesses/[id]/services/actions';
import type { Service, Extension } from '@/app/super-admin/businesses/[id]/services/schema';

const db = admin.database();
const serverTimestamp = admin.database.ServerValue.TIMESTAMP;

async function getBusiness(id: string): Promise<any | null> {
    try {
        const businessRef = db.ref(`businesses/${id}`);
        const snapshot = await businessRef.once('value');
        if (snapshot.exists()) {
            return { id: snapshot.key, ...snapshot.val() };
        }
        return null;
    } catch (error) {
        console.error("Error fetching business with Admin SDK:", error);
        return null;
    }
}

const formatSenderId = async (name: string): Promise<string> => {
    const sanitized = name.replace(/[^a-zA-Z0-9]/g, '');
    if (sanitized) {
        return sanitized.substring(0, 11);
    }
    const globalSettings = await getGlobalSettings();
    return globalSettings.general?.appName?.replace(/[^a-zA-Z0-9]/g, '').substring(0, 11) || 'QueuePilot';
};

async function updateLastUpdatedTimestamp(businessId: string) {
    const scheduleLastUpdatedRef = db.ref(`businesses/${businessId}/scheduleLastUpdated`);
    await scheduleLastUpdatedRef.set(serverTimestamp);
}

export async function sendLoginSms(businessId: string, phoneNumber: string) {
    const business = await getBusiness(businessId);
    if (!business) {
        return { success: false, error: 'Business not found.' };
    }
    if (!(await hasSmsEnabled(business))) {
        return { success: false, error: 'SMS service not configured for this business.' };
    }
    const smsClient = await getSmsClient(business.id);
    
    if (!smsClient) {
        return { success: false, error: 'SMS service provider details not configured correctly.' };
    }

    try {
        const verificationCode = Math.floor(1000 + Math.random() * 9000).toString();
        
        const loginRequestsRef = db.ref(`businesses/${businessId}/loginRequests`);
        const newLoginRequestRef = loginRequestsRef.push();
        await newLoginRequestRef.set({
            phone: phoneNumber,
            code: verificationCode,
            expires: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
        });
        
        const lang = business.smsLanguage || 'bs';
        const template = business.smsVerificationTemplate?.[lang] || 'Your sign-in code for {{businessName}} is {{code}}';
        const text = template
            .replace('{{businessName}}', business.businessName)
            .replace('{{code}}', verificationCode);
        
        await smsClient.send({
            to: phoneNumber,
            from: await formatSenderId(business.businessName),
            text,
        });

        return { success: true, loginId: newLoginRequestRef.key };
    } catch (error) {
        console.error("Error sending login SMS:", error);
        return { success: false, error: 'Failed to send sign-in code.' };
    }
}

export async function verifyLoginCode(businessId: string, loginId: string, code: string): Promise<{ success: boolean; customer?: Customer; error?: string }> {
    try {
        const loginRequestRef = db.ref(`businesses/${businessId}/loginRequests/${loginId}`);
        const snapshot = await loginRequestRef.once('value');

        if (!snapshot.exists()) {
            return { success: false, error: 'No sign-in request found. Please try again.' };
        }

        const request = snapshot.val();
        if (new Date() > new Date(request.expires)) {
            await loginRequestRef.remove();
            return { success: false, error: 'Verification code has expired.' };
        }

        if (request.code !== code) {
            return { success: false, error: 'Invalid verification code.' };
        }

        const customerId = await findOrCreateCustomer(businessId, '', request.phone, true);
        const customerRef = db.ref(`businesses/${businessId}/customers/${customerId}`);
        const customerSnapshot = await customerRef.once('value');
        const customerData = customerSnapshot.val() || {};
        
        await loginRequestRef.remove();

        const customerToReturn = {
            id: customerId,
            ...customerData,
            name: customerData.name || '',
        };

        return { success: true, customer: customerToReturn };

    } catch (error) {
        console.error("Error verifying code:", error);
        return { success: false, error: 'An unexpected error occurred.' };
    }
}

export async function sendVerificationSms(businessId: string, phoneNumber: string, customerName: string) {
    const business = await getBusiness(businessId);
    if (!business) {
        return { success: false, error: 'Business not found.' };
    }

    if (!(await hasSmsEnabled(business))) {
        return { success: false, error: 'SMS service not configured for this business.' };
    }
    
    const smsClient = await getSmsClient(business.id);
    if(!smsClient) {
         return { success: false, error: 'SMS service provider details not configured correctly.' };
    }

    const verificationCode = Math.floor(1000 + Math.random() * 9000).toString();

    try {
        const verificationRef = db.ref(`businesses/${businessId}/verifications`).push();
        await verificationRef.set({
            phone: phoneNumber,
            name: customerName,
            code: verificationCode,
            expires: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
        });

        const lang = business.smsLanguage || 'bs';
        const template = business.smsVerificationTemplate?.[lang] || 'Your verification code for {{businessName}} is {{code}}';
        const text = template
            .replace('{{businessName}}', business.businessName)
            .replace('{{code}}', verificationCode);
        
        await smsClient.send({
            to: phoneNumber,
            from: await formatSenderId(business.businessName),
            text,
        });

        return { success: true, verificationId: verificationRef.key };
    } catch (error) {
        console.error("Error sending SMS:", error);
        return { success: false, error: 'Failed to send verification code.' };
    }
}

export async function verifyCodeAndSignIn(businessId: string, verificationId: string, code: string): Promise<{ success: boolean; customer?: Customer; error?: string }> {
    try {
        const verificationRef = db.ref(`businesses/${businessId}/verifications/${verificationId}`);
        const snapshot = await verificationRef.once('value');
        if (!snapshot.exists()) {
            return { success: false, error: "Verification request not found. Please try again." };
        }

        const verificationData = snapshot.val();
        if (new Date() > new Date(verificationData.expires)) {
            await verificationRef.remove();
            return { success: false, error: "Verification code has expired." };
        }

        if (verificationData.code !== code) {
            return { success: false, error: "Invalid verification code." };
        }

        const customerId = await findOrCreateCustomer(businessId, verificationData.name, verificationData.phone, false);
        const customerRef = db.ref(`businesses/${businessId}/customers/${customerId}`);
        const customerSnapshot = await customerRef.once('value');
        
        await verificationRef.remove();

        const customerData = customerSnapshot.val() || {};
        const customerToReturn = {
            id: customerId,
            ...customerData,
            name: customerData.name || '',
        };

        return { success: true, customer: customerToReturn };

    } catch (error) {
        console.error("Error verifying code and signing in:", error);
        return { success: false, error: 'An unexpected error occurred.' };
    }
}

async function findOrCreateCustomer(businessId: string, name: string, phone: string, isSignIn: boolean = false) {
    const customersRef = db.ref(`businesses/${businessId}/customers`);
    const snapshot = await customersRef.orderByChild('phone').equalTo(phone).limitToFirst(1).once('value');
    
    if(snapshot.exists()) {
        const customerId = Object.keys(snapshot.val())[0];
        const customerRef = db.ref(`businesses/${businessId}/customers/${customerId}`);
        const updates: any = { lastSeen: serverTimestamp };
        if (name && !isSignIn) { 
            updates.name = name;
        }
        await customerRef.update(updates);
        return customerId;
    } else {
        const newCustomerRef = customersRef.push();
        const newCustomerData: any = { 
            phone, 
            createdAt: serverTimestamp,
            lastSeen: serverTimestamp
        };
        newCustomerData.name = name || '';
        await newCustomerRef.set(newCustomerData);
        return newCustomerRef.key!;
    }
}

async function sendNewBookingSmsToOwner(business: any, booking: BookingFormData) {
    if (!business?.enableNewBookingSmsNotification || !business.newBookingSmsRecipient) {
        return;
    }
    
    const smsClient = await getSmsClient(business.id);
    if(!smsClient) return;

    try {
        const lang = business.smsLanguage || 'bs';
        const locale = lang === 'bs' ? bs : (lang === 'da' ? da : enUS);
        const formattedDate = format(new Date(booking.date), 'dd MMM yy', { locale });
        const template = business.smsNewBookingTemplate?.[lang] || 'New booking for {{serviceName}} from {{customerName}} on {{date}} at {{time}} with {{staffName}}.';
        
        const text = template
            .replace(/{{businessName}}/g, business.businessName)
            .replace(/{{customerName}}/g, booking.customerName)
            .replace(/{{serviceName}}/g, booking.serviceName)
            .replace(/{{date}}/g, formattedDate)
            .replace(/{{time}}/g, booking.time)
            .replace(/{{staffName}}/g, booking.staffName);
        
        await smsClient.send({
            to: business.newBookingSmsRecipient,
            from: await formatSenderId(business.businessName),
            text,
        });

    } catch (error) {
        console.error("Failed to send new booking notification SMS to owner:", error);
    }
}

async function sendConfirmationSms(business: any, booking: BookingFormData) {
    if (!booking.sendSms || !(await hasSmsEnabled(business)) || !business.smsConfirmationTemplate) {
        return;
    }
    
    const smsClient = await getSmsClient(business.id);
    if(!smsClient) return;

    try {
        const lang = business.smsLanguage || 'bs';
        const locale = lang === 'bs' ? bs : (lang === 'da' ? da : enUS);
        const formattedDate = format(new Date(booking.date), 'dd MMM yy', { locale });
        const template = business.smsConfirmationTemplate?.[lang] || 'Your booking for {{serviceName}} at {{businessName}} on {{date}} at {{time}} is confirmed.';
        const text = template
            .replace(/{{businessName}}/g, business.businessName)
            .replace(/{{customerName}}/g, booking.customerName)
            .replace(/{{serviceName}}/g, booking.serviceName)
            .replace(/{{date}}/g, formattedDate)
            .replace(/{{time}}/g, booking.time);
        
        await smsClient.send({
            to: booking.customerPhone,
            from: await formatSenderId(business.businessName),
            text,
        });

    } catch (error) {
        console.error("Failed to send booking confirmation SMS:", error);
    }
}

export async function sendRescheduleSms(businessId: string, booking: any, newDate: string, newTime: string) {
    const business = await getBusiness(businessId);
    if (!business || !(await hasSmsEnabled(business)) || !business.smsRescheduleTemplate) {
        return;
    }
    
    const smsClient = await getSmsClient(business.id);
    if(!smsClient) return;

    try {
        const lang = business.smsLanguage || 'bs';
        const locale = lang === 'bs' ? bs : (lang === 'da' ? da : enUS);
        const formattedDate = format(new Date(newDate), 'dd MMM yy', { locale });
        const template = business.smsRescheduleTemplate?.[lang] || 'Your appointment at {{businessName}} for {{serviceName}} has been rescheduled to {{date}} at {{time}}.';
        const text = template
            .replace(/{{businessName}}/g, business.businessName)
            .replace(/{{customerName}}/g, booking.customerName)
            .replace(/{{serviceName}}/g, booking.serviceName)
            .replace(/{{date}}/g, formattedDate)
            .replace(/{{time}}/g, newTime);
        
        await smsClient.send({
            to: booking.customerPhone,
            from: await formatSenderId(business.businessName),
            text,
        });

    } catch (error) {
        console.error("Failed to send booking reschedule SMS:", error);
    }
}

export async function sendCancellationSms(businessId: string, booking: any) {
    const business = await getBusiness(businessId);
    if (!business || !(await hasSmsEnabled(business)) || !business.smsCancellationTemplate) {
        return;
    }

    const smsClient = await getSmsClient(businessId);
    if (!smsClient) return;

    try {
        const lang = business.smsLanguage || 'bs';
        const locale = lang === 'bs' ? bs : (lang === 'da' ? da : enUS);
        const formattedDate = format(new Date(booking.date), 'dd MMM yy', { locale });
        const template = business.smsCancellationTemplate?.[lang] || 'Your booking for {{serviceName}} at {{businessName}} on {{date}} at {{time}} has been cancelled.';
        const text = template
            .replace(/{{businessName}}/g, business.businessName)
            .replace(/{{customerName}}/g, booking.customerName)
            .replace(/{{serviceName}}/g, booking.serviceName)
            .replace(/{{date}}/g, formattedDate)
            .replace(/{{time}}/g, booking.time);

        await smsClient.send({
            to: booking.customerPhone,
            from: await formatSenderId(business.businessName),
            text,
        });

    } catch (error) {
        console.error("Failed to send booking cancellation SMS:", error);
    }
}

async function isSlotAvailable(businessId: string, staffId: string, date: string, time: string, duration: number, bookingIdToIgnore?: string): Promise<boolean> {
    const staffScheduleRef = db.ref(`schedules/${businessId}/${staffId}`);
    const snapshot = await staffScheduleRef.once('value');

    if (!snapshot.exists()) {
        return true;
    }

    const schedule = snapshot.val();
    const [startHours, startMinutes] = time.split(':').map(Number);
    const slotStartMinutes = startHours * 60 + startMinutes;
    const slotEndMinutes = slotStartMinutes + duration;

    for (const eventId in schedule) {
        if (bookingIdToIgnore && eventId === bookingIdToIgnore) {
            continue;
        }
        const event = schedule[eventId];
        
        if (event.date === date && event.status !== 'cancelled') {
            let eventStartMinutes, eventEndMinutes;

            if (event.type === 'booking') {
                const [eventStartH, eventStartM] = event.time.split(':').map(Number);
                eventStartMinutes = eventStartH * 60 + eventStartM;
                eventEndMinutes = eventStartMinutes + event.totalDuration;
            } else if (event.type === 'break' || event.type === 'manual') {
                const [eventStartH, eventStartM] = event.startTime.split(':').map(Number);
                eventStartMinutes = eventStartH * 60 + eventStartM;
                eventEndMinutes = eventStartMinutes + event.duration;
            } else {
                continue;
            }
            
            if (slotStartMinutes < eventEndMinutes && slotEndMinutes > eventStartMinutes) {
                return false;
            }
        }
    }

    return true;
}

export async function createBooking(businessId: string, data: BookingFormData, fromStaffScreen = false): Promise<{ success: boolean; errors?: any }> {
  const business = await getBusiness(businessId);
  if (!business) {
    return { success: false, errors: { _root: ['Business not found.'] } };
  }

  const currentBookingSchema = bookingSchema(business.allowedPhoneCountries || [], fromStaffScreen);
  const validationResult = currentBookingSchema.safeParse(data);

  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }
  
  const bookingPayload = validationResult.data;

  const slotIsStillAvailable = await isSlotAvailable(businessId, bookingPayload.staffId, bookingPayload.date, bookingPayload.time, bookingPayload.totalDuration);
  if (!slotIsStillAvailable) {
      return { success: false, errors: { _root: ['This time slot is no longer available. Please select another time.'] } };
  }

  try {
    let finalCustomerId: string;

    if (fromStaffScreen) {
        finalCustomerId = await findOrCreateCustomer(businessId, bookingPayload.customerName, bookingPayload.customerPhone);
    } else {
        if (!bookingPayload.customerId) {
             return { success: false, errors: { _root: ['Customer could not be verified. Please try again.'] } };
        }
        finalCustomerId = bookingPayload.customerId;
    }

    const scheduleRef = db.ref(`schedules/${businessId}/${bookingPayload.staffId}`);
    const newBookingRef = scheduleRef.push();
    const newBookingId = newBookingRef.key!;

    const newBookingData: any = { 
        type: 'booking',
        id: newBookingId,
        status: 'waiting',
        createdAt: serverTimestamp as any,
        serviceId: bookingPayload.serviceId,
        serviceName: bookingPayload.serviceName,
        extensions: bookingPayload.extensions || [],
        staffId: bookingPayload.staffId,
        staffName: bookingPayload.staffName,
        date: bookingPayload.date,
        time: bookingPayload.time,
        customerName: bookingPayload.customerName,
        customerPhone: bookingPayload.customerPhone,
        customerId: finalCustomerId,
        totalDuration: bookingPayload.totalDuration,
        totalPrice: bookingPayload.totalPrice,
    };
    
    await newBookingRef.set(newBookingData);
    await updateLastUpdatedTimestamp(businessId);
    
    if (bookingPayload.sendSms) {
        await sendConfirmationSms(business, validationResult.data);
    }
    
    if (!fromStaffScreen) {
        await sendNewBookingSmsToOwner(business, validationResult.data);
    }
    
    revalidatePath(`/${businessId}/client-app`);
    revalidatePath(`/${businessId}/staff-app`);

    return { success: true };
  } catch (error) {
    console.error("Error creating booking:", error);
    return { success: false, errors: { _root: ['Failed to create booking.'] } };
  }
}

export type CustomerBooking = BookingFormData & { id: string };

export async function getCustomerBookings(businessId: string, customerId: string): Promise<CustomerBooking[]> {
    try {
        const schedulesRef = db.ref(`schedules/${businessId}`);
        const schedulesSnapshot = await schedulesRef.once('value');
        
        if (!schedulesSnapshot.exists()) {
            return [];
        }

        const now = new Date();
        let bookings: CustomerBooking[] = [];

        schedulesSnapshot.forEach(staffSchedule => {
            const staffBookings = staffSchedule.val();
            for (const bookingId in staffBookings) {
                const booking = staffBookings[bookingId];
                if (booking.type === 'booking' && booking.customerId === customerId) {
                    const bookingDateTime = parse(`${booking.date} ${booking.time}`, 'yyyy-MM-dd HH:mm', new Date());

                    if (isAfter(bookingDateTime, now) && booking.status !== 'cancelled' && booking.status !== 'completed') {
                        bookings.push({ id: bookingId, ...booking });
                    }
                }
            }
        });

        return bookings.sort((a,b) => {
            const dateA = new Date(`${a.date}T${a.time}`);
            const dateB = new Date(`${b.date}T${b.time}`);
            return dateA.getTime() - dateB.getTime();
        });

    } catch (error) {
        console.error("Error getting customer bookings:", error);
        return [];
    }
}

export async function cancelBooking(businessId: string, bookingId: string, staffId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const bookingRef = db.ref(`schedules/${businessId}/${staffId}/${bookingId}`);
        const snapshot = await bookingRef.once('value');
        if(!snapshot.exists()) {
            return { success: false, error: 'Booking not found.' };
        }
        
        const bookingData = snapshot.val();
        await bookingRef.update({ status: 'cancelled' });
        await updateLastUpdatedTimestamp(businessId);

        await sendCancellationSms(businessId, bookingData);

        revalidatePath(`/${businessId}/client-app`);
        return { success: true };
    } catch (error) {
        console.error("Error cancelling booking:", error);
        return { success: false, error: 'Failed to cancel the booking.' };
    }
}

export async function updateCustomerName(businessId: string, customerId: string, name: string): Promise<{ success: boolean; error?: string }> {
    const nameSchema = z.string().min(2, 'Name must be at least 2 characters.');
    const validationResult = nameSchema.safeParse(name);

    if (!validationResult.success) {
        return { success: false, error: validationResult.error.errors[0].message };
    }
    
    try {
        const customerRef = db.ref(`businesses/${businessId}/customers/${customerId}`);
        await customerRef.update({ name });
        revalidatePath(`/${businessId}/client-app/customer-auth`);
        return { success: true };
    } catch (error) {
        console.error("Error updating customer name:", error);
        return { success: false, error: 'Failed to update name.' };
    }
}

export async function hasSmsEnabled(business: any) {
    return !!business?.enableSms;
}

export async function findNextAvailableDay(businessId: string, serviceDuration: number, allStaff: Staff[]): Promise<string | null> {
    const business = await getBusiness(businessId);
    if (!business) return null;
    
    const { events } = await getConsolidatedAvailability(businessId);

    const timeZone = business.timezone || 'UTC';
    let minBookingDateTime = toZonedTime(new Date(), timeZone);
    if (business.leadTimeValue && business.leadTimeUnit) {
         switch(business.leadTimeUnit) {
            case 'minutes': minBookingDateTime = addMinutes(minBookingDateTime, business.leadTimeValue); break;
            case 'hours': minBookingDateTime = addHours(minBookingDateTime, business.leadTimeValue); break;
            case 'days': minBookingDateTime = addDays(minBookingDateTime, business.leadTimeValue); break;
        }
    }
    
    let startDate = startOfDay(minBookingDateTime);

    for (let i = 0; i < 60; i++) { // Check up to 60 days in the future
        const dateToCheck = addDays(startDate, i);
        const dayOfWeekName = format(dateToCheck, 'EEEE', { locale: enUS });
        const workingStaff = allStaff.filter(staff => {
             const dayAvailability = staff.availability.find(a => a.day === dayOfWeekName);
             return dayAvailability && dayAvailability.working;
        });

        if (workingStaff.length > 0) {
            return format(dateToCheck, 'yyyy-MM-dd');
        }
    }
    return null;
}

export async function getConsolidatedAvailability(businessId: string): Promise<{ events: any[], lastUpdated: number | null }> {
    try {
        const [schedulesSnapshot, lastUpdatedSnapshot] = await Promise.all([
            db.ref(`schedules/${businessId}`).once('value'),
            db.ref(`businesses/${businessId}/scheduleLastUpdated`).once('value')
        ]);

        const allEvents: any[] = [];
        if (schedulesSnapshot.exists()) {
            const allSchedules = schedulesSnapshot.val();
            for (const staffId in allSchedules) {
                const staffSchedule = allSchedules[staffId];
                for (const eventId in staffSchedule) {
                    const eventData = staffSchedule[eventId];
                    allEvents.push({ id: eventId, staffId, ...eventData });
                }
            }
        }
        const lastUpdated = lastUpdatedSnapshot.exists() ? lastUpdatedSnapshot.val() : null;
        
        return { events: allEvents, lastUpdated };
    } catch (error) {
        console.error("Error getting consolidated availability:", error);
        return { events: [], lastUpdated: null };
    }
}

const rescheduleSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.string().regex(/^\d{2}:\d{2}$/),
  staffId: z.string(),
  staffName: z.string(),
});

export async function rescheduleBooking(businessId: string, bookingId: string, oldStaffId: string, data: z.infer<typeof rescheduleSchema>) {
    const validationResult = rescheduleSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, error: 'Invalid rescheduling data provided.' };
    }
    
    try {
        const oldBookingRef = db.ref(`schedules/${businessId}/${oldStaffId}/${bookingId}`);
        const snapshot = await oldBookingRef.once('value');
        if (!snapshot.exists()) {
            return { success: false, error: 'Booking not found.' };
        }
        const oldBooking = snapshot.val();

        const newBookingData = {
            ...oldBooking,
            ...validationResult.data,
            status: 'waiting', // This is the crucial fix
            serviceStartTime: null, 
            updatedAt: serverTimestamp
        };

        // If staff member is changed, we need to move the booking in the DB
        if (oldStaffId !== validationResult.data.staffId) {
            const newBookingRef = db.ref(`schedules/${businessId}/${validationResult.data.staffId}/${bookingId}`);
            await newBookingRef.set(newBookingData);
            await oldBookingRef.remove();
        } else {
            await oldBookingRef.update(newBookingData);
        }
        
        await sendRescheduleSms(businessId, oldBooking, validationResult.data.date, validationResult.data.time);
        await updateLastUpdatedTimestamp(businessId);

        revalidatePath(`/${businessId}/staff-app`);
        revalidatePath(`/${businessId}/client-app`);

        return { success: true };
    } catch (error) {
        console.error("Error rescheduling booking:", error);
        return { success: false, error: 'Failed to reschedule the booking.' };
    }
}

export async function getBusinessBookings(businessId: string): Promise<AggregatedBooking[]> {
  try {
    const scheduleRef = db.ref(`schedules/${businessId}`);
    const scheduleSnapshot = await scheduleRef.once('value');

    if (!scheduleSnapshot.exists()) {
      return [];
    }

    const allBookings: AggregatedBooking[] = [];
    const staffSchedules = scheduleSnapshot.val();
    
    for (const staffId in staffSchedules) {
        const bookings = staffSchedules[staffId];
        for (const bookingId in bookings) {
            const booking = bookings[bookingId];
            if (booking.type === 'booking') {
                 allBookings.push({
                    ...booking,
                    id: bookingId,
                    bookingId,
                    dateTime: parse(`${booking.date} ${booking.time}`, 'yyyy-MM-dd HH:mm', new Date()).getTime(),
                 });
            }
        }
    }
   
    return allBookings.sort((a, b) => b.dateTime - a.dateTime);
  } catch (error) {
    console.error(`Error fetching bookings for business ${businessId}:`, error);
    return [];
  }
}

export async function getBusinessCustomers(businessId: string): Promise<BusinessCustomer[]> {
  try {
    const customersRef = db.ref(`businesses/${businessId}/customers`);
    const customersSnapshot = await customersRef.once('value');

    if (!customersSnapshot.exists()) {
      return [];
    }
    const customersData = customersSnapshot.val();
    
    const customers: BusinessCustomer[] = [];
    for(const customerId in customersData) {
        const customer = customersData[customerId];
        customers.push({
            id: customerId,
            ...customer,
            createdAt: customer.createdAt ? format(new Date(customer.createdAt), 'yyyy-MM-dd') : '',
            lastSeen: customer.lastSeen ? format(new Date(customer.lastSeen), 'yyyy-MM-dd') : '',
        })
    }
    
    return customers.sort((a,b) => (a.name || '').localeCompare(b.name || ''));
  } catch (error) {
    console.error(`Error fetching customers for business ${businessId}:`, error);
    return [];
  }
}

export async function getServicesAndExtensions(businessId: string): Promise<{ services: Service[], extensions: Extension[], categories: any[] }> {
    const categories = await getCategories(businessId);
    const extensions = await getExtensions(businessId);
    const services = categories.flatMap(c => c.services || []);
    return { services, extensions, categories };
}

export async function updateBookingStatus(businessId: string, bookingId: string, staffId: string, status: 'cancelled'): Promise<{ success: boolean; error?: string }> {
    try {
        const bookingRef = db.ref(`schedules/${businessId}/${staffId}/${bookingId}`);
        
        const snapshot = await bookingRef.once('value');
        if (!snapshot.exists()) {
            return { success: false, error: 'Booking not found.' };
        }
        const bookingData = snapshot.val();

        const updates: any = { status };

        await bookingRef.update(updates);
        await updateLastUpdatedTimestamp(businessId);
        
        if (status === 'cancelled') {
            await sendCancellationSms(businessId, bookingData);
        }

        revalidatePath(`/${businessId}/staff-app`);
        revalidatePath(`/${businessId}/client-app`);

        return { success: true };
    } catch (error) {
        console.error("Error updating booking status:", error);
        return { success: false, error: 'Failed to update booking status.' };
    }
}

export async function sendYourTurnSoonSms(businessId: string, bookingId: string, staffId: string): Promise<{ success: boolean; error?: string }> {
    const bookingRef = db.ref(`schedules/${businessId}/${staffId}/${bookingId}`);
    const bookingSnapshot = await bookingRef.once('value');
    if (!bookingSnapshot.exists()) {
        return { success: false, error: 'Booking not found.' };
    }
    const booking = bookingSnapshot.val();
    
    const business = await getBusiness(businessId);
    if (!business || !(await hasSmsEnabled(business)) || !business.smsYourTurnSoonTemplate) {
        return { success: false, error: 'SMS feature or template not configured.' };
    }
    
    const smsClient = await getSmsClient(businessId);
    if(!smsClient) return { success: false, error: 'SMS client not available.'};

    try {
        const lang = business.smsLanguage || 'bs';
        const template = business.smsYourTurnSoonTemplate?.[lang] || 'Your turn is soon at {{businessName}}. Please head to our location.';
        const text = template
            .replace(/{{businessName}}/g, business.businessName);
        
        await smsClient.send({
            to: booking.customerPhone,
            from: await formatSenderId(business.businessName),
            text,
        });
        
        await bookingRef.update({ yourTurnSoonSmsSentAt: new Date().toISOString() });
        await updateLastUpdatedTimestamp(businessId);

        revalidatePath(`/${businessId}/staff-app`);
        
        return { success: true };

    } catch (error) {
        console.error("Failed to send 'your turn soon' SMS:", error);
        return { success: false, error: "Failed to send notification." };
    }
}

export async function deleteBooking(businessId: string, staffId: string, bookingId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const bookingRef = db.ref(`schedules/${businessId}/${staffId}/${bookingId}`);
        await bookingRef.remove();
        await updateLastUpdatedTimestamp(businessId);
        revalidatePath(`/${businessId}/staff-app`);
        revalidatePath(`/${businessId}/client-app`);
        return { success: true };
    } catch (error) {
        console.error("Error deleting booking:", error);
        return { success: false, error: "Failed to delete booking." };
    }
}

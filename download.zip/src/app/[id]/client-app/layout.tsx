
import { Toaster } from "@/components/ui/toaster";
import { getBusinessBySlug, getBusiness } from "@/app/super-admin/businesses/actions";
import '../../globals.css';
import { PT_Sans } from "next/font/google";
import { cn } from "@/lib/utils";
import { CustomerProvider, AvailabilityProvider } from "./providers";
import * as React from "react";
import { notFound } from 'next/navigation';
import type { Metadata, ResolvingMetadata } from 'next'

const ptSans = PT_Sans({
    subsets: ["latin"],
    weight: ["400", "700"],
    variable: '--font-body',
});

// Helper to convert hex to HSL string for CSS variables
const hexToHslString = (hex: string): string | undefined => {
    if (!hex) return undefined;
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 7) {
        r = parseInt(hex.substring(1, 3), 16);
        g = parseInt(hex.substring(3, 5), 16);
        b = parseInt(hex.substring(5, 7), 16);
    } else {
        return undefined;
    }

    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }

    h = Math.round(h * 360);
    s = Math.round(s * 100);
    l = Math.round(l * 100);
    
    return `${h} ${s}% ${l}%`;
};

type Props = {
  params: Promise<{ id: string }>;
}

export async function generateMetadata(
  { params }: Props,
  parent: ResolvingMetadata
): Promise<Metadata> {
  const { id } = await params;
  let business = await getBusinessBySlug(id);
  if (!business) {
    business = await getBusiness(id);
  }
 
  if (!business) {
    return {
        title: 'Business Not Found'
    }
  }
 
  return {
    title: business.metaTitle || business.businessName,
    description: business.metaDescription || `Book your next appointment with ${business.businessName}.`,
    manifest: `/${id}/client-app/manifest`,
    openGraph: {
        title: business.metaTitle || business.businessName,
        description: business.metaDescription || '',
        images: business.metaImageUrl ? [business.metaImageUrl] : [],
    }
  }
}

export default async function BusinessLayout({
    children,
    params
}: {
    children: React.ReactNode;
    params: Promise<{ id: string }>;
}) {
    const { id: businessIdOrSlug } = await params;
    let business = await getBusinessBySlug(businessIdOrSlug);
    if (!business) {
        business = await getBusiness(businessIdOrSlug);
    }

    if (!business) {
        notFound();
    }
    
    const backgroundHsl = business?.enableCustomDesign ? hexToHslString(business.backgroundColor) : undefined;
    const primaryHsl = business?.enableCustomDesign ? hexToHslString(business.primaryColor) : undefined;
    
    const customStyles = business?.enableCustomDesign ? {
        '--background': backgroundHsl,
        '--primary': primaryHsl,
        '--ring': primaryHsl,
    } as React.CSSProperties : {};
    
    return (
        <div lang={business.language || 'en'} className={cn(ptSans.variable, business.theme === 'dark' ? 'dark' : '')} style={customStyles}>
            <CustomerProvider>
                <AvailabilityProvider businessId={business.id}>
                    {children}
                    <Toaster />
                </AvailabilityProvider>
            </CustomerProvider>
        </div>
    );
}

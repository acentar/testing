
'use client';

import * as React from 'react';
import type { Customer } from './customer-schema';
import { getConsolidatedAvailability } from './actions';
import { onValue, ref, onDisconnect, set, getDatabase } from 'firebase/database';
import { app } from '@/lib/firebase';
import { useAuth } from '@/app/super-admin/auth/provider';

const rtdb = getDatabase(app);

// --- Customer Auth Context ---
interface CustomerAuthContextType {
    customer: Customer | null;
    setCustomer: (customer: Customer | null) => void;
    signOut: () => void;
}

const CustomerAuthContext = React.createContext<CustomerAuthContextType | null>(null);

export const useCustomer = () => {
    const context = React.useContext(CustomerAuthContext);
    if (!context) {
        throw new Error("useCustomer must be used within a CustomerAuthProvider");
    }
    return context;
};

export const CustomerProvider = ({ children }: { children: React.ReactNode }) => {
    const [customer, setCustomerState] = React.useState<Customer | null>(null);

    React.useEffect(() => {
        try {
            const storedCustomer = localStorage.getItem('customer');
            if (storedCustomer) {
                setCustomerState(JSON.parse(storedCustomer));
            }
        } catch (error) {
            console.error("Failed to parse customer from localStorage", error);
            localStorage.removeItem('customer');
        }
    }, []);

    const setCustomer = (customerData: Customer | null) => {
        setCustomerState(customerData);
        if (customerData) {
            localStorage.setItem('customer', JSON.stringify(customerData));
        } else {
            localStorage.removeItem('customer');
        }
    };
    
    const signOut = () => {
        setCustomer(null);
    }

    return (
        <CustomerAuthContext.Provider value={{ customer, setCustomer, signOut }}>
            {children}
        </CustomerAuthContext.Provider>
    );
};


// --- Availability Context ---
interface AvailabilityContextType {
  availabilityData: any[] | null;
  isLoading: boolean;
}

const AvailabilityContext = React.createContext<AvailabilityContextType | null>(null);

export const useAvailability = (initialAvailability: any[]) => {
    const context = React.useContext(AvailabilityContext);
    if (!context) {
        throw new Error("useAvailability must be used within an AvailabilityProvider");
    }
    return { ...context, availabilityData: context.availabilityData ?? initialAvailability };
};

export const AvailabilityProvider = ({ businessId, children }: { businessId: string; children: React.ReactNode }) => {
    const [availabilityData, setAvailabilityData] = React.useState<any[] | null>(null);
    const [isLoading, setIsLoading] = React.useState(true);

    const fetchAvailability = React.useCallback(async () => {
        setIsLoading(true); // Ensure loading is true at the start of a fetch
        const { events } = await getConsolidatedAvailability(businessId);
        setAvailabilityData(events);
        setIsLoading(false);
    }, [businessId]);

    React.useEffect(() => {
        fetchAvailability();
        
        const scheduleLastUpdatedRef = ref(rtdb, `businesses/${businessId}/scheduleLastUpdated`);
        const unsubscribe = onValue(scheduleLastUpdatedRef, async () => {
             await fetchAvailability(); // Await the fetch on update
        });

        return () => unsubscribe();
    }, [fetchAvailability, businessId]);

    return (
        <AvailabilityContext.Provider value={{ availabilityData, isLoading }}>
            {children}
        </AvailabilityContext.Provider>
    );
};

export function BusinessPresenceTracker({ businessName, businessId }: { businessName: string, businessId: string }) {
    const { customer } = useCustomer();

    React.useEffect(() => {
        if (!customer) return;

        const presenceRef = ref(rtdb, `presence/${customer.id}`);
        const disconnectRef = onDisconnect(presenceRef);
    
        set(presenceRef, {
            name: customer.name,
            phone: customer.phone,
            businessName,
            businessId,
            page: 'Booking Page (I3)',
            timestamp: new Date().toISOString()
        });

        disconnectRef.remove();

    }, [customer, businessName, businessId]);

    return null;
}

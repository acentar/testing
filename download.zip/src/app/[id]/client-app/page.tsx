
import { BusinessLandingPageWrapper } from "./page-client";
import { getBusiness, getBusinessBySlug } from '../../super-admin/businesses/actions';
import { getCategories } from '../../super-admin/businesses/[id]/services/actions';
import { hasSmsEnabled } from './actions';
import { getGlobalSettings } from '../../super-admin/settings/actions';
import { notFound } from 'next/navigation';
import * as React from 'react';

export default async function BusinessBookingPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: businessIdOrSlug } = await params;
    
    let businessData = await getBusinessBySlug(businessIdOrSlug);
    if (!businessData) {
        businessData = await getBusiness(businessIdOrSlug);
    }

    if (!businessData) {
        notFound();
    }

    const [categoriesData, smsData, settings] = await Promise.all([
        getCategories(businessData.id),
        hasSmsEnabled(businessData),
        getGlobalSettings(),
    ]);

    return (
        <BusinessLandingPageWrapper
            business={businessData}
            categories={categoriesData}
            smsEnabled={smsData}
            globalSettings={settings.general || {}}
        />
    );
}


'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { FormattedPrice } from '@/components/formatted-price';
import { MapPin, Wifi, Clock, Phone, FileText, Mail, ChevronRight, Loader2 } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { CustomerAuth } from './customer-auth';
import type { Category } from '@/app/super-admin/businesses/[id]/services/schema';
import { format, type Locale } from 'date-fns';
import { enUS, bs, da } from 'date-fns/locale';

interface BusinessLandingPageProps {
    business: any;
    categories: Category[];
    smsEnabled: boolean;
    globalSettings: any;
}

const translations = {
  en: {
    ourServices: "Our Services",
    bookNow: "Book",
    aboutUs: "About Us",
    ourLocation: "Our Location",
    operatingHours: "Operating Hours",
    liveWaitTime: "Live Wait Time",
    open: "Open",
    closed: "Closed",
    closesAt: "Closes at",
    contactInfo: "Contact Information",
    bookingPolicy: "Booking Policy",
    viewOnGoogleMaps: "View on Google Maps",
    checkingStatus: "Checking status...",
  },
  bs: {
    ourServices: "Naše usluge",
    bookNow: "Rezerviši",
    aboutUs: "O nama",
    ourLocation: "Naša lokacija",
    operatingHours: "Radno vrijeme",
    liveWaitTime: "Vrijeme čekanja uživo",
    open: "Otvoreno",
    closed: "Zatvoreno",
    closesAt: "Zatvara se u",
    contactInfo: "Kontakt informacije",
    bookingPolicy: "Pravila rezervacije",
    viewOnGoogleMaps: "Prikaži na Google kartama",
    checkingStatus: "Provjera statusa...",
  },
  da: {
    ourServices: "Vores ydelser",
    bookNow: "Book",
    aboutUs: "Om os",
    ourLocation: "Vores placering",
    operatingHours: "Åbningstider",
    liveWaitTime: "Live ventetid",
    open: "Åben",
    closed: "Lukket",
    closesAt: "Lukker kl",
    contactInfo: "Kontaktinformation",
    bookingPolicy: "Bookingpolitik",
    viewOnGoogleMaps: "Vis på Google Maps",
    checkingStatus: "Tjekker status...",
  }
};

type Language = 'en' | 'bs' | 'da';

const dayMap = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const LiveClock = ({ locale }: { locale: Locale }) => {
    const [time, setTime] = React.useState<Date | null>(null);

    React.useEffect(() => {
        setTime(new Date());
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="text-center">
            <p className="text-3xl font-bold">{time ? format(time, 'HH:mm') : '--:--'}</p>
            <p className="text-muted-foreground capitalize">{time ? format(time, 'eeee, LLL d', { locale }) : '...'}</p>
        </div>
    );
};

export function BusinessLandingPageWrapper({ business, categories, smsEnabled, globalSettings }: BusinessLandingPageProps) {
    const language: Language = business.language || 'bs';
    const t = translations[language];
    const locale: Locale = language === 'da' ? da : language === 'en' ? enUS : bs;
    const businessId = business.id;
    const appName = globalSettings.appName || 'Bestiller';

    const [isOpen, setIsOpen] = React.useState<boolean | null>(null);
    const [todayHours, setTodayHours] = React.useState<any>(null);

    React.useEffect(() => {
        const today = new Date();
        const dayName = dayMap[today.getDay()];
        const currentTodayHours = business.operatingHours?.find((h: any) => h.day === dayName);
        setTodayHours(currentTodayHours);

        if (!currentTodayHours || !currentTodayHours.working) {
            setIsOpen(false);
            return;
        }

        const now = today.getHours() * 60 + today.getMinutes();
        const from = parseInt(currentTodayHours.from.split(':')[0]) * 60 + parseInt(currentTodayHours.from.split(':')[1]);
        const to = parseInt(currentTodayHours.to.split(':')[0]) * 60 + parseInt(currentTodayHours.to.split(':')[1]);
        
        if (to < from) { // Handles overnight hours
            setIsOpen(now >= from || now < to);
        } else {
            setIsOpen(now >= from && now < to);
        }
    }, [business.operatingHours]);
    
    const googleMapsUrl = business.address?.street ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.businessName + ', ' + business.address.street + ', ' + business.address.city)}` : '#';

    return (
        <div className="flex flex-col min-h-screen bg-muted/40">
            <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-sm border-b">
                <div className="container mx-auto px-4 md:px-8 flex h-20 items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link href={`/${business.slug || business.id}/client-app`} className="relative h-12 w-36">
                        {business.logoUrl ? (
                            <Image 
                                src={business.logoUrl} 
                                alt={`${business.businessName} logo`} 
                                fill
                                style={{objectFit: "contain", objectPosition: "left"}}
                                priority
                                unoptimized
                            />
                        ) : (
                        <h1 className="text-2xl font-bold">{business.businessName}</h1>
                        )}
                    </Link>
                    </div>
                    <CustomerAuth 
                    businessId={businessId}
                    hasSmsEnabled={smsEnabled}
                    allowedPhoneCountries={business.allowedPhoneCountries || []}
                    language={language}
                    />
                </div>
            </header>

            <main className="container mx-auto flex-1 px-4 md:px-8 py-8">
                <div className="grid md:grid-cols-3 gap-8 items-start">
                    <div className="md:col-span-2 space-y-4">

                        <Card>
                            <CardHeader>
                                <CardTitle>{t.ourServices}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Accordion type="multiple" defaultValue={categories.map(c => c.id)} className="w-full space-y-6">
                                    {categories.map((category) => (
                                        <AccordionItem value={category.id} key={category.id} className="border-b-0">
                                            <AccordionTrigger className="p-0 text-sm font-semibold uppercase tracking-wider text-muted-foreground hover:no-underline">
                                                {category.name}
                                            </AccordionTrigger>
                                            <AccordionContent className="p-0 border-t-0 pt-2">
                                            <div className="space-y-1">
                                                {category.services?.map((service: any) => (
                                                <Link key={service.id} href={`/${businessId}/client-app/book/${service.id}`} className="flex justify-between items-center p-4 rounded-lg hover:bg-muted transition-colors border">
                                                    <div>
                                                        <h4 className="font-semibold">{service.name}</h4>
                                                        <p className="text-sm text-muted-foreground">{service.duration} min</p>
                                                    </div>
                                                    <div className="text-right flex items-center gap-4">
                                                        <p className="font-semibold">
                                                            <FormattedPrice price={service.price} currency={business.currency || 'DKK'} />
                                                        </p>
                                                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                                                    </div>
                                                </Link>
                                                ))}
                                            </div>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            </CardContent>
                        </Card>
                         
                    </div>
                    <aside className="space-y-4">
                         <Card className="text-center">
                            <CardContent className="pt-6">
                                <LiveClock locale={locale} />
                            </CardContent>
                        </Card>
                        {business.showOperatingHours && (
                            <Card>
                                <CardHeader>
                                    <Accordion type="single" collapsible>
                                        <AccordionItem value="item-1" className="border-b-0">
                                            <AccordionTrigger className="p-0 hover:no-underline">
                                                 <div className="flex items-center gap-2">
                                                    {isOpen === null ? (
                                                        <>
                                                            <Loader2 className="h-3 w-3 animate-spin" />
                                                            <span className="font-semibold text-muted-foreground">{t.checkingStatus}</span>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <div className={`w-3 h-3 rounded-full ${isOpen ? 'bg-green-500' : 'bg-red-500'}`}></div>
                                                            <span className="font-semibold">{isOpen ? t.open : t.closed}</span>
                                                            {isOpen && todayHours && <span className="text-sm text-muted-foreground">&middot; {t.closesAt} {todayHours.to}</span>}
                                                        </>
                                                    )}
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent className="pt-4">
                                                 <div className="space-y-2 text-sm">
                                                    {business.operatingHours.map((hours: any) => (
                                                        <div key={hours.day} className="flex justify-between">
                                                            <span className="font-medium text-muted-foreground capitalize">{hours.day.toLowerCase()}</span>
                                                            <span className="font-mono">{hours.working ? `${hours.from} - ${hours.to}` : t.closed}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </AccordionContent>
                                        </AccordionItem>
                                    </Accordion>
                                </CardHeader>
                            </Card>
                        )}
                        <Card>
                             <CardHeader className="flex flex-row items-center gap-3">
                                <MapPin className="h-5 w-5 text-muted-foreground" />
                                <CardTitle className="text-base">{t.ourLocation}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2 text-sm">
                                <p className="font-semibold">{business.businessName}</p>
                                <p className="text-muted-foreground">{business.address.street}, {business.address.postalCode} {business.address.city}, {business.address.country}</p>
                                <a href={googleMapsUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline pt-2 inline-block">
                                    {t.viewOnGoogleMaps}
                                </a>
                            </CardContent>
                        </Card>
                         <Card>
                            <CardHeader className="flex flex-row items-center gap-3">
                                <Phone className="h-5 w-5 text-muted-foreground" />
                                <CardTitle className="text-base">{t.contactInfo}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2 text-sm">
                                {business.businessPhone && (
                                    <a href={`tel:${business.businessPhone}`} className="flex items-center gap-2 hover:text-primary">
                                        <Phone className="h-4 w-4" />
                                        {business.businessPhone}
                                    </a>
                                )}
                                {business.businessEmail && (
                                    <a href={`mailto:${business.businessEmail}`} className="flex items-center gap-2 hover:text-primary">
                                        <Mail className="h-4 w-4" />
                                        {business.businessEmail}
                                    </a>
                                )}
                                {business.bookingPolicy && (
                                     <Link href="#" className="flex items-center gap-2 hover:text-primary pt-2">
                                        <FileText className="h-4 w-4" />
                                        {t.bookingPolicy}
                                    </Link>
                                )}
                            </CardContent>
                        </Card>
                    </aside>
                </div>
            </main>
            <footer className="border-t bg-background/50">
                <div className="container mx-auto p-4 text-center text-xs text-muted-foreground">
                    &copy; {new Date().getFullYear()} {business.businessName}. All rights reserved.
                </div>
            </footer>
        </div>
    );
}


import { getBusiness, getBusinessBySlug } from "@/app/super-admin/businesses/actions";
import { type NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  let business = await getBusinessBySlug(id);
  if (!business) {
      business = await getBusiness(id);
  }

  if (!business || !business.enablePwa) {
    return new NextResponse("Not Found", { status: 404 });
  }

  const manifest = {
    name: business.businessName,
    short_name: business.pwaShortName || business.businessName,
    description: business.metaDescription || `Book your next appointment with ${business.businessName}.`,
    start_url: `/${id}/client-app`,
    display: "standalone",
    background_color: business.pwaBackgroundColor || "#ffffff",
    theme_color: business.pwaThemeColor || "#000000",
    icons: [
      {
        src: business.pwaIcon192Url || "/icons/icon-192x192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: business.pwaIcon512Url || "/icons/icon-512x512.png",
        sizes: "512x512",
        type: "image/png",
      },
      business.pwaMaskableIconUrl ? {
        src: business.pwaMaskableIconUrl,
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      } : undefined,
    ].filter(Boolean),
  };

  return new NextResponse(JSON.stringify(manifest), {
    headers: {
      "Content-Type": "application/manifest+json",
    },
  });
}

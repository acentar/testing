
import { z } from 'zod';

const getPhoneSchema = (countries: ('DK' | 'BA')[]) => {
  return z.string().refine(value => {
    // If no specific countries are enforced, any valid international number is ok
    if (!countries || countries.length === 0) {
      const phoneRegex = /^\+\d{1,3}\d{4,14}$/;
      return phoneRegex.test(value);
    }
    
    // Danish numbers: +45 followed by 8 digits
    if (countries.includes('DK') && value.startsWith('+45') && value.length === 11) return true;
    
    // Bosnian numbers: +387 followed by 8 or 9 digits
    if (countries.includes('BA') && value.startsWith('+387') && (value.length === 12 || value.length === 13)) return true;

    return false;
  }, 'Please enter a valid phone number for the selected region.');
};

export const bookingSchema = (allowedPhoneCountries: ('DK' | 'BA')[], fromStaffScreen = false) => z.object({
  serviceId: z.string(),
  serviceName: z.string(),
  extensions: z.array(z.object({
      id: z.string(),
      name: z.string(),
      price: z.number(),
      duration: z.number()
  })).optional(),
  staffId: z.string(),
  staffName: z.string(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format'),
  time: z.string().regex(/^\d{2}:\d{2}$/, 'Invalid time format'),
  customerName: z.string().min(2, 'Full name is required.'),
  customerPhone: getPhoneSchema(allowedPhoneCountries),
  totalPrice: z.number(),
  totalDuration: z.number(),
  status: z.enum(['waiting', 'in-progress', 'completed', 'cancelled']).optional(),
  serviceStartTime: z.string().optional(),
  
  sendSms: z.boolean().default(true),
  
  // This is for new (un-authenticated) customers from the public page
  verificationCode: z.string().optional(),
  verificationId: z.string().optional(),

  // This is for existing (authenticated) customers
  customerId: z.string().optional(),
});

export type BookingFormData = z.infer<ReturnType<typeof bookingSchema>>;

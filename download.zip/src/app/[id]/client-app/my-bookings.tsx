
'use client';

import * as React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { format, type Locale } from 'date-fns';
import { enUS, bs, da } from 'date-fns/locale';
import { Loader2, Trash2 } from 'lucide-react';
import { cancelBooking, getCustomerBookings, type CustomerBooking } from './actions';
import { useCustomer } from './providers';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';

const translations = {
  en: {
    with: "with",
    areYouSure: "Are you sure?",
    cancelBookingConfirmation: "This will permanently cancel your booking for {{serviceName}} on {{date}} at {{time}}.",
    nevermind: "Nevermind",
    yesCancel: "Yes, cancel it",
    bookingCancelled: "Booking cancelled",
    bookingCancelledSuccess: "Your appointment has been successfully cancelled.",
    error: "Error",
    yourReservations: "Your reservations",
    noUpcomingBookings: "You have no upcoming bookings.",
  },
  bs: {
    with: "kod",
    areYouSure: "Jeste li sigurni?",
    cancelBookingConfirmation: "Ovo će trajno otkazati vašu rezervaciju za {{serviceName}} dana {{date}} u {{time}}.",
    nevermind: "Odustani",
    yesCancel: "Da, otkaži",
    bookingCancelled: "Rezervacija otkazana",
    bookingCancelledSuccess: "Vaš termin je uspješno otkazan.",
    error: "Greška",
    yourReservations: "Vaše rezervacije",
    noUpcomingBookings: "Nemate nadolazećih rezervacija.",
  },
  da: {
    with: "med",
    areYouSure: "Er du sikker?",
    cancelBookingConfirmation: "Dette vil permanent annullere din booking for {{serviceName}} den {{date}} kl. {{time}}.",
    nevermind: "Aldrig sind",
    yesCancel: "Ja, annuller den",
    bookingCancelled: "Booking annulleret",
    bookingCancelledSuccess: "Din aftale er blevet annulleret.",
    error: "Fejl",
    yourReservations: "Dine reservationer",
    noUpcomingBookings: "Du har ingen kommende bookinger.",
  }
};

type Language = keyof typeof translations;

interface MyBookingsProps {
  businessId: string;
  language: Language;
}

export function MyBookings({ businessId, language = 'bs' }: MyBookingsProps) {
  const { customer } = useCustomer();
  const [bookings, setBookings] = React.useState<CustomerBooking[]>([]);
  const [loading, setLoading] = React.useState(true);
  const { toast } = useToast();
  const t = translations[language];
  const locale: Locale = language === 'bs' ? bs : language === 'da' ? da : enUS;

  const fetchBookings = React.useCallback(async () => {
    if (!customer) {
      setLoading(false);
      setBookings([]);
      return;
    }
    setLoading(true);
    try {
      const customerBookings = await getCustomerBookings(businessId, customer.id);
      setBookings(customerBookings);
    } catch (error) {
      console.error("Failed to fetch bookings:", error);
      setBookings([]);
    } finally {
      setLoading(false);
    }
  }, [businessId, customer]);

  React.useEffect(() => {
    fetchBookings();
  }, [customer, fetchBookings]);

  const handleCancelBooking = async (booking: CustomerBooking) => {
    const result = await cancelBooking(businessId, booking.id, booking.staffId);
    if (result.success) {
      toast({ title: t.bookingCancelled, description: t.bookingCancelledSuccess });
      fetchBookings();
    } else {
      toast({ variant: 'destructive', title: t.error, description: result.error });
    }
  };
  
  return (
    <Card className="border-0 shadow-none">
        <CardHeader>
            <CardTitle>{t.yourReservations}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
        {loading ? (
            <div className="flex items-center justify-center h-24">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
        ) : bookings.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">{t.noUpcomingBookings}</p>
        ) : (
            bookings.map(booking => (
                <div key={booking.id} className="flex justify-between items-center border p-3 rounded-md">
                    <div>
                        <p className="font-semibold">{booking.serviceName} {t.with} {booking.staffName}</p>
                        <p className="text-sm text-muted-foreground">{format(new Date(booking.date), 'EEEE, LLL d', { locale })} at {booking.time}</p>
                    </div>
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive">
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>{t.areYouSure}</AlertDialogTitle>
                                <AlertDialogDescription>
                                    {t.cancelBookingConfirmation
                                        .replace("{{serviceName}}", booking.serviceName)
                                        .replace("{{date}}", format(new Date(booking.date), 'LLL d', { locale }))
                                        .replace("{{time}}", booking.time)}
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>{t.nevermind}</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleCancelBooking(booking)}>{t.yesCancel}</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
            ))
        )}
        </CardContent>
    </Card>
  );
}

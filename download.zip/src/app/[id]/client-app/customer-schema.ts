
import { z } from 'zod';

const phoneRegex = /^\+?[1-9]\d{1,14}$/;

export const customerSchema = z.object({
  id: z.string(),
  name: z.string().min(2, 'Name must be at least 2 characters.'),
  phone: z.string().regex(phoneRegex, 'A valid international phone number is required.'),
  createdAt: z.string().optional(),
  lastSeen: z.string().optional(),
});

export type Customer = z.infer<typeof customerSchema>;

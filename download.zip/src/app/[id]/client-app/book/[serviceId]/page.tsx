
import * as React from 'react';
import { getBusiness, getBusinessBySlug } from "@/app/super-admin/businesses/actions";
import { notFound } from "next/navigation";
import { getCategories, getExtensions } from "@/app/super-admin/businesses/[id]/services/actions";
import { hasSmsEnabled as checkSmsEnabled } from '../../actions';
import { getStaff } from "@/app/super-admin/businesses/[id]/staff/actions";
import { BookingFlow } from "../../booking-flow";
import { type Service, type Extension } from '@/app/super-admin/businesses/[id]/services/schema';
import { type Staff } from '@/app/super-admin/businesses/[id]/staff/schema';

interface PageProps {
  params: Promise<{ id: string; serviceId: string; }>;
}

export default async function BookServicePage({ params }: PageProps) {
    const { id, serviceId } = await params;

    let business = await getBusinessBySlug(id);
    if (!business) {
        business = await getBusiness(id);
    }
    
    if (!business) {
        notFound();
    }

    const businessId = business.id;
    const [categoriesData, extensionsData, staffData, smsEnabled] = await Promise.all([
        getCategories(businessId),
        getExtensions(businessId),
        getStaff(businessId),
        checkSmsEnabled(business),
    ]);

    const allServices = categoriesData.flatMap(c => c.services || []);
    const service = allServices.find(s => s.id === serviceId);

    if (!service) {
        notFound();
    }

    return (
       <BookingFlow 
         business={business}
         service={service}
         allExtensions={extensionsData}
         allStaff={staffData}
         hasSmsEnabled={smsEnabled}
       />
    );
}

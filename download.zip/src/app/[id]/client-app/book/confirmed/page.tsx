
'use client';

import * as React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useParams } from 'next/navigation';
import { Check } from 'lucide-react';
import Link from 'next/link';

const translations = {
    en: {
        bookingConfirmed: 'Booking Confirmed',
        description: 'Your appointment is set. You will receive a confirmation message shortly.',
        backToHome: 'Back to home',
        bookAnother: 'Book another appointment',
    },
    bs: {
        bookingConfirmed: 'Rezervacija potvrđena',
        description: 'Vaš termin je zakazan. Uskoro ćete primiti potvrdnu poruku.',
        backToHome: 'Nazad na početnu',
        bookAnother: 'Zakaži novi termin',
    },
    da: {
        bookingConfirmed: 'Booking bekræftet',
        description: 'Din aftale er sat. Du vil modtage en bekræftelsesmeddelelse snarest.',
        backToHome: 'Tilbage til forsiden',
        bookAnother: 'Book en ny aftale',
    }
};

type Language = keyof typeof translations;

export default function BookingConfirmedPage() {
    const params = useParams();
    const businessId = params.id;
    const [language, setLanguage] = React.useState<Language>('bs');
    const [businessName, setBusinessName] = React.useState('');

    // This is a simple way to get language/business name without fetching again
    // In a real app, you might fetch this from a server component or context.
    React.useEffect(() => {
        const lang = sessionStorage.getItem('lastBusinessLanguage') as Language | null;
        const name = sessionStorage.getItem('lastBusinessName');
        if (lang) setLanguage(lang);
        if (name) setBusinessName(name);

        // Clean up sessionStorage
        sessionStorage.removeItem('lastBusinessLanguage');
        sessionStorage.removeItem('lastBusinessName');
    }, []);

    const t = translations[language] || translations.bs;

    return (
        <div className="flex items-center justify-center min-h-screen bg-muted">
             <Card className="w-full max-w-md shadow-2xl">
                 <CardHeader className="text-center items-center space-y-4 pt-8">
                     <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center dark:bg-green-900/50">
                        <Check className="h-10 w-10 text-green-600 dark:text-green-400" />
                    </div>
                    <CardTitle className="text-2xl">{t.bookingConfirmed}</CardTitle>
                    <CardDescription>{t.description} {businessName && `with ${businessName}`}</CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                    {/* The dynamic details have been removed to avoid reliance on sessionStorage */}
                </CardContent>
                <CardFooter className="flex flex-col gap-2 pt-6">
                    <Button size="lg" className="w-full" asChild>
                        <Link href={`/${businessId}/client-app`}>{t.backToHome}</Link>
                    </Button>
                     <Button size="lg" variant="outline" className="w-full" asChild>
                        <Link href={`/${businessId}/client-app`}>{t.bookAnother}</Link>
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}


'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { sendLoginSms, verifyLoginCode, updateCustomerName } from './actions';
import { ChevronDown, Loader2, LogIn, LogOut, Ticket, User } from 'lucide-react';
import { Customer } from './customer-schema';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { PhoneInput } from '@/components/phone-input';
import { useCustomer } from './providers';
import { MyBookings } from './my-bookings';

const translations = {
  en: {
    signIn: "Sign In",
    myBookings: "My Bookings",
    editProfile: "Edit Profile",
    signOut: "Sign Out",
    changeName: "Change your name",
    welcome: "Welcome! What should we call you?",
    nameUsedForBookings: "This name will be used for your bookings.",
    fullName: "Full Name",
    save: "Save",
    cancel: "Cancel",
    profileUpdated: "Profile updated",
    nameSaved: "Your name has been saved.",
    error: "Error",
    signInTitle: "Sign in",
    signInDescription: "Enter your phone number to receive a sign-in code.",
    phoneNumber: "Phone Number",
    sendCode: "Send Code",
    enterCodeTitle: "Enter Code",
    enterCodeDescription: "We sent a 4-digit code to {{phone}}.",
    verificationCode: "Verification Code",
    back: "Back",
    verify: "Verify",
    signedInSuccess: "Signed in successfully!",
    welcomeBack: "Welcome back",
    signInFailed: "Sign-in Failed",
    yourReservations: "Your reservations",
  },
  bs: {
    signIn: "Prijavi se",
    myBookings: "Moje rezervacije",
    editProfile: "Uredi profil",
    signOut: "Odjavi se",
    changeName: "Promijenite svoje ime",
    welcome: "Dobrodošli! Kako da vas zovemo?",
    nameUsedForBookings: "Ovo ime će se koristiti za vaše rezervacije.",
    fullName: "Puno ime",
    save: "Spremi",
    cancel: "Otkaži",
    profileUpdated: "Profil ažuriran",
    nameSaved: "Vaše ime je spremljeno.",
    error: "Greška",
    signInTitle: "Prijavi se",
    signInDescription: "Unesite svoj broj telefona kako biste primili kod za prijavu.",
    phoneNumber: "Broj telefona",
    sendCode: "Pošalji kod",
    enterCodeTitle: "Unesite kod",
    enterCodeDescription: "Poslali smo 4-znamenkasti kod na {{phone}}.",
    verificationCode: "Verifikacijski kod",
    back: "Nazad",
    verify: "Verificiraj",
    signedInSuccess: "Uspješno ste prijavljeni!",
    welcomeBack: "Dobrodošli nazad",
    signInFailed: "Prijava nije uspjela",
    yourReservations: "Vaše rezervacije",
  },
  da: {
    signIn: "Log ind",
    myBookings: "Mine bookinger",
    editProfile: "Rediger profil",
    signOut: "Log ud",
    changeName: "Skift dit navn",
    welcome: "Velkommen! Hvad skal vi kalde dig?",
    nameUsedForBookings: "Dette navn vil blive brugt til dine bookinger.",
    fullName: "Fulde navn",
    save: "Gem",
    cancel: "Annuller",
    profileUpdated: "Profil opdateret",
    nameSaved: "Dit navn er blevet gemt.",
    error: "Fejl",
    signInTitle: "Log ind",
    signInDescription: "Indtast dit telefonnummer for at modtage en log-in kode.",
    phoneNumber: "Telefonnummer",
    sendCode: "Send kode",
    enterCodeTitle: "Indtast kode",
    enterCodeDescription: "Vi har sendt en 4-cifret kode til {{phone}}.",
    verificationCode: "Verifikationskode",
    back: "Tilbage",
    verify: "Verificer",
    signedInSuccess: "Du er nu logget ind!",
    welcomeBack: "Velkommen tilbage",
    signInFailed: "Login mislykkedes",
    yourReservations: "Dine reservationer",
  },
};

type Language = keyof typeof translations;

const getPhoneSchema = (countries: ('DK' | 'BA')[]) => z.object({
  phone: z.string().refine(value => {
    if (!countries || countries.length === 0) {
      const phoneRegex = /^\+\d{1,3}\d{4,14}$/;
      return phoneRegex.test(value);
    }
    if (countries.includes('DK') && value.startsWith('+45') && value.length === 11) return true;
    if (countries.includes('BA') && value.startsWith('+387') && (value.length === 12 || value.length === 13)) return true;
    
    return false;
  }, 'Please enter a valid phone number.'),
});

const codeSchema = z.object({
    code: z.string().length(4, 'Code must be 4 digits.'),
});
const nameSchema = z.object({
    name: z.string().min(2, 'Name must be at least 2 characters.'),
});

interface CustomerAuthProps {
    businessId: string;
    hasSmsEnabled: boolean;
    allowedPhoneCountries: ('DK' | 'BA')[];
    language: Language;
}

export function CustomerAuth({ businessId, hasSmsEnabled, allowedPhoneCountries, language = 'bs' }: CustomerAuthProps) {
    const { customer, setCustomer, signOut } = useCustomer();
    const { toast } = useToast();
    const [open, setOpen] = React.useState(false);
    const [myBookingsOpen, setMyBookingsOpen] = React.useState(false);
    const [step, setStep] = React.useState<'phone' | 'code'>('phone');
    const [isLoading, setIsLoading] = React.useState(false);
    const [editProfileOpen, setEditProfileOpen] = React.useState(false);
    const [loginId, setLoginId] = React.useState<string | undefined>(undefined);
    const t = translations[language];

    const phoneForm = useForm<{ phone: string }>({
        resolver: zodResolver(getPhoneSchema(allowedPhoneCountries)),
        defaultValues: { phone: '' },
    });
    const codeForm = useForm<{ code: string }>({
        resolver: zodResolver(codeSchema),
        defaultValues: { code: '' },
    });
    const nameForm = useForm<{ name: string }>({
        resolver: zodResolver(nameSchema),
        defaultValues: { name: '' },
    });

    const onPhoneSubmit = async ({ phone }: { phone: string }) => {
        setIsLoading(true);
        const result = await sendLoginSms(businessId, phone);
        setIsLoading(false);
        if (result.success && result.loginId) {
            setLoginId(result.loginId);
            setStep('code');
        } else {
            toast({ variant: 'destructive', title: t.error, description: result.error });
        }
    };

    const onCodeSubmit = async ({ code }: { code: string }) => {
        if (!loginId) return;
        setIsLoading(true);
        const result = await verifyLoginCode(businessId, loginId, code);
        setIsLoading(false);
        if (result.success && result.customer) {
            setCustomer(result.customer);
            toast({ title: t.signedInSuccess, description: `${t.welcomeBack}${result.customer.name ? `, ${result.customer.name}` : ''}!` });
            setOpen(false);
            if (!result.customer.name) {
                // Prompt for name if it's their first time
                setEditProfileOpen(true);
            }
        } else {
            toast({ variant: 'destructive', title: t.signInFailed, description: result.error || 'An unexpected error occurred.' });
        }
    };

    const onNameSubmit = async ({ name }: { name: string }) => {
        if (!customer) return;
        setIsLoading(true);
        const result = await updateCustomerName(businessId, customer.id, name);
        setIsLoading(false);
        if (result.success) {
            const updatedCustomer = { ...customer, name };
            setCustomer(updatedCustomer);
            toast({ title: t.profileUpdated, description: t.nameSaved });
            setEditProfileOpen(false);
        } else {
            toast({ variant: "destructive", title: t.error, description: result.error });
        }
    };

    React.useEffect(() => {
        if (!open) {
            setTimeout(() => {
                setStep('phone');
                phoneForm.reset();
                codeForm.reset();
                setLoginId(undefined);
            }, 300)
        }
    }, [open, phoneForm, codeForm]);

    React.useEffect(() => {
        if (customer && customer.name) {
            nameForm.setValue('name', customer.name);
        } else {
            nameForm.setValue('name', '');
        }
    }, [customer, nameForm]);


    if (!hasSmsEnabled) return null;

    if (customer) {
        return (
            <div>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline">
                            <User className="mr-2 h-4 w-4" />
                            {customer.name || customer.phone}
                            <ChevronDown className="ml-2 h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem onSelect={() => setMyBookingsOpen(true)}>
                            <Ticket className="mr-2 h-4 w-4" />
                            {t.myBookings}
                        </DropdownMenuItem>
                        <DropdownMenuItem onSelect={() => setEditProfileOpen(true)}>
                            <User className="mr-2 h-4 w-4" />
                            {t.editProfile}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={signOut}>
                            <LogOut className="mr-2 h-4 w-4" />
                           {t.signOut}
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>

                <Dialog open={myBookingsOpen} onOpenChange={setMyBookingsOpen}>
                    <DialogContent>
                        <MyBookings businessId={businessId} language={language} />
                    </DialogContent>
                </Dialog>

                <Dialog open={editProfileOpen} onOpenChange={setEditProfileOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{customer.name ? t.changeName : t.welcome}</DialogTitle>
                            <DialogDescription>
                                {t.nameUsedForBookings}
                            </DialogDescription>
                        </DialogHeader>
                        <Form {...nameForm}>
                            <form onSubmit={nameForm.handleSubmit(onNameSubmit)} className="space-y-8">
                                <FormField
                                    control={nameForm.control}
                                    name="name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t.fullName}</FormLabel>
                                            <FormControl>
                                                <Input {...field} />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <DialogFooter>
                                    <DialogClose asChild>
                                        <Button type="button" variant="outline">{t.cancel}</Button>
                                    </DialogClose>
                                    <Button type="submit" disabled={isLoading}>
                                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                        {t.save}
                                    </Button>
                                </DialogFooter>
                            </form>
                        </Form>
                    </DialogContent>
                </Dialog>
            </div>
        );
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button variant="outline">
                    <LogIn className="mr-2 h-4 w-4" />
                     {t.signIn}
                </Button>
            </DialogTrigger>
            {step === 'phone' && (
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{t.signInTitle}</DialogTitle>
                        <DialogDescription>{t.signInDescription}</DialogDescription>
                    </DialogHeader>
                    <Form {...phoneForm}>
                        <form onSubmit={phoneForm.handleSubmit(onPhoneSubmit)} className="space-y-8">
                            <FormField
                                control={phoneForm.control}
                                name="phone"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t.phoneNumber}</FormLabel>
                                        <FormControl>
                                            <PhoneInput {...field} allowedCountries={allowedPhoneCountries} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter>
                                <DialogClose asChild>
                                    <Button type="button" variant="outline">{t.cancel}</Button>
                                </DialogClose>
                                <Button type="submit" disabled={isLoading}>
                                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    {t.sendCode}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            )}
            {step === 'code' && (
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{t.enterCodeTitle}</DialogTitle>
                        <DialogDescription>
                            {t.enterCodeDescription.replace("{{phone}}", phoneForm.getValues('phone'))}
                        </DialogDescription>
                    </DialogHeader>
                    <Form {...codeForm}>
                        <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-8">
                            <FormField
                                control={codeForm.control}
                                name="code"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>{t.verificationCode}</FormLabel>
                                        <FormControl>
                                            <Input type="tel" maxLength={4} {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <DialogFooter className="justify-between">
                                 <Button type="button" variant="ghost" onClick={() => setStep('phone')}>{t.back}</Button>
                                 <Button type="submit" disabled={isLoading}>
                                     {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                     {t.verify}
                                </Button>
                            </DialogFooter>
                        </form>
                    </Form>
                </DialogContent>
            )}
        </Dialog>
    );
}

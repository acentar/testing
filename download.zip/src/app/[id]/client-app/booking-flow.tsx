
'use client';

import * as React from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  ArrowLeft,
  Calendar,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Loader2,
  Phone,
  User,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { type Service, type Extension } from '@/app/super-admin/businesses/[id]/(edit-business)/services/schema';
import { useToast } from '@/hooks/use-toast';
import { createBooking, sendVerificationSms, verifyCodeAndSignIn } from './actions';
import { bookingSchema, type BookingFormData } from './schema';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { add, addDays, format, isBefore, startOfDay, startOfMonth, type Locale } from 'date-fns';
import { type Staff } from '@/app/super-admin/businesses/[id]/(edit-business)/staff/schema';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { useCustomer } from './providers';
import { FormattedPrice } from '@/components/formatted-price';
import { PhoneInput } from '@/components/phone-input';
import { cn } from '@/lib/utils';
import { useMediaQuery } from '@/hooks/use-media-query';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { enUS, bs, da } from 'date-fns/locale';
import { useScheduler } from '@/hooks/use-scheduler';

const translations = {
  en: {
    backToServices: "Back to Services",
    step1: "Add-ons",
    step2: "Date & Time",
    step3: "Specialist",
    step4: "Your Details",
    step5: "Confirmation",
    addonsFor: "Add-ons for",
    continue: "Continue",
    selected: "selected",
    selectDateTime: "Select date & time",
    pickDate: "Pick a date",
    availableSlots: "Available slots",
    appointmentTime: "Appointment time:",
    noSlotsForDay: "No available slots for this day.",
    next: "Next",
    back: "Back",
    noAppointmentsAvailable: "No appointments available",
    noAppointmentsDescription: "We are sorry, but there are no available appointments in the near future for the selected service. Please try a different service or check back later.",
    close: "Close",
    chooseSpecialist: "Choose your specialist",
    expertStylist: "Expert stylist",
    yourInformation: "Your information",
    yourInformationDescription: "Please provide your details to complete the booking.",
    fullName: "Full name",
    fullNamePlaceholder: "e.g., John Doe",
    phoneNumber: "Phone number",
    reviewBooking: "Review booking",
    confirmBooking: "Confirm your booking",
    confirmBookingDescription: "Please review the details below before confirming.",
    service: "Service",
    addOns: "Add-ons",
    with: "With",
    dateTime: "Date & time",
    yourName: "Your name",
    phone: "Phone",
    totalTime: "Total time",
    totalPrice: "Total price",
    confirmAndBook: "Confirm & Book",
    bookingConfirmed: "Booking confirmed!",
    bookingConfirmedDescription: "Your appointment is set. You will receive a confirmation message shortly. We look forward to seeing you!",
    done: "Done",
    errorCreatingBooking: "Error creating booking",
    errorNoLongerAvailable: "The selected time slot is no longer available. Please choose another time.",
    errorUnexpected: "An unexpected error occurred.",
    noExtensions: "No extensions available for this service.",
    staffError: "Could not find the assigned staff member. Please try again.",
    checkingAvailability: "Checking availability...",
    bookingSummary: "Booking Summary",
    verifyAndBook: "Verify & Book",
    verifyYourNumber: "Last step: Verify your number",
    verificationCodeSent: "A 4-digit verification code has been sent to your phone number. Enter it below to confirm your booking.",
    verificationCode: "Verification code",
    verify: "Verify",
    errorSendingCode: "Error sending code",
    errorVerifyingCode: "Error verifying code",
    cancel: "Cancel"
  },
  bs: {
    backToServices: "Nazad na usluge",
    step1: "Dodaci",
    step2: "Datum i vrijeme",
    step3: "Stručnjak",
    step4: "Vaši podaci",
    step5: "Potvrda",
    addonsFor: "Dodaci za",
    continue: "Nastavi",
    selected: "odabrano",
    selectDateTime: "Odaberite datum i vrijeme",
    pickDate: "Odaberite datum",
    availableSlots: "Dostupni termini",
    appointmentTime: "Vrijeme termina:",
    noSlotsForDay: "Nema dostupnih termina za ovaj dan.",
    next: "Dalje",
    back: "Nazad",
    noAppointmentsAvailable: "Nema dostupnih termina",
    noAppointmentsDescription: "Žao nam je, ali trenutno nema dostupnih termina za odabranu usluguc. Molimo pokušajte s drugom uslugom ili provjerite kasnije.",
    close: "Zatvori",
    chooseSpecialist: "Odaberite svog stručnjaka",
    expertStylist: "Stručni stilist",
    yourInformation: "Vaše informacije",
    yourInformationDescription: "Molimo unesite svoje podatke kako biste dovršili rezervaciju.",
    fullName: "Puno ime",
    fullNamePlaceholder: "npr., John Doe",
    phoneNumber: "Broj telefona",
    reviewBooking: "Pregledajte rezervaciju",
    confirmBooking: "Potvrdite svoju rezervaciju",
    confirmBookingDescription: "Molimo pregledajte detalje ispod prije potvrde.",
    service: "Usluga",
    addOns: "Dodaci",
    with: "Sa",
    dateTime: "Datum i vrijeme",
    yourName: "Vaše ime",
    phone: "Telefon",
    totalTime: "Ukupno vrijeme",
    totalPrice: "Ukupna cijena",
    confirmAndBook: "Potvrdi i rezerviši",
    bookingConfirmed: "Rezervacija potvrđena!",
    bookingConfirmedDescription: "Vaš termin je zakazan. Uskoro ćete primiti potvrdnu poruku. Radujemo se vašem dolasku!",
    done: "Gotovo",
    errorCreatingBooking: "Greška pri kreiranju rezervacije",
    errorNoLongerAvailable: "Odabrani termin više nije dostupan. Molimo odaberite drugi termin.",
    errorUnexpected: "Došlo je do neočekivane greške.",
    noExtensions: "Nema dostupnih dodataka za ovu usluguc.",
    staffError: "Nije moguće pronaći dodijeljenog zaposlenika. Molimo pokušajte ponovo.",
    checkingAvailability: "Provjera dostupnosti...",
    bookingSummary: "Sažetak rezervacije",
    verifyAndBook: "Verifikuj i Rezerviši",
    verifyYourNumber: "Zadnji korak: Verifikujte svoj broj",
    verificationCodeSent: "4-cifreni verifikacioni kod je poslan na vaš broj telefona. Unesite ga ispod da potvrdite rezervaciju.",
    verificationCode: "Verifikacioni kod",
    verify: "Verifikuj",
    errorSendingCode: "Greška pri slanju koda",
    errorVerifyingCode: "Greška pri verifikaciji koda",
    cancel: "Otkaži"
  },
  da: {
    backToServices: "Tilbage til ydelser",
    step1: "Tilføjelser",
    step2: "Dato & tid",
    step3: "Specialist",
    step4: "Dine oplysninger",
    step5: "Bekræftelse",
    addonsFor: "Tilføjelser til",
    continue: "Fortsæt",
    selected: "valgt",
    selectDateTime: "Vælg dato & tid",
    pickDate: "Vælg en dato",
    availableSlots: "Ledige tider",
    appointmentTime: "Aftale tidspunkt:",
    noSlotsForDay: "Ingen ledige tider for denne dag.",
    next: "Næste",
    back: "Tilbage",
    noAppointmentsAvailable: "Ingen ledige aftaler",
    noAppointmentsDescription: "Vi beklager, men der er ingen ledige aftaler i den nærmeste fremtid for den valgte service. Prøv venligst en anden service eller tjek tilbage senere.",
    close: "Luk",
    chooseSpecialist: "Vælg din specialist",
    expertStylist: "Ekspert stylist",
    yourInformation: "Dine oplysninger",
    yourInformationDescription: "Angiv venligst dine oplysninger for at fuldføre bookingen.",
    fullName: "Fulde navn",
    fullNamePlaceholder: "f.eks., John Doe",
    phoneNumber: "Telefonnummer",
    reviewBooking: "Gennemse booking",
    confirmBooking: "Bekræft din booking",
    confirmBookingDescription: "Gennemse venligst detaljerne nedenfor, før du bekræfter.",
    service: "Service",
    addOns: "Tilføjelser",
    with: "Med",
    dateTime: "Dato & tid",
    yourName: "Dit navn",
    phone: "Telefon",
    totalTime: "Samlet tid",
    totalPrice: "Samlet pris",
    confirmAndBook: "Bekræft & book",
    bookingConfirmed: "Booking bekræftet!",
    bookingConfirmedDescription: "Din aftale er sat. Du vil modtage en bekræftelsesmeddelelse snarest. Vi glæder os til at se dig!",
    done: "Færdig",
    errorCreatingBooking: "Fejl ved oprettelse af booking",
    errorNoLongerAvailable: "Det valgte tidsrum er ikke længere tilgængeligt. Vælg venligst et andet tidspunkt.",
    errorUnexpected: "Der opstod en uventet fejl.",
    noExtensions: "Ingen tilgængelige udvidelser for denne service.",
    staffError: "Kunne ikke finde den tildelte medarbejder. Prøv venligst igen.",
    checkingAvailability: "Kontrollerer tilgængelighed...",
    bookingSummary: "Booking Oversigt",
    verifyAndBook: "Bekræft & Book",
    verifyYourNumber: "Sidste trin: Bekræft dit nummer",
    verificationCodeSent: "En 4-cifret bekræftelseskode er blevet sendt til dit telefonnummer. Indtast den nedenfor for at bekræfte din booking.",
    verificationCode: "Bekræftelseskode",
    verify: "Bekræft",
    errorSendingCode: "Fejl ved afsendelse af kode",
    errorVerifyingCode: "Fejl ved bekræftelse af kode",
    cancel: "Annuller"
  },
};

type Language = keyof typeof translations;

type Step = 'extensions' | 'datetime' | 'staff' | 'details' | 'verify' | 'confirm';

interface BookingFlowProps {
  business: any;
  service: Service;
  allExtensions: Extension[];
  allStaff: Staff[];
  hasSmsEnabled: boolean;
}

export function BookingFlow({ business, service, allExtensions, allStaff, hasSmsEnabled }: BookingFlowProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [step, setStep] = React.useState<Step>('extensions');
  const [selectedExtensions, setSelectedExtensions] = React.useState<Extension[]>([]);
  
  const [selectedTime, setSelectedTime] = React.useState<string | undefined>(undefined);
  const [availableStaffForSlot, setAvailableStaffForSlot] = React.useState<Staff[]>([]);
  const [selectedStaffId, setSelectedStaffId] = React.useState<string | undefined>(undefined);

  const [verificationId, setVerificationId] = React.useState<string | undefined>(undefined);
  const [verificationCode, setVerificationCode] = React.useState('');
  const [isVerifying, setIsVerifying] = React.useState(false);
  const [isSubmittingFinal, setIsSubmittingFinal] = React.useState(false);

  const { customer, setCustomer } = useCustomer();
  const language: Language = business.language || 'bs';
  const t = translations[language];
  const locale: Locale = language === 'bs' ? bs : (language === 'da' ? da : enUS);
  const currency = business.currency || 'DKK';
  const allowedPhoneCountries = business.allowedPhoneCountries || [];
  
  const serviceExtensions = service.extensions
    ? allExtensions.filter(ext => service.extensions!.includes(ext.id))
    : [];
  
  const totalDuration = service.duration + selectedExtensions.reduce((acc, ext) => acc + ext.duration, 0);
  const totalPrice = service.price + selectedExtensions.reduce((acc, ext) => acc + ext.price, 0);

  const {
    selectedDate,
    setSelectedDate,
    currentMonth,
    setCurrentMonth,
    availableSlots,
    isLoadingAvailability,
    noSlotsFound,
  } = useScheduler({ business, allStaff, totalDuration });

  const currentBookingSchema = bookingSchema(allowedPhoneCountries, false);
  const form = useForm<BookingFormData>({
    resolver: zodResolver(currentBookingSchema),
    defaultValues: {
      serviceId: service.id,
      serviceName: service.name,
      extensions: [],
      customerName: customer?.name || '',
      customerPhone: customer?.phone || '',
      customerId: customer?.id || '',
      totalDuration: service.duration,
      totalPrice: service.price,
    },
  });

   const isMobile = useMediaQuery("(max-width: 768px)");
   const [accordionValue, setAccordionValue] = React.useState<string>("date-picker");
  
   React.useEffect(() => {
    if (serviceExtensions.length === 0 && step === 'extensions') {
      setStep('datetime');
      form.setValue('extensions', []);
      form.setValue('totalDuration', service.duration);
      form.setValue('totalPrice', service.price);
    }
  }, [service.duration, service.price, serviceExtensions.length, form, step]);

  React.useEffect(() => {
    if (customer) {
        form.setValue('customerName', customer.name || '');
        form.setValue('customerPhone', customer.phone || '');
        form.setValue('customerId', customer.id || '');
    }
  }, [customer, form]);

  const onFinalSubmit = async (data: BookingFormData) => {
    setIsSubmittingFinal(true);
    const payload = { ...data, sendSms: hasSmsEnabled };
    const result = await createBooking(business.id, payload);
    if(result.success) {
      router.push(`/${business.id}/client-app/book/confirmed`);
    } else {
       const formErrors = 'errors' in result ? (result.errors as any) : null;
       const rootError = formErrors?._root?.[0] || ('error' in result ? result.error : null);
       if (rootError && rootError.includes('longer available')) {
            toast({
                variant: 'destructive',
                title: t.errorCreatingBooking,
                description: t.errorNoLongerAvailable,
            });
            // Redirect back to datetime selection
            setStep('datetime');
            setSelectedTime(undefined);
       } else {
            toast({
                variant: 'destructive',
                title: t.errorCreatingBooking,
                description: rootError || t.errorUnexpected,
            });
       }
       setIsSubmittingFinal(false);
    }
  };

  const handleNextStep = async () => {
    if (step === 'extensions') {
      form.setValue('extensions', selectedExtensions.map(e => ({ id: e.id, name: e.name, price: e.price, duration: e.duration })));
      form.setValue('totalDuration', totalDuration);
      form.setValue('totalPrice', totalPrice);
      setStep('datetime');
    } else if (step === 'datetime') {
        form.setValue('date', format(selectedDate!, 'yyyy-MM-dd'));
        form.setValue('time', selectedTime!);

        const slot = availableSlots.find(s => s.time === selectedTime);
        if (slot) {
            if (slot.staffIds.length === 1) {
                const staffId = slot.staffIds[0];
                const staffMember = allStaff.find(s => s.id === staffId);
                if (staffMember) {
                    form.setValue('staffId', staffMember.id);
                    form.setValue('staffName', staffMember.fullName);
                    if (customer) {
                        setStep('confirm');
                    } else {
                        setStep('details');
                    }
                } else {
                    toast({ variant: 'destructive', title: 'Error', description: t.staffError });
                }
            } else {
                const availableStaff = allStaff.filter(s => slot.staffIds.includes(s.id));
                setAvailableStaffForSlot(availableStaff);
                setStep('staff');
            }
        }
    } else if (step === 'staff') {
        const staffMember = allStaff.find(s => s.id === selectedStaffId)!;
        form.setValue('staffId', staffMember.id);
        form.setValue('staffName', staffMember.fullName);
        if (customer) {
            setStep('confirm');
        } else {
            setStep('details');
        }
    } else if (step === 'details') {
        const isValid = await form.trigger(['customerName', 'customerPhone']);
        if (!isValid) return;

        if (hasSmsEnabled) {
            const { customerName, customerPhone } = form.getValues();
            setIsVerifying(true);
            const result = await sendVerificationSms(business.id, customerPhone, customerName);
            setIsVerifying(false);
            if (result.success && result.verificationId) {
                setVerificationId(result.verificationId);
                setStep('verify');
            } else {
                toast({ variant: 'destructive', title: t.errorSendingCode, description: result.error });
            }
        } else {
            // If SMS is disabled, just confirm
            setStep('confirm');
        }
    }
  };

  const handleVerifyCode = async () => {
    if (!verificationId || verificationCode.length !== 4) return;
    setIsVerifying(true);
    const result = await verifyCodeAndSignIn(business.id, verificationId, verificationCode);
    setIsVerifying(false); // Stop loading indicator regardless of outcome

    if (result.success && result.customer) {
        setCustomer(result.customer);
        form.setValue('customerId', result.customer.id);
        form.setValue('customerName', result.customer.name);
        form.setValue('customerPhone', result.customer.phone);
        // After successful verification, move to confirm step
        setStep('confirm');
    } else {
        toast({ variant: 'destructive', title: t.errorVerifyingCode, description: result.error });
    }
  };

  const handlePrevStep = () => {
    const firstStep = serviceExtensions.length > 0 ? 'extensions' : 'datetime';
    if (step === firstStep) {
        router.push(`/${business.id}/client-app`);
        return;
    }

    if (step === 'confirm') {
       const slot = availableSlots.find(s => s.time === selectedTime);
       if (customer) {
           if(slot && slot.staffIds.length > 1) {
               setStep('staff');
           } else {
               setStep('datetime');
           }
       } else {
           setStep('details');
       }
    }
    if (step === 'datetime') {
        if (serviceExtensions.length > 0) {
            setStep('extensions');
        } else {
             router.push(`/${business.id}/client-app`);
        }
    }
    if (step === 'staff') setStep('datetime');
    if (step === 'verify') setStep('details');
    if (step === 'details') {
       const slot = availableSlots.find(s => s.time === selectedTime);
       if(slot && slot.staffIds.length > 1) {
           setStep('staff');
       } else {
           setStep('datetime');
       }
    }
  };
  
  const getStepTitle = () => {
    switch (step) {
        case 'extensions': return t.step1;
        case 'datetime': return t.step2;
        case 'staff': return t.step3;
        case 'details': return t.step4;
        case 'verify': return t.verifyYourNumber;
        case 'confirm': return t.confirmBooking;
        default: return '';
    }
  }

  const stepContent = () => {
    const maxBookingDate = business.schedulingWindowValue ? add(new Date(), { [business.schedulingWindowUnit || 'days']: business.schedulingWindowValue }) : undefined;

    switch (step) {
        case 'extensions':
            return (
                <>
                    <h3 className="text-xl font-semibold mb-4">{t.addonsFor} {service.name}</h3>
                    <div className="space-y-4 py-4">
                        {serviceExtensions.length > 0 ? serviceExtensions.map(ext => (
                            <div key={ext.id} className="flex items-center space-x-4 p-4 rounded-lg border has-[:checked]:bg-primary/5 has-[:checked]:border-primary">
                            <Checkbox 
                                id={ext.id}
                                checked={selectedExtensions.some(e => e.id === ext.id)}
                                onCheckedChange={() => {
                                    const isSelected = selectedExtensions.some(e => e.id === ext.id);
                                    if (isSelected) {
                                        setSelectedExtensions(prev => prev.filter(e => e.id !== ext.id));
                                    } else {
                                        setSelectedExtensions(prev => [...prev, ext]);
                                    }
                                }}
                                className="h-6 w-6"
                            />
                            <label htmlFor={ext.id} className="flex-1 cursor-pointer">
                                <div className="flex justify-between">
                                <span className="font-medium text-base">{ext.name}</span>
                                <span className="font-semibold">
                                    + <FormattedPrice price={ext.price} currency={currency} />
                                </span>
                                </div>
                                <p className="text-sm text-muted-foreground">+{ext.duration} min</p>
                            </label>
                            </div>
                        )) : (
                            <p className="text-center text-muted-foreground py-8">{t.noExtensions}</p>
                        )}
                    </div>
                </>
            );
        case 'datetime':
            return (
                <>
                    <h3 className="text-xl font-semibold mb-4">{t.selectDateTime}</h3>
                    <div className="py-4 md:grid md:grid-cols-2 md:gap-8">
                        {isMobile ? (
                            <Accordion type="single" value={accordionValue} onValueChange={setAccordionValue} collapsible className="w-full mb-6">
                                <AccordionItem value="date-picker">
                                    <AccordionTrigger className="text-lg font-semibold w-full">
                                        {selectedDate ? format(selectedDate, 'PPP', { locale }) : t.pickDate}
                                    </AccordionTrigger>
                                    <AccordionContent>
                                        <CalendarComponent
                                            mode="single"
                                            selected={selectedDate}
                                            onSelect={(date) => {
                                                setSelectedDate(date as Date);
                                                if (date) setAccordionValue('');
                                            }}
                                            month={currentMonth}
                                            onMonthChange={setCurrentMonth}
                                            disabled={(date) => isBefore(date, startOfDay(new Date()))}
                                            weekStartsOn={business.weekStartsOn === 0 ? 0 : 1}
                                            toDate={maxBookingDate}
                                            fromDate={new Date()}
                                            locale={locale}
                                        />
                                    </AccordionContent>
                                </AccordionItem>
                            </Accordion>
                        ) : (
                            <div className="flex flex-col items-center">
                                <CalendarComponent
                                    mode="single"
                                    selected={selectedDate}
                                    onSelect={(date) => {
                                        setSelectedDate(date as Date);
                                        setSelectedTime(undefined);
                                    }}
                                    month={currentMonth}
                                    onMonthChange={setCurrentMonth}
                                    disabled={(date) => isBefore(date, startOfDay(new Date()))}
                                    weekStartsOn={business.weekStartsOn === 0 ? 0 : 1}
                                    toDate={maxBookingDate}
                                    fromDate={new Date()}
                                    locale={locale}
                                />
                            </div>
                        )}
                        <div>
                            <h4 className="font-semibold mb-4 text-center">
                                {t.availableSlots}
                            </h4>
                            {isLoadingAvailability ? (
                                <div className="flex justify-center items-center h-48">
                                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                                </div>
                            ) : selectedDate && availableSlots.length > 0 ? (
                                <div className="grid grid-cols-3 gap-2">
                                    {availableSlots.map(slot => (
                                        <Button key={slot.time} variant={selectedTime === slot.time ? 'default' : 'outline'} onClick={() => setSelectedTime(slot.time)}>
                                            {slot.time}
                                        </Button>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-center text-muted-foreground pt-10">{noSlotsFound ? t.noAppointmentsAvailable : t.noSlotsForDay}</p>
                            )}
                        </div>
                    </div>
                </>
            );
        case 'staff':
            return (
                <>
                    <h3 className="text-xl font-semibold mb-4">{t.chooseSpecialist}</h3>
                    <div className="space-y-4 py-4">
                        {availableStaffForSlot.map(staff => (
                            <Card key={staff.id} 
                                className={cn('cursor-pointer transition-all', selectedStaffId === staff.id ? 'border-primary ring-2 ring-primary' : 'hover:border-primary/50')}
                                onClick={() => setSelectedStaffId(staff.id)}
                            >
                                <CardHeader className="flex flex-row items-center gap-4">
                                    <Avatar className="h-14 w-14">
                                        <AvatarImage src={staff.imageUrl ?? undefined} className="object-cover" data-ai-hint="person portrait" />
                                        <AvatarFallback>{staff.fullName.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <CardTitle className="text-lg">{staff.fullName}</CardTitle>
                                        <CardDescription>{t.expertStylist}</CardDescription>
                                    </div>
                                </CardHeader>
                            </Card>
                        ))}
                    </div>
                </>
            );
        case 'details':
            return (
                <>
                    <h3 className="text-xl font-semibold mb-4">{t.step4}</h3>
                    <div className="space-y-6 py-4">
                        <FormField
                            control={form.control}
                            name="customerName"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>{t.fullName}</FormLabel>
                                <FormControl>
                                    <Input placeholder={t.fullNamePlaceholder} {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="customerPhone"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>{t.phoneNumber}</FormLabel>
                                <FormControl>
                                    <PhoneInput {...field} allowedCountries={business.allowedPhoneCountries || []} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                </>
            );
        case 'verify':
            return (
                <>
                    <h3 className="text-xl font-semibold mb-4">{t.verifyYourNumber}</h3>
                    <p className="text-muted-foreground">{t.verificationCodeSent}</p>
                    <div className="space-y-6 py-8">
                         <FormField
                            control={form.control}
                            name="verificationCode"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t.verificationCode}</FormLabel>
                                    <FormControl>
                                        <Input
                                        {...field}
                                        type="tel"
                                        maxLength={4}
                                        className="h-14 text-2xl text-center tracking-[1em]"
                                        value={verificationCode}
                                        onChange={(e) => setVerificationCode(e.target.value)}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                </>
            );
        case 'confirm':
            return (
                <div className="w-full mx-auto">
                    <h3 className="text-xl font-semibold mb-2">{t.confirmBooking}</h3>
                    <p className="text-muted-foreground mb-6">{t.confirmBookingDescription}</p>
                    <div className="space-y-4 text-sm">
                        <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.service}</span>
                        <span className="font-semibold">{form.watch('serviceName')}</span>
                        </div>
                        <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.with}</span>
                        <span className="font-semibold">{form.watch('staffName')}</span>
                        </div>
                        <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.dateTime}</span>
                        <span className="font-semibold">{format(new Date(form.watch('date')), 'dd MMM yy', { locale })} at {form.watch('time')}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.yourName}</span>
                        <span className="font-semibold">{form.watch('customerName')}</span>
                        </div>
                        <div className="flex justify-between">
                        <span className="text-muted-foreground">{t.phone}</span>
                        <span className="font-semibold">{form.watch('customerPhone')}</span>
                        </div>
                    </div>
                </div>
            );
        default:
            return null;
    }
  };
    
  const bookNowButtonText = () => {
    switch(step) {
      case 'extensions': return t.continue;
      case 'datetime': return t.next;
      case 'staff': return t.next;
      case 'details': return hasSmsEnabled ? t.verifyAndBook : t.confirmAndBook;
      case 'verify': return t.verify;
      case 'confirm': return t.confirmAndBook;
      default: return t.continue;
    }
  }
    
  const currentAction = () => {
    if (step === 'confirm') return form.handleSubmit(onFinalSubmit);
    if (step === 'verify') return handleVerifyCode;
    return handleNextStep;
  }
    
  return (
    <div className="flex flex-col min-h-screen bg-muted/40">
      <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-sm">
          <div className="container mx-auto px-4 md:px-8 flex h-20 items-center justify-between">
              <h3 className="font-semibold text-lg">{getStepTitle()}</h3>
              <Button variant="ghost" size="lg" onClick={handlePrevStep}>
                <X className="mr-2 h-4 w-4" />
                {t.cancel}
              </Button>
          </div>
      </header>

      <main className="container mx-auto py-8 px-4 md:px-8 flex-1">
        <FormProvider {...form}>
            <form onSubmit={(e) => {
                e.preventDefault();
              }}>
              <Card>
                <CardContent className="p-6">
                  {stepContent()}
                </CardContent>
              </Card>
            </form>
        </FormProvider>
      </main>
      
      <footer className="sticky bottom-0 bg-background border-t z-10">
        <div className="container mx-auto px-4 md:px-8 flex items-center justify-between h-20">
            <Button type="button" variant="ghost" size="lg" onClick={handlePrevStep} >
                <ArrowLeft className="mr-2 h-5 w-5" />{t.back}
            </Button>
            <Button 
                type="button" 
                size="lg" 
                onClick={currentAction()} 
                disabled={isVerifying || isSubmittingFinal}>
                {(isVerifying || isSubmittingFinal) && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
                {bookNowButtonText()}
            </Button>
        </div>
      </footer>
    </div>
  );
}

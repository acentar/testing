
import { z } from 'zod';

export const orderSchema = z.object({
  legalCompanyName: z.string().min(2, 'Legal company name is required.'),
  customerName: z.string().min(2, 'Your name is required.'),
  email: z.string().email('A valid email is required.'),
  accountantEmail: z.string().email('A valid email is required.').optional().or(z.literal('')),
  phone: z.string().min(8, 'A valid phone number is required.'),
  calendars: z.number().min(3),
  monthlyPrice: z.number(),
  setupFee: z.number(),
  vatRate: z.number(),
  vatAmount: z.number(),
  totalAmount: z.number(),
  currency: z.enum(['EUR', 'DKK', 'BAM']),
  language: z.enum(['en', 'bs', 'da']).default('bs'),
  address: z.object({
    street: z.string().min(2, 'Street address is required.'),
    city: z.string().min(2, 'City is required.'),
    postalCode: z.string().min(2, 'Postal code is required.'),
    country: z.string().min(1, 'Country is required.'),
  }),
  taxId: z.string().optional(),
});

export type OrderFormData = z.infer<typeof orderSchema>;


'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import { FormattedPrice } from '@/components/formatted-price';
import { ArrowLeft, Check, CheckCircle, ChevronDown, Info, Loader2 } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { createOrder } from './actions';
import { type OrderFormData, orderSchema } from './schema';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const translations = {
  en: {
    yourOrderTitle: "Your order",
    orderDetails: "Just a few more details to get you started.",
    yourDetails: "Your details",
    billingInfo: "Billing information for invoicing",
    legalCompanyName: "Legal company name",
    yourName: "Your full name",
    email: "Email",
    accountantEmail: "Accountant email (optional)",
    emailPlaceholder: "e.g., john@royalcut.com",
    phoneNumber: "Phone number",
    confirmOrder: "Confirm order",
    backToHomepage: "Back to homepage",
    orderSummary: "Order summary",
    employeeCalendars: "up to {{count}} employee calendars",
    monthlySubscription: "Monthly subscription",
    calendars: "calendars",
    oneTimeSetupFee: "One-time setup fee",
    subtotal: "Subtotal",
    vat: "VAT",
    totalDueToday: "Total due today",
    monthlyStartsLater: "Your monthly subscription of {{price}} will start after setup is complete.",
    thankYou: "Thank you for your order!",
    orderReceived: "We have received your request and will be in touch shortly to finalize the setup of your new business account.",
    done: "Done",
    noBinding: "No binding period. Cancel your subscription at any time.",
    legalNameTooltip: "Your company or legal name",
    address: "Address",
    street: "Street address",
    city: "City",
    postalCode: "Postal code",
    country: "Country",
    taxId: "Tax ID (PDV Broj)",
    taxIdTooltip: "Enter your TIN or PDV ID. Optional, but required for VAT deduction on invoices.",
    yourOrder: "Your order",
    howToContactYou: "How to contact you",
  },
  da: {
    yourOrderTitle: "Din ordre",
    orderDetails: "Bare et par detaljer mere for at komme i gang.",
    yourDetails: "Dine oplysninger",
    billingInfo: "Faktureringsoplysninger",
    legalCompanyName: "Juridisk firmanavn",
    yourName: "Dit fulde navn",
    email: "E-mail",
    accountantEmail: "Revisor-e-mail (valgfrit)",
    emailPlaceholder: "f.eks., john@royalcut.com",
    phoneNumber: "Telefonnummer",
    confirmOrder: "Bekræft ordre",
    backToHomepage: "Tilbage til forsiden",
    orderSummary: "Ordreoversigt",
    employeeCalendars: "op til {{count}} medarbejderkalendere",
    monthlySubscription: "Månedligt abonnement",
    calendars: "kalendere",
    oneTimeSetupFee: "Engangsoprettelsesgebyr",
    subtotal: "Subtotal",
    vat: "Moms",
    totalDueToday: "Samlet pris i dag",
    monthlyStartsLater: "Dit månedlige abonnement på {{price}} starter, når opsætningen er fuldført.",
    thankYou: "Tak for din ordre!",
    orderReceived: "Vi har modtaget din anmodning og kontakter dig snarest for at færdiggøre opsætningen af din nye virksomhedskonto.",
    done: "Færdig",
    noBinding: "Ingen bindingsperiode. Opsig dit abonnement når som helst.",
    legalNameTooltip: "Din virksomheds eller juridiske navn",
    address: "Adresse",
    street: "Gadeadresse",
    city: "By",
    postalCode: "Postnummer",
    country: "Land",
    taxId: "Skatte-ID (CVR)",
    taxIdTooltip: "Indtast dit CVR-nummer. Valgfrit, men påkrævet for momsfradrag på fakturaer.",
    yourOrder: "Din ordre",
    howToContactYou: "Hvordan kontakter vi dig",
  },
  bs: {
    yourOrderTitle: "Vaša narudžba",
    orderDetails: "Još samo nekoliko detalja da započnete.",
    yourDetails: "Vaši podaci",
    billingInfo: "Podaci o naplati za fakturisanje",
    legalCompanyName: "Pravni naziv kompanije",
    yourName: "Vaše puno ime",
    email: "Email",
    accountantEmail: "Email računovođe (opcionalno)",
    emailPlaceholder: "npr., john@royalcut.com",
    phoneNumber: "Broj telefona",
    confirmOrder: "Potvrdi narudžbu",
    backToHomepage: "Nazad na početnu",
    orderSummary: "Sažetak narudžbe",
    employeeCalendars: "do {{count}} kalendara zaposlenih",
    monthlySubscription: "Mjesečna pretplata",
    calendars: "kalendara",
    oneTimeSetupFee: "Jednokratna naknada za postavljanje",
    subtotal: "Ukupno",
    vat: "PDV",
    totalDueToday: "Ukupno za platiti danas",
    monthlyStartsLater: "Vaša mjesečna pretplata od {{price}} će početi nakon što postavljanje bude završeno.",
    thankYou: "Hvala vam na narudžbi!",
    orderReceived: "Primili smo vaš zahtjev i uskoro ćemo vas kontaktirati kako bismo dovršili postavljanje vašeg novog poslovnog računa.",
    done: "Gotovo",
    noBinding: "Nema perioda vezivanja. Otkažite pretplatu u bilo kojem trenutku.",
    legalNameTooltip: "Naziv vaše kompanije ili pravnog lica",
    address: "Adresa",
    street: "Ulica i broj",
    city: "Grad",
    postalCode: "Poštanski broj",
    country: "Država",
    taxId: "Porezni broj (IDB/JIB)",
    taxIdTooltip: "Unesite vaš IDB ili JIB broj. Opciono, ali obavezno za odbitak ulaznog PDV-a na fakturama.",
    yourOrder: "Vaša narudžba",
    howToContactYou: "Kako da vas kontaktiramo",
  },
};

const europeanCountries = [
    "Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herzegovina", 
    "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", 
    "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Ireland", 
    "Italy", "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", 
    "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands", "North Macedonia", 
    "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino", "Serbia", 
    "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "Ukraine", 
    "United Kingdom", "Vatican City"
];

type OrderFormValues = z.infer<typeof orderSchema>;

interface OrderClientPageProps {
    appName: string;
    appLogoUrl?: string;
    storeSettings: any;
}

export function OrderClientPage({ appName, appLogoUrl, storeSettings }: OrderClientPageProps) {
    const [language, setLanguage] = React.useState<'en' | 'bs' | 'da'>('bs');
    const [calendars, setCalendars] = React.useState(3);
    const [isSubmitted, setIsSubmitted] = React.useState(false);
    const { toast } = useToast();

    const t = translations[language];
    const currentSettings = storeSettings[language];

    const form = useForm<OrderFormValues>({
        resolver: zodResolver(orderSchema),
        defaultValues: {
            calendars: 3,
            customerName: '',
            email: '',
            phone: '',
            legalCompanyName: '',
            accountantEmail: '',
            address: { street: '', city: '', postalCode: '', country: 'Bosnia and Herzegovina' },
            taxId: ''
        }
    });
    
    React.useEffect(() => {
        form.setValue('calendars', calendars);
    }, [calendars, form]);
    
    const monthlyCost = React.useMemo(() => {
        if (!currentSettings) return 0;
        if (calendars <= 3) {
            return currentSettings.basePrice || (currentSettings.pricePerCalendar * 3);
        }
        return (currentSettings.basePrice || (currentSettings.pricePerCalendar * 3)) + (calendars - 3) * currentSettings.pricePerCalendar;
    }, [calendars, currentSettings]);

    const setupFee = currentSettings?.setupFee || 0;
    const vatRatePercent = currentSettings?.vatRate || 0;
    const vatRate = vatRatePercent / 100;
    
    const subtotal = monthlyCost + setupFee;
    const totalVat = subtotal * vatRate;
    const totalDueToday = subtotal + totalVat;


    const onSubmit = async (data: OrderFormValues) => {
        const result = await createOrder(data);

        if (result.success) {
            setIsSubmitted(true);
        } else {
            toast({
                variant: 'destructive',
                title: 'Order Failed',
                description: result.error || 'An unexpected error occurred. Please try again.'
            });
        }
    };
    
    const onConfirmClick = async () => {
        form.setValue('monthlyPrice', monthlyCost);
        form.setValue('setupFee', setupFee);
        form.setValue('vatRate', vatRatePercent);
        form.setValue('vatAmount', totalVat);
        form.setValue('totalAmount', totalDueToday);
        form.setValue('currency', currentSettings.currency);
        form.setValue('language', language);
        
        const isValid = await form.trigger();
        if (isValid) {
            onSubmit(form.getValues());
        } else {
            toast({
                variant: 'destructive',
                title: 'Incomplete Form',
                description: 'Please fill out all required fields correctly.',
            });
        }
    };
    
    if (isSubmitted) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen p-4">
                <Card className="w-full max-w-lg text-center shadow-lg">
                    <CardHeader>
                        <div className="mx-auto bg-green-100 rounded-full p-3 w-16 h-16 flex items-center justify-center">
                            <CheckCircle className="h-10 w-10 text-green-600" />
                        </div>
                         <CardTitle className="text-2xl mt-4">{t.thankYou}</CardTitle>
                        <CardDescription>
                           {t.orderReceived}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button asChild>
                            <Link href="/">{t.done}</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }
    
    if (!currentSettings) {
        return <div className="flex items-center justify-center h-screen"><Loader2 className="h-8 w-8 animate-spin" /></div>
    }
    
    const { isSubmitting } = form.formState;

    return (
        <TooltipProvider>
        <div className="container mx-auto py-8 md:py-16">
            <header className="text-center mb-10">
                 <div className="flex justify-center items-center gap-4 mb-8">
                     <Link href="/" className="inline-block">
                      {appLogoUrl ? (
                          <Image src={appLogoUrl} alt={`${appName} logo`} width={200} height={50} className="h-12 w-auto" unoptimized />
                      ) : (
                          <h1 className="text-3xl font-bold">{appName}</h1>
                      )}
                    </Link>
                     <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">
                           <span className="text-xl">{language === 'bs' ? '🇧🇦' : language === 'da' ? '🇩🇰' : '🇬🇧'}</span>
                           <ChevronDown className="ml-2 h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setLanguage('en')}>
                          <span className="mr-2 text-xl">🇬🇧</span> English (EUR)
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setLanguage('da')}>
                          <span className="mr-2 text-xl">🇩🇰</span> Dansk (DKK)
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setLanguage('bs')}>
                          <span className="mr-2 text-xl">🇧🇦</span> Bosanski (BAM)
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                 </div>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">{t.yourOrderTitle}</h2>
                <p className="text-muted-foreground mt-2">{t.orderDetails}</p>
            </header>

            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="grid lg:grid-cols-5 gap-8 items-start">
                        <div className="lg:col-span-3">
                            <Card>
                                <CardContent className="p-6 space-y-6">
                                    <h3 className="font-semibold pt-2 text-lg">{t.yourOrder}</h3>
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center mb-2">
                                            <FormLabel htmlFor="calendars-slider" className="font-medium">{t.employeeCalendars.replace('{{count}}', String(calendars))}</FormLabel>
                                            <div className="text-2xl font-bold">{calendars}</div>
                                        </div>
                                        <Slider
                                            id="calendars-slider"
                                            value={[calendars]}
                                            onValueChange={(value) => setCalendars(value[0])}
                                            min={3}
                                            max={20}
                                            step={1}
                                        />
                                    </div>
                                    
                                    <Separator />
                                    <h3 className="font-semibold pt-2 text-lg">{t.howToContactYou}</h3>
                                    <FormField
                                        control={form.control}
                                        name="customerName"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>{t.yourName}</FormLabel>
                                                <FormControl><Input {...field} /></FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <FormField
                                            control={form.control}
                                            name="email"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>{t.email}</FormLabel>
                                                    <FormControl><Input type="email" {...field} /></FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={form.control}
                                            name="phone"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>{t.phoneNumber}</FormLabel>
                                                    <FormControl><Input type="tel" {...field} /></FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <Separator />
                                    <h3 className="font-semibold pt-2 text-lg">{t.billingInfo}</h3>
                                     <FormField
                                        control={form.control}
                                        name="legalCompanyName"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel className="flex items-center gap-2">
                                                    {t.legalCompanyName}
                                                    <Tooltip>
                                                        <TooltipTrigger asChild>
                                                            <button type="button"><Info className="h-4 w-4 text-muted-foreground" /></button>
                                                        </TooltipTrigger>
                                                        <TooltipContent>
                                                            <p>{t.legalNameTooltip}</p>
                                                        </TooltipContent>
                                                    </Tooltip>
                                                </FormLabel>
                                                <FormControl><Input {...field} /></FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <div className="space-y-4">
                                         <FormLabel>{t.address}</FormLabel>
                                        <FormField
                                            control={form.control}
                                            name="address.street"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>{t.street}</FormLabel>
                                                    <FormControl><Input {...field} /></FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                            <FormField
                                                control={form.control}
                                                name="address.city"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>{t.city}</FormLabel>
                                                        <FormControl><Input {...field} /></FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField
                                                control={form.control}
                                                name="address.postalCode"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>{t.postalCode}</FormLabel>
                                                        <FormControl><Input {...field} /></FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                        </div>
                                        <FormField
                                            control={form.control}
                                            name="address.country"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>{t.country}</FormLabel>
                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                        <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder={t.country} />
                                                        </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                        {europeanCountries.map(country => (
                                                            <SelectItem key={country} value={country}>{country}</SelectItem>
                                                        ))}
                                                        </SelectContent>
                                                    </Select>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <FormField
                                        control={form.control}
                                        name="taxId"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel className="flex items-center gap-2">
                                                    {t.taxId}
                                                    <Tooltip>
                                                        <TooltipTrigger asChild>
                                                            <button type="button"><Info className="h-4 w-4 text-muted-foreground" /></button>
                                                        </TooltipTrigger>
                                                        <TooltipContent>
                                                            <p>{t.taxIdTooltip}</p>
                                                        </TooltipContent>
                                                    </Tooltip>
                                                </FormLabel>
                                                <FormControl><Input {...field} /></FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="accountantEmail"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>{t.accountantEmail}</FormLabel>
                                                <FormControl><Input type="email" {...field} /></FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </CardContent>
                            </Card>
                        </div>

                        <aside className="lg:col-span-2 sticky top-8 space-y-4">
                            <Card className="shadow-lg">
                                <CardHeader>
                                    <CardTitle>{t.orderSummary}</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <Separator />
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between">
                                            <span className="text-muted-foreground">{t.monthlySubscription} ({calendars} {t.calendars})</span>
                                            <span><FormattedPrice price={monthlyCost} currency={currentSettings.currency} /></span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-muted-foreground">{t.oneTimeSetupFee}</span>
                                            <span><FormattedPrice price={setupFee} currency={currentSettings.currency} /></span>
                                        </div>
                                        {vatRate > 0 && (
                                            <div className="flex justify-between">
                                                <span className="text-muted-foreground">{t.vat} ({currentSettings.vatRate}%)</span>
                                                <span><FormattedPrice price={totalVat} currency={currentSettings.currency} /></span>
                                            </div>
                                        )}
                                    </div>
                                    <Separator />
                                    <div className="text-center">
                                        <p className="text-muted-foreground text-sm">{t.totalDueToday}</p>
                                        <p className="font-bold text-4xl">
                                            <FormattedPrice price={totalDueToday} currency={currentSettings.currency} />
                                        </p>
                                    </div>
                                </CardContent>
                                <CardFooter>
                                    <p className="text-xs text-muted-foreground text-center w-full">{t.noBinding}</p>
                                </CardFooter>
                            </Card>
                             <Button type="button" size="lg" className="w-full" disabled={isSubmitting} onClick={onConfirmClick}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t.confirmOrder}
                            </Button>
                            <Button variant="ghost" className="w-full" asChild>
                                <Link href="/"><ArrowLeft className="mr-2 h-4 w-4" /> {t.backToHomepage}</Link>
                            </Button>
                        </aside>
                    </div>
                </form>
            </Form>
        </div>
        </TooltipProvider>
    );
}

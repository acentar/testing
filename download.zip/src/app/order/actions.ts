
'use server';

import { rtdb } from '@/lib/firebase.ts';
import { push, serverTimestamp, set, ref } from 'firebase/database';
import { getGlobalSettings, getSmtpSettings, sendSystemEmail } from '../super-admin/settings/actions.ts';
import { type OrderFormData, orderSchema } from './schema.ts';
import { createInvoiceFromOrder } from '../super-admin/invoices/actions.ts';

export async function createOrder(data: OrderFormData): Promise<{ success: boolean; error?: string }> {
  const validationResult = orderSchema.safeParse(data);

  if (!validationResult.success) {
    console.error('Order validation failed:', validationResult.error);
    return { success: false, error: 'Invalid order data provided.' };
  }

  try {
    const ordersRef = ref(rtdb, 'orders');
    const newOrderRef = push(ordersRef);
    const newOrderId = newOrderRef.key!;
    
    const newOrderData = {
      ...validationResult.data,
      id: newOrderId, // Add the ID to the data itself
      status: 'new' as const, // Initial status
      createdAt: new Date().toISOString(),
    };

    await set(newOrderRef, { ...newOrderData, createdAt: serverTimestamp() });

    // Automatically create the first invoice and send the confirmation email
    const invoiceResult = await createInvoiceFromOrder(newOrderData, true);
    
    if (!invoiceResult.success) {
        // We should probably handle this more gracefully, maybe roll back the order creation
        console.error("Failed to create initial invoice for order:", newOrderId);
        return { success: false, error: "Order was created, but failed to generate the initial invoice." };
    }

    // Send email notification to admin
    const [smtpSettings, globalSettings] = await Promise.all([
      getSmtpSettings(),
      getGlobalSettings(),
    ]);

    const appName = globalSettings.general?.appName || 'Bestiller.com';

    if(smtpSettings.alertEmail) {
        const emails = smtpSettings.alertEmail.split(',').map((e: string) => e.trim()).filter(Boolean);
        if (emails.length > 0) {
             await sendSystemEmail(
                emails,
                `New Order Received: ${data.legalCompanyName}`,
                `
                    <p>A new order has been placed on ${appName}.</p>
                    <h3>Order Details:</h3>
                    <ul>
                    <li><strong>Legal Company Name:</strong> ${data.legalCompanyName}</li>
                    <li><strong>Contact Name:</strong> ${data.customerName}</li>
                    <li><strong>Email:</strong> ${data.email}</li>
                    <li><strong>Accountant Email:</strong> ${data.accountantEmail || 'N/A'}</li>
                    <li><strong>Phone:</strong> ${data.phone}</li>
                    <li><strong>Address:</strong> ${data.address.street}, ${data.address.postalCode} ${data.address.city}, ${data.address.country}</li>
                    <li><strong>Tax ID:</strong> ${data.taxId || 'N/A'}</li>
                    <li><strong>Calendars Ordered:</strong> ${data.calendars}</li>
                    </ul>
                    <h3>Billing Summary:</h3>
                    <ul>
                    <li><strong>Monthly Price:</strong> ${data.monthlyPrice.toFixed(2)} ${data.currency}</li>
                    <li><strong>Setup Fee:</strong> ${data.setupFee.toFixed(2)} ${data.currency}</li>
                    <li><strong>VAT (${newOrderData.vatRate}%):</strong> ${data.vatAmount.toFixed(2)} ${data.currency}</li>
                    <li><strong>Total:</strong> ${data.totalAmount.toFixed(2)} ${data.currency}</li>
                    </ul>
                    <p>Please review the order in the Super Admin panel.</p>
                `,
                undefined,
                undefined,
                appName,
                data.language
            );
        }
    }

    return { success: true };
  } catch (error) {
    console.error('Error creating order:', error);
    return { success: false, error: 'Failed to create the order due to a server error.' };
  }
}

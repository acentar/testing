
import * as React from 'react';
import { OrderClientPage } from './client-page';
import { getGlobalSettings } from '../super-admin/settings/actions';
import { Toaster } from '@/components/ui/toaster';

export default async function OrderPage() {
    const globalSettings = await getGlobalSettings();
    const appName = globalSettings.general?.appName || 'QueuePilot';
    const appLogoUrl = globalSettings.general?.appLogoUrl;
    const storeSettings = globalSettings.store || {
        en: { currency: 'EUR', pricePerCalendar: 9, setupFee: 45, vatRate: 0 },
        da: { currency: 'DKK', pricePerCalendar: 69, setupFee: 350, vatRate: 0 },
        bs: { currency: 'BAM', pricePerCalendar: 15, setupFee: 80, vatRate: 0 },
    };

    return (
        <div className="bg-muted min-h-screen">
            <OrderClientPage appName={appName} appLogoUrl={appLogoUrl} storeSettings={storeSettings} />
            <Toaster />
        </div>
    );
}

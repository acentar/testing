
import { getInvoice } from "@/app/super-admin/invoices/actions";
import { getGlobalSettings } from "@/app/super-admin/settings/actions";
import { notFound } from "next/navigation";
import { InvoiceClient } from "./invoice-client";

export default async function InvoicePage({ params }: { params: Promise<{ invoiceId: string }> }) {
  const { invoiceId } = await params;
  const [invoice, globalSettings] = await Promise.all([
    getInvoice(invoiceId),
    getGlobalSettings()
  ]);

  if (!invoice) {
    notFound();
  }
  
  return (
    <InvoiceClient invoice={invoice} globalSettings={globalSettings} />
  );
}

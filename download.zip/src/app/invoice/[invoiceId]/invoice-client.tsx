
'use client';

import * as React from 'react';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import Image from "next/image";
import type { Invoice } from '@/app/super-admin/invoices/schema';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import { FormattedPrice } from '@/components/formatted-price';

interface InvoiceClientProps {
    invoice: Invoice;
    globalSettings: any;
}

const statusConfig: Record<string, { text: string; color: string }> = {
  pending: { text: "Pending", color: "bg-amber-500/10 text-amber-700 border-amber-500/20" },
  paid: { text: "Paid", color: "bg-green-500/10 text-green-700 border-green-500/20" },
  cancelled: { text: "Cancelled", color: "bg-red-500/10 text-red-700 border-red-500/20" },
};

export function InvoiceClient({ invoice, globalSettings }: InvoiceClientProps) {
    const invoicingSettings = globalSettings.invoicing || {};
    const statusInfo = statusConfig[invoice.status] || statusConfig.pending;
    const invoiceRef = React.useRef<HTMLDivElement>(null);

    const handlePrint = () => {
        window.print();
    };
    
    const subtotal = invoice.lineItems.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0);
    const vatAmount = invoice.amount - subtotal;
    const vatRate = subtotal > 0 ? (vatAmount / subtotal) * 100 : 0;

  return (
    <div className="bg-gray-100 min-h-screen p-4 sm:p-8 print:p-0 print:bg-white">
        <div className="max-w-4xl mx-auto flex justify-end mb-4 print:hidden">
            <Button onClick={handlePrint}>
                <Printer className="mr-2 h-4 w-4" />
                Print / Save as PDF
            </Button>
        </div>
      <Card ref={invoiceRef} id="invoice-content" className="max-w-4xl mx-auto shadow-lg print:shadow-none print:border-none print:rounded-none">
        <CardHeader className="p-8">
           <div className="flex justify-between items-start gap-8">
                <div>
                     {globalSettings.general?.appLogoUrl ? (
                         <Image src={globalSettings.general.appLogoUrl} alt="Company Logo" width={150} height={40} className="mb-4" />
                     ) : (
                         <h1 className="text-3xl font-bold mb-4">{globalSettings.general?.appName || 'Invoice'}</h1>
                     )}
                     <div className="text-sm text-muted-foreground">
                         <p className="font-semibold text-foreground">{invoicingSettings.companyName}</p>
                         <p className="whitespace-pre-wrap">{invoicingSettings.address}</p>
                         <p>Tax ID: {invoicingSettings.taxId}</p>
                     </div>
                </div>
                <div className="text-right flex-shrink-0">
                    <h2 className="text-4xl font-bold uppercase tracking-wider text-gray-800">Invoice</h2>
                    <p className="text-sm text-muted-foreground mt-1"># {invoice.id.substring(0, 10)}...</p>
                    <div className="mt-4">
                        <Badge className={`text-sm ${statusInfo.color}`}>{statusInfo.text}</Badge>
                    </div>
                </div>
           </div>
           <div className="grid grid-cols-2 gap-4 mt-8 text-sm">
                <div>
                    <p className="font-semibold text-gray-600">Bill To:</p>
                    <div className="text-gray-800">
                        <p className="font-medium">{invoice.customerName}</p>
                        <p className="whitespace-pre-wrap">{invoice.customerAddress}</p>
                        {invoice.customerEmail && <p>{invoice.customerEmail}</p>}
                        {invoice.customerPhone && <p>{invoice.customerPhone}</p>}
                        {invoice.taxId && <p>Tax ID: {invoice.taxId}</p>}
                    </div>
                </div>
                <div className="text-right">
                     <p><span className="font-semibold text-gray-600">Invoice Date:</span> {format(new Date(invoice.createdAt), 'LLL d, yyyy')}</p>
                    {invoice.paidAt && <p><span className="font-semibold text-gray-600">Paid Date:</span> {format(new Date(invoice.paidAt), 'LLL d, yyyy')}</p>}
                </div>
           </div>
        </CardHeader>
        <CardContent className="p-8">
            <div className="mt-2">
                <Table>
                    <TableHeader>
                        <TableRow className="bg-gray-50">
                            <TableHead className="w-1/2">Description</TableHead>
                            <TableHead className="text-center">Quantity</TableHead>
                            <TableHead className="text-right">Unit Price</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {invoice.lineItems.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell className="font-medium">{item.description}</TableCell>
                                <TableCell className="text-center">{item.quantity}</TableCell>
                                <TableCell className="text-right"><FormattedPrice price={item.unitPrice} currency={invoice.currency} /></TableCell>
                                <TableCell className="text-right font-medium"><FormattedPrice price={item.unitPrice * item.quantity} currency={invoice.currency} /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
            
            <div className="flex justify-end mt-8">
                <div className="w-full max-w-sm space-y-3">
                    <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span><FormattedPrice price={subtotal} currency={invoice.currency} /></span>
                    </div>
                     <div className="flex justify-between">
                        <span>VAT ({vatRate > 0 ? vatRate.toFixed(0) : '0'}%)</span>
                        <span><FormattedPrice price={vatAmount} currency={invoice.currency} /></span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-lg">
                        <span>Total Amount Due</span>
                        <span><FormattedPrice price={invoice.amount} currency={invoice.currency} /></span>
                    </div>
                </div>
            </div>

            <Separator className="my-8" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
                <div>
                    <h4 className="font-semibold mb-2">Payment Details</h4>
                    <div className="text-muted-foreground whitespace-pre-wrap">
                        {invoicingSettings.bankDetails || 'Bank details not provided.'}
                    </div>
                </div>
                 <div>
                    <h4 className="font-semibold mb-2">Notes</h4>
                    <p className="text-muted-foreground">
                        {invoicingSettings.invoiceNotes || 'Thank you for your business.'}
                    </p>
                </div>
            </div>
        </CardContent>
      </Card>
      <style jsx global>{`
        @media print {
            body {
                background-color: #fff;
            }
        }
      `}</style>
    </div>
  );
}

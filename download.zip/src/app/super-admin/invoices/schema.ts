
import { z } from 'zod';

const lineItemSchema = z.object({
    description: z.string(),
    quantity: z.number(),
    unitPrice: z.number(),
});

export const invoiceSchema = z.object({
  id: z.string(),
  orderId: z.string(),
  customerName: z.string(),
  customerEmail: z.string().email().optional(),
  customerPhone: z.string().optional(),
  customerAddress: z.string().optional(),
  taxId: z.string().optional(),
  amount: z.number(),
  currency: z.enum(['EUR', 'DKK', 'BAM']),
  status: z.enum(['pending', 'paid', 'cancelled']),
  createdAt: z.string().datetime(),
  paidAt: z.string().datetime().optional().nullable(),
  lineItems: z.array(lineItemSchema),
});

export type Invoice = z.infer<typeof invoiceSchema>;

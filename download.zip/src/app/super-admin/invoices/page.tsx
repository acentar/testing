
import * as React from 'react';
import { getInvoices } from './actions';
import { InvoicesClientPage } from './client-page';

export default async function SuperAdminInvoicesPage() {
  const invoices = await getInvoices();
  return <InvoicesClientPage initialInvoices={invoices} />;
}

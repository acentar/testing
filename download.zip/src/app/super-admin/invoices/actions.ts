
'use server';

import admin from '@/lib/firebase-admin';
import { revalidatePath } from 'next/cache';
import type { Order } from '../orders/actions';
import { type Invoice, invoiceSchema } from './schema';
import { getGlobalSettings, getSmtpSettings, sendSystemEmail } from '../settings/actions';

export async function getInvoices(): Promise<Invoice[]> {
  try {
    const invoicesRef = admin.database().ref('invoices');
    const snapshot = await invoicesRef.orderByChild('createdAt').once('value');
    if (!snapshot.exists()) {
      return [];
    }
    const invoicesData = snapshot.val();
    const invoices: Invoice[] = Object.keys(invoicesData).map(key => ({
      id: key,
      ...invoicesData[key],
    }));
    return invoices.reverse();
  } catch (error) {
    console.error("Error fetching invoices:", error);
    return [];
  }
}

export async function getInvoice(id: string): Promise<Invoice | null> {
    try {
        const invoiceRef = admin.database().ref(`invoices/${id}`);
        const snapshot = await invoiceRef.once('value');
        if (!snapshot.exists()) {
            return null;
        }
        return { id: snapshot.key!, ...snapshot.val() };
    } catch (error) {
        console.error(`Error fetching invoice ${id}:`, error);
        return null;
    }
}

export async function updateInvoiceStatus(invoiceId: string, status: 'pending' | 'paid' | 'cancelled'): Promise<{ success: boolean; error?: string }> {
  try {
    const invoiceRef = admin.database().ref(`invoices/${invoiceId}`);
    const updates: any = { status };
    if (status === 'paid') {
        updates.paidAt = new Date().toISOString();
    }
    await invoiceRef.update(updates);
    revalidatePath('/super-admin/orders');
    return { success: true };
  } catch (error) {
    return { success: false, error: 'Failed to update invoice status.' };
  }
}

export async function sendInvoiceByEmail(invoiceId: string): Promise<{ success: boolean; error?: string }> {
    const invoice = await getInvoice(invoiceId);
    if (!invoice) {
        return { success: false, error: 'Invoice not found.' };
    }
    
    if (!invoice.customerEmail) {
        return { success: false, error: 'Customer email is not available for this invoice.'};
    }
    
    const globalSettings = await getGlobalSettings();
    const appName = globalSettings.general?.appName || 'Bestiller.com';
    const orderSnapshot = await admin.database().ref(`orders/${invoice.orderId}`).once('value');
    const order = orderSnapshot.val();
    const orderLanguage = order?.language || 'bs';


    try {
        const invoiceLink = `${process.env.NEXT_PUBLIC_BASE_URL}/invoice/${invoiceId}`;
        const emailBody = `
            <p>Here is a copy of your invoice #${invoice.id.substring(0, 7)}... from ${appName}.</p>
            <p>If you have any questions, please reply to this email.</p>
        `;

        await sendSystemEmail(
            invoice.customerEmail,
            `Your Invoice from ${appName} (#${invoice.id.substring(0, 7)})`,
            emailBody,
            { text: 'View Invoice Online', link: invoiceLink },
            invoice,
            appName,
            orderLanguage
        );

        return { success: true };
    } catch (error: any) {
        console.error(`Error sending email for invoice ${invoiceId}:`, error);
        return { success: false, error: error.message || 'Failed to send invoice email.' };
    }
}

export async function sendOrderConfirmationEmail(orderId: string): Promise<{ success: boolean; error?: string }> {
    const orderRef = admin.database().ref(`orders/${orderId}`);
    const orderSnapshot = await orderRef.once('value');
    if (!orderSnapshot.exists()) {
        return { success: false, error: 'Order not found.' };
    }
    const order: Order = { id: orderSnapshot.key!, ...orderSnapshot.val() };
    const globalSettings = await getGlobalSettings();
    const appName = globalSettings.general?.appName || 'Bestiller.com';
    
    const invoicesRef = admin.database().ref('invoices');
    const invoiceQuery = invoicesRef.orderByChild('orderId').equalTo(orderId).limitToFirst(1);
    const invoiceSnapshot = await invoiceQuery.once('value');
    
    if (!invoiceSnapshot.exists()) {
        return { success: false, error: 'No invoice found for this order. Please create one first.' };
    }
    const invoiceId = Object.keys(invoiceSnapshot.val())[0];
    const invoice = await getInvoice(invoiceId);
    if (!invoice) {
        return { success: false, error: 'Could not retrieve invoice details.' };
    }
    
    try {
        const emailBody = `
            <p>Thank you for your order with ${appName}. We're excited to get you started!</p>
            <p>Your first invoice has been generated and includes the one-time setup fee and your first month of service. You can also view it online using the button below.</p>
            <p>We will be in touch shortly to finalize the setup of your new business account.</p>
        `;
        await sendSystemEmail(
            order.email,
            `Your ${appName} Order Confirmation & Invoice`,
            emailBody,
            { text: 'View Your Invoice Online', link: `${process.env.NEXT_PUBLIC_BASE_URL}/invoice/${invoiceId}` },
            invoice,
            appName,
            order.language
        );
        return { success: true };
    } catch (error: any) {
        console.error("Error sending order confirmation email:", error);
        return { success: false, error: error.message || 'Failed to send confirmation email.' };
    }
}


export async function createInvoiceFromOrder(order: Order, sendEmail: boolean = false): Promise<{ success: boolean, invoiceId?: string, error?: string }> {
    try {
        const newInvoiceData: Omit<Invoice, 'id'> = {
            orderId: order.id,
            customerName: order.legalCompanyName,
            customerAddress: `${order.address.street}\n${order.address.postalCode} ${order.address.city}\n${order.address.country}`,
            customerEmail: order.email,
            customerPhone: order.phone,
            taxId: order.taxId,
            amount: order.totalAmount,
            currency: order.currency,
            status: 'pending',
            createdAt: new Date().toISOString(),
            lineItems: [
                { description: 'One-time setup fee', quantity: 1, unitPrice: order.setupFee },
                { description: `Monthly subscription (${order.calendars} calendars)`, quantity: 1, unitPrice: order.monthlyPrice },
            ],
        };

        const validation = invoiceSchema.omit({ id: true }).safeParse(newInvoiceData);
        if (!validation.success) {
            console.error("Invoice validation failed", validation.error);
            return { success: false, error: "Failed to validate invoice data."};
        }

        const invoicesRef = admin.database().ref('invoices');
        const newInvoiceRef = await invoicesRef.push();
        const newInvoiceId = newInvoiceRef.key!;
        await newInvoiceRef.set(validation.data);

        if (sendEmail) {
            await sendOrderConfirmationEmail(order.id);
        }

        revalidatePath('/super-admin/orders');
        return { success: true, invoiceId: newInvoiceId };
    } catch (error) {
        console.error("Error creating invoice from order:", error);
        return { success: false, error: 'Failed to create invoice.' };
    }
}


export async function deleteInvoice(invoiceId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const invoiceRef = admin.database().ref(`invoices/${invoiceId}`);
        await invoiceRef.remove();
        revalidatePath('/super-admin/orders');
        return { success: true };
    } catch (error) {
        console.error("Error deleting invoice:", error);
        return { success: false, error: 'Failed to delete invoice.' };
    }
}


'use client';

import * as React from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getSortedRowModel,
  SortingState,
} from "@tanstack/react-table"
import { ArrowUpDown, CheckCircle, MoreHorizontal, Hourglass, XCircle, FileText, Trash2, Send } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { type Invoice, updateInvoiceStatus, getInvoices, deleteInvoice, sendInvoiceByEmail } from './actions';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { FormattedPrice } from '@/components/formatted-price';
import Link from 'next/link';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';


interface InvoicesClientPageProps {
  initialInvoices: Invoice[];
}

const statusConfig: Record<Invoice['status'], { icon: React.ElementType, color: string }> = {
    'pending': { icon: Hourglass, color: 'text-amber-500' },
    'paid': { icon: CheckCircle, color: 'text-green-600' },
    'cancelled': { icon: XCircle, color: 'text-red-500' },
}

export function InvoicesClientPage({ initialInvoices }: InvoicesClientPageProps) {
    const [invoices, setInvoices] = React.useState(initialInvoices);
    const [loading, setLoading] = React.useState(true);
    const [sorting, setSorting] = React.useState<SortingState>([{ id: 'createdAt', desc: true }]);
    const { toast } = useToast();

    const refreshInvoices = React.useCallback(async () => {
        setLoading(true);
        const fetchedInvoices = await getInvoices();
        setInvoices(fetchedInvoices);
        setLoading(false);
    }, []);

    React.useEffect(() => {
        setInvoices(initialInvoices);
        setLoading(false);
    }, [initialInvoices]);
    
    const handleStatusChange = async (invoiceId: string, status: Invoice['status']) => {
        const result = await updateInvoiceStatus(invoiceId, status);
        if (result.success) {
            refreshInvoices();
            toast({ title: "Invoice Status Updated" });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
    }
    
    const handleDeleteInvoice = async (invoiceId: string) => {
        const result = await deleteInvoice(invoiceId);
        if (result.success) {
            toast({ title: "Invoice Deleted" });
            refreshInvoices();
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
    }

    const handleResendInvoice = async (invoiceId: string) => {
        const result = await sendInvoiceByEmail(invoiceId);
        if (result.success) {
            toast({ title: "Invoice Sent", description: "The invoice has been re-sent to the customer." });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
    }
    
    const columns: ColumnDef<Invoice>[] = [
    {
      accessorKey: "id",
      header: "Invoice ID",
      cell: ({ row }) => <div className="font-mono text-xs text-muted-foreground">{row.original.id}</div>,
    },
    {
      accessorKey: "customerName",
      header: "Customer",
      cell: ({ row }) => <div className="font-medium">{row.original.customerName}</div>,
    },
    {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ row }) => <FormattedPrice price={row.original.amount} currency={row.original.currency} />,
    },
    {
        accessorKey: "createdAt",
        header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Created Date <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
        cell: ({ row }) => format(new Date(row.original.createdAt), 'LLL d, yyyy')
    },
    {
        accessorKey: "paidAt",
        header: "Paid Date",
        cell: ({ row }) => row.original.paidAt ? format(new Date(row.original.paidAt), 'LLL d, yyyy') : 'N/A',
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status;
            const { icon: Icon, color } = statusConfig[status];
            return (
                <Badge variant="outline" className={color}>
                    <Icon className="mr-2 h-4 w-4"/>
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                </Badge>
            )
        }
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const invoice = row.original;
            return (
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem asChild>
                             <Link href={`/invoice/${invoice.id}`} target="_blank">View Invoice</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleResendInvoice(invoice.id)}>
                            <Send className="mr-2 h-4 w-4" />
                            Resend Email
                        </DropdownMenuItem>
                        <DropdownMenuSub>
                            <DropdownMenuSubTrigger>Change status</DropdownMenuSubTrigger>
                            <DropdownMenuSubContent>
                                <DropdownMenuItem onClick={() => handleStatusChange(invoice.id, 'pending')}>Pending</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleStatusChange(invoice.id, 'paid')}>Paid</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleStatusChange(invoice.id, 'cancelled')}>Cancelled</DropdownMenuItem>
                            </DropdownMenuSubContent>
                        </DropdownMenuSub>
                        <DropdownMenuSeparator />
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}>
                                    <Trash2 className="mr-2 h-4 w-4" /> Delete Invoice
                                </DropdownMenuItem>
                            </AlertDialogTrigger>
                             <AlertDialogContent>
                                <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This will permanently delete invoice #{invoice.id.substring(0, 7)}... This action cannot be undone.
                                </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteInvoice(invoice.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                 </DropdownMenu>
            )
        },
    }
  ]

  const table = useReactTable({
    data: invoices,
    columns,
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    state: { sorting },
  });

  return (
    <Card>
        <CardHeader>
            <CardTitle>Invoice Management</CardTitle>
            <CardDescription>
                View and manage all generated invoices.
            </CardDescription>
        </CardHeader>
      <CardContent>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
                <TableRow><TableCell colSpan={columns.length} className="h-24 text-center"><Skeleton className="h-10 w-full" /></TableCell></TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No invoices found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
      </CardContent>
    </Card>
  );
}

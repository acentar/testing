
'use client';

import * as React from 'react';
import { usePathname } from 'next/navigation';
import { StaffScreenProvider } from '@/app/[id]/staff-app/staff-screen-context';

export function StaffScreenProviderWrapper({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const isBusinessSpecificPage = /^\/super-admin\/businesses\/([^/]+)/.test(pathname);
    const businessIdMatch = pathname.match(/^\/super-admin\/businesses\/([^/]+)/);
    const businessId = businessIdMatch ? businessIdMatch[1] : null;

    if (isBusinessSpecificPage && businessId) {
        return <StaffScreenProvider>{children}</StaffScreenProvider>;
    }

    return <>{children}</>;
}

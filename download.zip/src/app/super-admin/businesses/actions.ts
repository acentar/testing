
'use server';

import admin from '@/lib/firebase-admin';
import { storage } from '@/lib/firebase';
import { ref as storageRef, deleteObject } from 'firebase/storage';
import { revalidatePath } from 'next/cache';

export type Business = {
  id: string;
  businessName: string;
  address: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
  };
  status: 'Active' | 'Pending' | 'Archived';
  bookings: number;
  theme?: 'light' | 'dark';
  currency?: 'DKK' | 'BAM';
  [key: string]: any;
};

// Action to get all businesses from the Realtime Database
export async function getBusinesses(): Promise<Business[]> {
  try {
    const businessesRef = admin.database().ref('businesses');
    const snapshot = await businessesRef.once('value');
    if (snapshot.exists()) {
      const businessesData = snapshot.val();
      const businesses: Business[] = [];
      
      for(const businessId in businessesData) {
        const businessData = businessesData[businessId];
        const bookingsCount = businessData.bookings ? Object.keys(businessData.bookings).length : 0;

        businesses.push({
          id: businessId,
          businessName: businessData.businessName,
          address: businessData.address,
          status: businessData.status || 'Pending',
          bookings: bookingsCount,
          theme: businessData.theme || 'dark',
          currency: businessData.currency || 'DKK',
          slug: businessData.slug || ''
        });
      }
      
      // Sort businesses by name alphabetically
      return businesses.sort((a, b) => a.businessName.localeCompare(b.businessName));
    }
    return [];
  } catch (error) {
    console.error("Error fetching businesses:", error);
    return [];
  }
}

// Action to get a single business by its ID
export async function getBusiness(id: string): Promise<Business | null> {
    try {
        const businessRef = admin.database().ref(`businesses/${id}`);
        const snapshot = await businessRef.once('value');
        if (snapshot.exists()) {
            return { id: snapshot.key, ...snapshot.val() };
        }
        return null;
    } catch (error) {
        console.error("Error fetching business:", error);
        return null;
    }
}

async function findBusinessBy(field: string, value: string): Promise<Business | null> {
    if (!value) return null;
    try {
        const businessesRef = admin.database().ref('businesses');
        const snapshot = await businessesRef.orderByChild(field).equalTo(value).once('value');
        if (snapshot.exists()) {
            const businessId = Object.keys(snapshot.val())[0];
            const businessData = snapshot.val()[businessId];
            return { id: businessId, ...businessData };
        }
        return null;
    } catch (error) {
        console.error(`Error fetching business by ${field}:`, error);
        return null;
    }
}

export async function getBusinessByKioskLoginName(loginName: string): Promise<Business | null> {
    if (!loginName) return null;
    try {
        const businessesRef = admin.database().ref('businesses');
        const snapshot = await businessesRef.orderByChild('staffAppSettings/kioskLoginName').equalTo(loginName).once('value');
        if (snapshot.exists()) {
            const businessId = Object.keys(snapshot.val())[0];
            const businessData = snapshot.val()[businessId];
            return { id: businessId, ...businessData };
        }
        return null;
    } catch (error) {
        console.error(`Error fetching business by kioskLoginName:`, error);
        return null;
    }
}


// Action to get a single business by its slug
export async function getBusinessBySlug(slug: string): Promise<Business | null> {
    return findBusinessBy('slug', slug);
}

export async function deleteBusiness(businessId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const business = await getBusiness(businessId);
        if (!business) {
            return { success: false, error: "Business not found." };
        }

        // Delete logo from Storage
        if (business.logoUrl) {
            try {
                const logoStorageRef = storageRef(storage, business.logoUrl);
                await deleteObject(logoStorageRef);
            } catch (e: any) {
                if (e.code !== 'storage/object-not-found') {
                    console.warn(`Could not delete logo for business ${businessId}: ${e.message}`);
                }
            }
        }
        
        // Delete business pictures from Storage
        if (business.businessPictures && business.businessPictures.length > 0) {
            for (const url of business.businessPictures) {
                try {
                     const pictureStorageRef = storageRef(storage, url);
                     await deleteObject(pictureStorageRef);
                } catch(e: any) {
                     if (e.code !== 'storage/object-not-found') {
                        console.warn(`Could not delete picture ${url} for business ${businessId}: ${e.message}`);
                    }
                }
            }
        }

        // Delete data from Realtime Database
        const businessRef = admin.database().ref(`businesses/${businessId}`);
        await businessRef.remove();
        
        revalidatePath('/super-admin/businesses');
        
        return { success: true };

    } catch (error) {
        console.error("Error deleting business:", error);
        return { success: false, error: 'An unexpected error occurred while deleting the business.' };
    }
}


export type Booking = {
    id: string;
    serviceId: string;
    serviceName: string;
    extensions?: { id: string; name: string; price: number; duration: number }[];
    staffId: string;
    staffName: string;
    date: string; // yyyy-MM-dd
    time: string; // HH:mm
    customerName: string;
    customerPhone: string;
    totalPrice: number;
    totalDuration: number;
    status: 'waiting' | 'in-progress' | 'completed' | 'cancelled';
    serviceStartTime?: string;
    customerId?: string;
};

export type AggregatedBooking = {
    id: string;
    bookingId: string;
    customerName: string;
    customerPhone: string;
    serviceId: string;
    serviceName: string;
    staffName: string;
    staffId: string;
    date: string;
    time: string;
    status: 'waiting' | 'in-progress' | 'completed' | 'cancelled';
    totalDuration: number;
    dateTime: number; 
    createdAt?: number | string;
    serviceStartTime?: string;
    serviceEndTime?: string;
};

export type BusinessCustomer = {
    id: string;
    name: string;
    phone: string;
    createdAt: string; 
    lastSeen: string;
};

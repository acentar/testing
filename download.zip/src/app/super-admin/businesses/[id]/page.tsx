
import { redirect } from "next/navigation";

export default async function EditBusinessPage({ params }: { params: { id: string } }) {
  const { id } = params;
  redirect(`/super-admin/businesses/${id}/dashboard`);
}

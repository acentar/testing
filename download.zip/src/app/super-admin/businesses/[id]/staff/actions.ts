
'use server';

import { z } from 'zod';
import { staffSchema } from './schema';
import admin from '@/lib/firebase-admin';
import { storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { revalidatePath } from 'next/cache';
import sharp from 'sharp';

export type Staff = z.infer<typeof staffSchema> & { id: string };

async function streamToBuffer(stream: ReadableStream<Uint8Array>): Promise<Buffer> {
    const reader = stream.getReader();
    const chunks: Uint8Array[] = [];
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}

async function handleFileUpload(file: File | null): Promise<string> {
    if (!file) return '';

    const buffer = await streamToBuffer(file.stream());
    const webpBuffer = await sharp(buffer).webp({ quality: 80 }).toBuffer();
    const uniqueFileName = `${Date.now()}_${file.name.split('.')[0]}.webp`;
    const filePath = `staff/${uniqueFileName}`;
    const fileStorageRef = storageRef(storage, filePath);

    await uploadBytes(fileStorageRef, webpBuffer, { contentType: 'image/webp' });
    return getDownloadURL(fileStorageRef);
}


export async function addStaff(businessId: string, formData: FormData) {
  const jsonData = formData.get('jsonData') as string;
  if (!jsonData) {
    return { success: false, errors: { _root: ["Missing form data."] } };
  }
  const data = JSON.parse(jsonData);

  const validationResult = staffSchema.safeParse(data);
  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }

  try {
    const { image, ...staffData } = validationResult.data;
    const imageFile = formData.get('image') as File | null;
    let imageUrl = '';
    if (imageFile) {
        imageUrl = await handleFileUpload(imageFile);
    }

    const staffRef = admin.database().ref(`businesses/${businessId}/staff`);
    const newStaffRef = staffRef.push();
    await newStaffRef.set({ ...staffData, imageUrl, createdAt: new Date().toISOString() });

    revalidatePath(`/super-admin/businesses/${businessId}/staff`);
    return { success: true };
  } catch (error) {
    console.error("Error adding staff:", error);
    return { success: false, errors: { _root: ['Failed to add staff member.'] } };
  }
}

export async function updateStaff(businessId: string, staffId: string, formData: FormData) {
    const jsonData = formData.get('jsonData') as string;
    if (!jsonData) {
        return { success: false, errors: { _root: ["Missing form data."] } };
    }
    const data = JSON.parse(jsonData);

    const validationResult = staffSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        const { image, ...staffData } = validationResult.data;
        const imageFile = formData.get('image') as File | null;
        let imageUrl = data.imageUrl; 
        
        if (imageFile) {
            imageUrl = await handleFileUpload(imageFile);
        }

        const staffRef = admin.database().ref(`businesses/${businessId}/staff/${staffId}`);
        await staffRef.update({ ...staffData, imageUrl, updatedAt: new Date().toISOString() });

        revalidatePath(`/super-admin/businesses/${businessId}/staff`);
        return { success: true };
    } catch (error) {
        console.error("Error updating staff:", error);
        return { success: false, errors: { _root: ['Failed to update staff member.'] } };
    }
}


export async function getStaff(businessId: string): Promise<Staff[]> {
    try {
        const staffRef = admin.database().ref(`businesses/${businessId}/staff`);
        const snapshot = await staffRef.orderByChild('fullName').once('value');
        if (!snapshot.exists()) {
            return [];
        }
        const staffData = snapshot.val();
        const staffList: Staff[] = Object.keys(staffData).map(id => ({
            id,
            ...staffData[id]
        }));
        return staffList;
    } catch (error) {
        console.error("Error fetching staff:", error);
        return [];
    }
}

export async function deleteStaff(businessId: string, staffId: string) {
    try {
        const staffRef = admin.database().ref(`businesses/${businessId}/staff/${staffId}`);
        const snapshot = await staffRef.once('value');
        const staffData = snapshot.val();

        if (staffData && staffData.imageUrl) {
             try {
                const imageStorageRef = storageRef(storage, staffData.imageUrl);
                await deleteObject(imageStorageRef);
            } catch (e: any) {
                if (e.code !== 'storage/object-not-found') {
                    console.warn(`Could not delete image for staff ${staffId}: ${e.message}`);
                }
            }
        }

        await staffRef.remove();
        revalidatePath(`/super-admin/businesses/${businessId}/staff`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to delete staff member.'] } };
    }
}


'use client';

import * as React from 'react';
import { MoreHorizontal, PlusCircle, Trash2 } from 'lucide-react';
import { getStaff, deleteStaff } from './actions';
import type { Staff } from './schema';
import type { Service } from '../services/schema';
import { useToast } from '@/hooks/use-toast';

import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { StaffSettingsForm } from './staff-settings-form';

interface StaffManagementClientProps {
    businessId: string;
    allServices: Service[];
}

export function StaffManagementClient({ businessId, allServices }: StaffManagementClientProps) {
  const [staff, setStaff] = React.useState<Staff[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [selectedStaff, setSelectedStaff] = React.useState<Staff | null>(null);
  const { toast } = useToast();

  const loadStaff = React.useCallback(async () => {
    setLoading(true);
    const fetchedStaff = await getStaff(businessId);
    setStaff(fetchedStaff);
    setLoading(false);
  }, [businessId]);

  React.useEffect(() => {
    loadStaff();
  }, [loadStaff]);
  
  const handleAddNew = () => {
    setSelectedStaff(null);
    setIsFormOpen(true);
  }

  const handleEdit = (staffMember: Staff) => {
    setSelectedStaff(staffMember);
    setIsFormOpen(true);
  };

  const handleDelete = async (staffId: string) => {
    const result = await deleteStaff(businessId, staffId);
    if (result.success) {
      toast({
        title: "Staff member deleted",
        description: "The staff member has been successfully deleted.",
      });
      loadStaff();
    } else {
      toast({
        variant: "destructive",
        title: "Error",
        description: (result as any).errors?._root?.[0] || "Failed to delete staff member.",
      });
    }
  };
  
  if (isFormOpen) {
    return <StaffSettingsForm 
              businessId={businessId}
              staffMember={selectedStaff}
              allServices={allServices}
              onFinished={() => {
                setIsFormOpen(false);
                loadStaff();
              }}
           />
  }

  if (loading) {
    return (
        <div className="space-y-4">
            <div className="flex items-center justify-end">
                <Skeleton className="h-10 w-28" />
            </div>
            <div className="border rounded-md">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Full Name</TableHead>
                            <TableHead>Availability</TableHead>
                            <TableHead><span className="sr-only">Actions</span></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        <TableRow>
                            <TableCell colSpan={3}>
                                <Skeleton className="h-8" />
                            </TableCell>
                        </TableRow>
                        <TableRow>
                             <TableCell colSpan={3}>
                                <Skeleton className="h-8" />
                            </TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
            </div>
        </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-end">
         <Button onClick={handleAddNew}>
            <PlusCircle className="mr-2 h-4 w-4" /> Add New Staff
        </Button>
      </div>
      <div className="border rounded-md">
        <Table>
            <TableHeader>
            <TableRow>
                <TableHead>Full Name</TableHead>
                <TableHead>Availability</TableHead>
                <TableHead>
                <span className="sr-only">Actions</span>
                </TableHead>
            </TableRow>
            </TableHeader>
            <TableBody>
            {staff.length === 0 ? (
                <TableRow>
                    <TableCell colSpan={3} className="text-center h-24">
                        No staff members found.
                    </TableCell>
                </TableRow>
            ) : (
                staff.map((staffMember) => (
                    <TableRow key={staffMember.id}>
                        <TableCell className="font-medium">{staffMember.fullName}</TableCell>
                        <TableCell>
                            <div className="flex flex-wrap gap-1">
                                {staffMember.availability.filter(d => d.working).map(day => (
                                    <Badge key={day.day} variant="secondary">{day.day.substring(0,3)}</Badge>
                                ))}
                            </div>
                        </TableCell>
                        <TableCell>
                            <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button
                                aria-haspopup="true"
                                size="icon"
                                variant="ghost"
                                >
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Toggle menu</span>
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => handleEdit(staffMember)}>Edit</DropdownMenuItem>
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-500">
                                            <Trash2 className="mr-2 h-4 w-4" />
                                            Delete
                                        </DropdownMenuItem>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                        <AlertDialogDescription>
                                            This action cannot be undone. This will permanently delete the staff member
                                            and remove their data from our servers.
                                        </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                                        <AlertDialogAction onClick={() => handleDelete(staffMember.id)} className="bg-destructive hover:bg-destructive/90">Continue</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>

                            </DropdownMenuContent>
                            </DropdownMenu>
                        </TableCell>
                    </TableRow>
                ))
            )}
            </TableBody>
        </Table>
      </div>
    </div>
  );
}

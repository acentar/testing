
import { z } from 'zod';

export const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/; // HH:mm format

export const breakSchema = z.object({
    from: z.string().regex(timeRegex, 'Invalid time format'),
    to: z.string().regex(timeRegex, 'Invalid time format'),
});

export const dayAvailabilitySchema = z.object({
  day: z.string(),
  working: z.boolean().optional(),
  workFrom: z.string().regex(timeRegex, 'Invalid time format').optional().nullable(),
  workTo: z.string().regex(timeRegex, 'Invalid time format').optional().nullable(),
  breaks: z.array(breakSchema).default([])
}).refine(data => {
  if (!data.working) {
    return true;
  }
  if (!data.workFrom || !data.workTo || data.workFrom >= data.workTo) {
    return false;
  }
  if (data.breaks) {
    for (const b of data.breaks) {
      if (b.from >= b.to || b.from < data.workFrom || b.to > data.workTo) {
        return false;
      }
    }
  }
  return true;
}, {
  message: "For working days, start time must be before end time, and all breaks must be valid and within the working hours.",
  path: ['workFrom'] 
});


export const staffSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters long.'),
  email: z.string().email('Please enter a valid email.').optional().nullable().or(z.literal('')),
  phone: z.string().optional().nullable().or(z.literal('')),
  imageUrl: z.string().optional().nullable(),
  image: z.any().optional(),
  availability: z.array(dayAvailabilitySchema).default([]),
  canPerformAllServices: z.boolean().default(true),
  assignedServices: z.array(z.string()).default([]),
});


export type Staff = z.infer<typeof staffSchema> & { id: string };
export type StaffFormData = z.infer<typeof staffSchema>;

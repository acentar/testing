
'use client';

import * as React from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { type Staff, type StaffFormData, staffSchema } from './schema';
import type { Service } from '../services/schema';
import { addStaff, updateStaff } from './actions';
import { useToast } from '@/hooks/use-toast';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { ImageCropper } from '@/components/image-cropper';
import { Loader2, ArrowLeft, Trash2 } from 'lucide-react';
import Image from 'next/image';
import { Label } from '@/components/ui/label';

const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

interface StaffSettingsFormProps {
    businessId: string;
    staffMember: Staff | null;
    allServices: Service[];
    onFinished: () => void;
}

export function StaffSettingsForm({ businessId, staffMember, allServices, onFinished }: StaffSettingsFormProps) {
    const { toast } = useToast();
    const isEditMode = !!staffMember;
    
    const form = useForm<StaffFormData>({
        resolver: zodResolver(staffSchema),
        defaultValues: {
            fullName: '',
            email: '',
            phone: '',
            availability: daysOfWeek.map(day => ({
                day,
                working: true,
                workFrom: '09:00',
                workTo: '17:00',
                breaks: []
            })),
            canPerformAllServices: true,
            assignedServices: [],
            imageUrl: '',
        },
    });
    
    const { fields: availabilityFields } = useFieldArray({
        control: form.control,
        name: "availability",
    });

    React.useEffect(() => {
        if (staffMember) {
            form.reset({
                ...staffMember,
                email: staffMember.email ?? '',
                phone: staffMember.phone ?? '',
                imageUrl: staffMember.imageUrl ?? '',
                availability: staffMember.availability && staffMember.availability.length === 7 
                    ? staffMember.availability 
                    : daysOfWeek.map(day => {
                        const existingDay = staffMember.availability?.find(d => d.day === day);
                        return existingDay || { day, working: false, workFrom: '09:00', workTo: '17:00', breaks: [] };
                    })
            });
        }
    }, [staffMember, form]);

    const onSubmit = async (data: StaffFormData) => {
        const formData = new FormData();
        const { image, ...jsonData } = data;
        formData.append('jsonData', JSON.stringify(jsonData));
        if (image instanceof File) {
            formData.append('image', image);
        }

        const result = isEditMode
            ? await updateStaff(businessId, staffMember.id, formData)
            : await addStaff(businessId, formData);

        if (result.success) {
            toast({ title: `Staff member ${isEditMode ? 'updated' : 'added'} successfully` });
            onFinished();
        } else {
            toast({ variant: 'destructive', title: 'Error', description: (result as any).errors?._root?.[0] || 'Failed to save staff member.' });
        }
    }

    const { isSubmitting } = form.formState;
    const canPerformAllServices = form.watch('canPerformAllServices');

    return (
         <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-3xl font-bold tracking-tight">{isEditMode ? 'Edit Staff Member' : 'Add New Staff Member'}</h2>
                        <p className="text-muted-foreground">Manage personal details, availability, and services.</p>
                    </div>
                     <Button type="button" variant="ghost" onClick={onFinished}><ArrowLeft className="mr-2 h-4 w-4" /> Back to Staff List</Button>
                </div>
                
                 <Card>
                    <CardHeader>
                        <CardTitle>Personal Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Full Name</FormLabel>
                                    <FormControl><Input placeholder="e.g., Jane Doe" {...field} /></FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="grid md:grid-cols-2 gap-4">
                            <FormField control={form.control} name="email" render={({ field }) => (<FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="jane.d@example.com" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)} />
                            <FormField control={form.control} name="phone" render={({ field }) => (<FormItem><FormLabel>Phone</FormLabel><FormControl><Input type="tel" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)} />
                        </div>
                        <FormField
                        control={form.control}
                        name="image"
                        render={({ field }) => (
                             <FormItem>
                                <FormLabel>Profile Image</FormLabel>
                                {staffMember?.imageUrl && (
                                     <div className="my-2 relative h-24 w-24 rounded-full overflow-hidden border">
                                        <Image src={staffMember.imageUrl} alt="Current Image" fill className="object-cover" unoptimized/>
                                    </div>
                                )}
                                <ImageCropper
                                    aspectRatio={1}
                                    onFileChange={(file) => field.onChange(file)}
                                />
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader>
                        <CardTitle>Services</CardTitle>
                        <CardDescription>Specify which services this staff member can perform.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <FormField
                            control={form.control}
                            name="canPerformAllServices"
                            render={({ field }) => (
                                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                    <div className="space-y-0.5">
                                        <FormLabel>Can perform all services</FormLabel>
                                    </div>
                                    <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                                </FormItem>
                            )}
                        />
                        {!canPerformAllServices && (
                            <FormField
                                control={form.control}
                                name="assignedServices"
                                render={() => (
                                    <FormItem>
                                         <FormLabel>Assigned Services</FormLabel>
                                        <div className="max-h-60 overflow-y-auto rounded-md border p-4 space-y-2">
                                            {allServices.map((service) => (
                                                <FormField
                                                    key={service.id}
                                                    control={form.control}
                                                    name="assignedServices"
                                                    render={({ field }) => (
                                                         <FormItem key={service.id} className="flex flex-row items-start space-x-3 space-y-0">
                                                            <FormControl>
                                                                <Checkbox
                                                                    checked={field.value?.includes(service.id)}
                                                                    onCheckedChange={(checked) => {
                                                                        return checked
                                                                        ? field.onChange([...(field.value || []), service.id])
                                                                        : field.onChange(field.value?.filter((value) => value !== service.id))
                                                                    }}
                                                                />
                                                            </FormControl>
                                                            <FormLabel className="font-normal">{service.name}</FormLabel>
                                                        </FormItem>
                                                    )}
                                                />
                                            ))}
                                        </div>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        )}
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader>
                        <CardTitle>Weekly Availability</CardTitle>
                        <CardDescription>Set working hours and breaks for each day.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                         {availabilityFields.map((field, index) => {
                             const { fields: breakFields, append: appendBreak, remove: removeBreak } = useFieldArray({
                                control: form.control,
                                name: `availability.${index}.breaks`
                            });

                             return (
                                <div key={field.id} className="p-4 border rounded-md space-y-3">
                                    <div className="flex items-center justify-between">
                                        <h4 className="font-semibold">{field.day}</h4>
                                        <FormField
                                            control={form.control}
                                            name={`availability.${index}.working`}
                                            render={({ field: switchField }) => (
                                                <FormItem className="flex items-center gap-2 space-y-0">
                                                    <FormLabel>Working</FormLabel>
                                                    <FormControl><Switch checked={switchField.value} onCheckedChange={switchField.onChange} /></FormControl>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                     {form.watch(`availability.${index}.working`) && (
                                        <div className="space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <FormField control={form.control} name={`availability.${index}.workFrom`} render={({ field: timeField }) => <FormItem><FormLabel>From</FormLabel><FormControl><Input type="time" {...timeField} value={timeField.value ?? ''}/></FormControl></FormItem>} />
                                                <FormField control={form.control} name={`availability.${index}.workTo`} render={({ field: timeField }) => <FormItem><FormLabel>To</FormLabel><FormControl><Input type="time" {...timeField} value={timeField.value ?? ''}/></FormControl></FormItem>} />
                                            </div>
                                             <div>
                                                <FormLabel className="text-sm">Breaks</FormLabel>
                                                 <div className="space-y-2 mt-1">
                                                {breakFields.map((breakField, breakIndex) => (
                                                     <div key={breakField.id} className="flex items-center gap-2">
                                                         <FormField control={form.control} name={`availability.${index}.breaks.${breakIndex}.from`} render={({ field: breakTimeField }) => <FormItem className="flex-1"><FormControl><Input type="time" {...breakTimeField} value={breakTimeField.value ?? ''} /></FormControl></FormItem>} />
                                                         <span>-</span>
                                                         <FormField control={form.control} name={`availability.${index}.breaks.${breakIndex}.to`} render={({ field: breakTimeField }) => <FormItem className="flex-1"><FormControl><Input type="time" {...breakTimeField} value={breakTimeField.value ?? ''} /></FormControl></FormItem>} />
                                                        <Button type="button" variant="ghost" size="icon" onClick={() => removeBreak(breakIndex)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                                     </div>
                                                ))}
                                                <Button type="button" variant="outline" size="sm" onClick={() => appendBreak({ from: '12:00', to: '13:00'})}>Add Break</Button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                             )
                         })}
                    </CardContent>
                </Card>

                <div className="flex justify-end">
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isEditMode ? 'Save Changes' : 'Add Staff Member'}
                    </Button>
                </div>
            </form>
        </Form>
    );
}

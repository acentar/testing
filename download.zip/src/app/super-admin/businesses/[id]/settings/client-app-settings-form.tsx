'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { updateBusiness } from '../../new/actions';
import { type BusinessFormData, businessSchema } from '../../new/schema';
import type { Business } from '../../actions';
import { Textarea } from '@/components/ui/textarea';
import { ImageCropper } from '@/components/image-cropper';
import { Checkbox } from '@/components/ui/checkbox';
import Image from 'next/image';
import { Label } from '@/components/ui/label';

const clientAppSettingsSchema = businessSchema.pick({
    // Landing Page
    showAboutUs: true,
    showLocation: true,
    showOperatingHours: true,
    description: true,
    bookingPolicy: true,
    weekStartsOn: true,
    // Booking Policies
    cancellationPolicy: true,
    leadTimeValue: true,
    leadTimeUnit: true,
    maxBookingsPerUser: true,
    schedulingWindowValue: true,
    schedulingWindowUnit: true,
    // SEO
    metaTitle: true,
    metaDescription: true,
    metaImage: true,
    metaImageToRemove: true,
});

type ClientAppSettingsFormData = z.infer<typeof clientAppSettingsSchema>;

interface ClientAppSettingsFormProps {
  business: Business;
  onSave: () => void;
}

export function ClientAppSettingsForm({ business, onSave }: ClientAppSettingsFormProps) {
  const { toast } = useToast();

  const form = useForm<ClientAppSettingsFormData>({
    resolver: zodResolver(clientAppSettingsSchema),
    defaultValues: {},
  });

  React.useEffect(() => {
    if (business) {
        form.reset({
          showAboutUs: business.showAboutUs ?? true,
          showLocation: business.showLocation ?? true,
          showOperatingHours: business.showOperatingHours ?? true,
          description: business.description ?? '',
          bookingPolicy: business.bookingPolicy ?? '',
          weekStartsOn: business.weekStartsOn ?? 1,
          cancellationPolicy: business.cancellationPolicy ?? 'anytime',
          leadTimeValue: business.leadTimeValue ?? 0,
          leadTimeUnit: business.leadTimeUnit ?? 'minutes',
          maxBookingsPerUser: business.maxBookingsPerUser ?? '',
          schedulingWindowValue: business.schedulingWindowValue ?? 0,
          schedulingWindowUnit: business.schedulingWindowUnit ?? 'days',
          metaTitle: business.metaTitle ?? '',
          metaDescription: business.metaDescription ?? '',
          metaImageToRemove: false,
        });
    }
  }, [business, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: ClientAppSettingsFormData) => {
    const formData = new FormData();
    const { metaImage, ...jsonData } = data;
    formData.append('jsonData', JSON.stringify(jsonData));
    
    if (metaImage instanceof File) formData.append('metaImage', metaImage);
    
    const result = await updateBusiness(business.id, formData);

    if (result.success) {
      toast({ title: "Settings updated successfully", description: "Client app settings have been saved." });
      onSave();
    } else {
      toast({ variant: "destructive", title: "Error updating settings", description: "Could not save settings." });
    }
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl">
            <Card>
                <CardHeader>
                    <CardTitle>Booking page settings</CardTitle>
                    <CardDescription>Control what customers see on your main booking page.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>About Us / Description</FormLabel>
                                <FormControl>
                                    <Textarea placeholder="Tell your customers about your business..." {...field} value={field.value ?? ''} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>Booking policies</CardTitle>
                    <CardDescription>Set rules and limits for online bookings.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <FormField
                        control={form.control}
                        name="bookingPolicy"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Booking policy text</FormLabel>
                                <FormControl>
                                    <Textarea placeholder="e.g., 'Cancellations must be made 24 hours in advance.'" {...field} value={field.value ?? ''} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>SEO and Social Sharing</CardTitle>
                    <CardDescription>Optimize how your booking page appears on Google and social media.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <FormField
                        control={form.control}
                        name="metaTitle"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Meta Title</FormLabel>
                                <FormControl>
                                    <Input {...field} value={field.value ?? ''} maxLength={60} />
                                </FormControl>
                                <FormDescription>Max 60 characters. This is what shows up in the browser tab and Google search results.</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="metaDescription"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Meta Description</FormLabel>
                                <FormControl>
                                    <Textarea {...field} value={field.value ?? ''} maxLength={150} />
                                </FormControl>
                                <FormDescription>Max 150 characters. A short summary for search engines and social media previews.</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                     <FormField
                        control={form.control}
                        name="metaImage"
                        render={({ field }) => (
                             <FormItem>
                                <FormLabel>Social Sharing Image</FormLabel>
                                {business.metaImageUrl && !form.watch('metaImageToRemove') && (
                                     <div className="my-2 relative aspect-video w-full max-w-sm">
                                        <Image src={business.metaImageUrl} alt="Current Meta Image" layout="fill" objectFit="cover" className="rounded-md border" unoptimized />
                                    </div>
                                )}
                                <ImageCropper
                                    aspectRatio={1.91 / 1}
                                    onFileChange={(file) => field.onChange(file)}
                                />
                                {business.metaImageUrl && (
                                     <FormField
                                        control={form.control}
                                        name="metaImageToRemove"
                                        render={({ field: removeField }) => (
                                            <FormItem className="flex items-center gap-2 pt-2">
                                                <FormControl>
                                                    <Checkbox checked={removeField.value} onCheckedChange={removeField.onChange} id="remove-meta-image" />
                                                </FormControl>
                                                <Label htmlFor="remove-meta-image" className="flex items-center gap-1 cursor-pointer"><Trash2 className="h-4 w-4"/> Remove Current Image</Label>
                                            </FormItem>
                                        )}
                                    />
                                )}
                                <FormDescription>Recommended size: 1200x630 pixels. This image will be shown when you share the link on platforms like Facebook or WhatsApp.</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </CardContent>
            </Card>
          <div className="flex justify-end gap-2">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Client App Settings
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

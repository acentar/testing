
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2, Info, Image as ImageIcon, PlusCircle, Trash2, Edit, KeyRound, RefreshCw } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import {
  Form,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { updateBusiness, createStaffKioskUser, deleteStaffKioskUser, updateStaffKioskUser, resetStaffKioskUserPin } from '@/app/super-admin/businesses/new/actions';
import { type BusinessFormData, type StaffKioskUser, type StaffKioskUserFormData, staffKioskUserSchema } from '@/app/super-admin/businesses/new/schema';
import type { Business } from '@/app/super-admin/businesses/actions';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { PhoneInput } from '@/components/phone-input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';


function KioskUserFormDialog({
  businessId,
  user,
  onSave,
  children
}: {
  businessId: string;
  user?: StaffKioskUser;
  onSave: () => void;
  children: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const { toast } = useToast();
  const isEditMode = !!user;

  const form = useForm<StaffKioskUserFormData>({
    resolver: zodResolver(staffKioskUserSchema),
    defaultValues: {
      fullName: '',
      phone: '',
      phoneCountry: 'BA',
    },
  });

  React.useEffect(() => {
    if (open) {
      if (user) {
        form.reset({
          fullName: user.fullName,
          phone: user.phone,
          phoneCountry: user.phoneCountry || 'BA',
        });
      } else {
        form.reset({
          fullName: '',
          phone: '',
          phoneCountry: 'BA',
        });
      }
    }
  }, [user, open, form]);

  const onSubmit = async (data: StaffKioskUserFormData) => {
    const result = isEditMode
      ? await updateStaffKioskUser(businessId, user.id, data)
      : await createStaffKioskUser(businessId, data);
    
    if (result.success) {
      toast({ title: `User ${isEditMode ? 'updated' : 'created'} successfully!` });
      onSave();
      setOpen(false);
    } else {
      const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
      toast({ variant: 'destructive', title: `Error ${isEditMode ? 'updating' : 'creating'} user`, description: errorMessage });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit' : 'Add'} Staff Screen User</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="phoneCountry"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number Region</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a region" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="BA">Bosnia (+387)</SelectItem>
                      <SelectItem value="DK">Denmark (+45)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <PhoneInput {...field} allowedCountries={[form.watch('phoneCountry')]} defaultCountry={form.watch('phoneCountry')} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="pt-4">
              <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isEditMode ? 'Save Changes' : 'Create User & Send PIN'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

export function StaffAppSettingsForm({ business }: { business: Business }) {
  const { toast } = useToast();
  const router = useRouter();
  const [kioskUsers, setKioskUsers] = React.useState<StaffKioskUser[]>([]);

  const form = useForm<Pick<BusinessFormData, 'staffAppSettings'>>({
    defaultValues: {
       staffAppSettings: business.staffAppSettings ?? {
            autoCompleteBookings: false,
            autoStartBookings: false,
       },
    },
  });
  
  React.useEffect(() => {
    if (business) {
        form.reset({
            staffAppSettings: business.staffAppSettings ?? {
                autoCompleteBookings: false,
                autoStartBookings: false,
            },
        });
        setKioskUsers(business.staffKioskUsers ? Object.entries(business.staffKioskUsers).map(([id, user]) => ({ id, ...(user as StaffKioskUser) })) : []);
    }
  }, [business, form]);
  
  const refreshUsers = () => {
    router.refresh();
  }

  const handleDeleteUser = async (userId: string) => {
    const result = await deleteStaffKioskUser(business.id, userId);
    if (result.success) {
      toast({ title: 'User deleted successfully!' });
      refreshUsers();
    } else {
      toast({ variant: 'destructive', title: 'Error', description: result.error });
    }
  }

  const handleResetPin = async (userId: string, fullName: string) => {
    const result = await resetStaffKioskUserPin(business.id, userId);
    if (result.success) {
        toast({ title: `PIN Reset for ${fullName}`, description: `A new PIN has been generated and sent.` });
        refreshUsers();
    } else {
         toast({ variant: 'destructive', title: 'Error', description: result.error });
    }
  }

  return (
    <div id="kiosk-settings" className="space-y-4 scroll-mt-20">
      <Card>
          <CardHeader>
              <CardTitle>Staff App Users</CardTitle>
              <CardDescription>Manage users who can log in to the staff screen.</CardDescription>
          </CardHeader>
          <CardContent>
            {kioskUsers.length > 0 ? (
               <div className="space-y-2">
                {kioskUsers.map(user => (
                  <div key={user.id} className="flex items-center justify-between p-2 border rounded-md">
                    <div className="flex items-center gap-4">
                        <div>
                            <p className="font-medium">{user.fullName}</p>
                            <p className="text-sm text-muted-foreground">{user.phone}</p>
                        </div>
                    </div>
                    <div className="flex items-center">
                       <KioskUserFormDialog businessId={business.id} user={user} onSave={refreshUsers}>
                          <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
                       </KioskUserFormDialog>
                       <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon"><RefreshCw className="h-4 w-4"/></Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Reset PIN for {user.fullName}?</AlertDialogTitle>
                              <AlertDialogDescription>This will generate a new 4-digit PIN and send it to them via SMS. Their old PIN will no longer work.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleResetPin(user.id, user.fullName)}>Reset & Send</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                       </AlertDialog>
                       <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon"><Trash2 className="h-4 w-4 text-destructive"/></Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete {user.fullName}?</AlertDialogTitle>
                              <AlertDialogDescription>This will revoke their access to the staff screen. This action cannot be undone.</AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteUser(user.id)}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                       </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">No staff screen users created yet.</p>
            )}
          </CardContent>
          <CardFooter>
            <KioskUserFormDialog businessId={business.id} onSave={refreshUsers}>
                <Button variant="outline"><PlusCircle className="mr-2 h-4 w-4" /> Add User</Button>
            </KioskUserFormDialog>
          </CardFooter>
      </Card>
      
    </div>
  );
}

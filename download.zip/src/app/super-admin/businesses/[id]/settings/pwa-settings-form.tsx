
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { updateBusiness } from '../../new/actions';
import { type BusinessFormData, businessSchema } from '../../new/schema';
import type { Business } from '../../actions';
import { Switch } from '@/components/ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';


const pwaSettingsSchema = businessSchema.pick({
    enablePwa: true,
    pwaShortName: true,
    pwaThemeColor: true,
    pwaBackgroundColor: true,
    pwaIcon192: true,
    pwaIcon512: true,
    pwaMaskableIcon: true,
});

type PwaSettingsFormData = z.infer<typeof pwaSettingsSchema>;

interface PwaSettingsFormProps {
  business: Business;
  onSave: () => void;
}

export function PwaSettingsForm({ business, onSave }: PwaSettingsFormProps) {
  const { toast } = useToast();

  const form = useForm<PwaSettingsFormData>({
    resolver: zodResolver(pwaSettingsSchema),
    defaultValues: {},
  });

  React.useEffect(() => {
    if (business) {
        form.reset({
          enablePwa: business.enablePwa ?? false,
          pwaShortName: business.pwaShortName ?? '',
          pwaThemeColor: business.pwaThemeColor ?? '#000000',
          pwaBackgroundColor: business.pwaBackgroundColor ?? '#FFFFFF',
        });
    }
  }, [business, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: PwaSettingsFormData) => {
    const formData = new FormData();
    const { pwaIcon192, pwaIcon512, pwaMaskableIcon, ...jsonData } = data;
    formData.append('jsonData', JSON.stringify(jsonData));
    
    if (pwaIcon192 instanceof File) formData.append('pwaIcon192', pwaIcon192);
    if (pwaIcon512 instanceof File) formData.append('pwaIcon512', pwaIcon512);
    if (pwaMaskableIcon instanceof File) formData.append('pwaMaskableIcon', pwaMaskableIcon);
    
    const result = await updateBusiness(business.id, formData);

    if (result.success) {
      toast({ title: "Settings updated successfully", description: "PWA settings have been saved." });
      onSave();
    } else {
      toast({ variant: "destructive", title: "Error updating settings", description: "Could not save settings." });
    }
  };

  const watchEnablePwa = form.watch('enablePwa');

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl">
            <Card>
                <CardHeader>
                    <CardTitle>PWA (Progressive Web App) Settings</CardTitle>
                    <CardDescription>Allow customers and staff to install the app on their devices.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <FormField
                        control={form.control}
                        name="enablePwa"
                        render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                    <FormLabel className="text-base">Enable Installable App</FormLabel>
                                    <FormDescription>
                                        Allow both the customer booking page and the staff screen to be installed as an app.
                                    </FormDescription>
                                </div>
                                <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                </FormControl>
                            </FormItem>
                        )}
                    />
                    {watchEnablePwa && (
                        <div className="space-y-6 pt-4 border-t">
                            <FormField
                                control={form.control}
                                name="pwaShortName"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>App Short Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g., RoyalCut" {...field} value={field.value ?? ''} />
                                        </FormControl>
                                        <FormDescription>A short name for the app icon label (max 20 characters).</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <div className="grid md:grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="pwaThemeColor"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Theme Color</FormLabel>
                                        <div className="flex items-center gap-2">
                                           <Popover>
                                            <PopoverTrigger asChild>
                                                <Button type="button" variant="outline" className="h-10 w-10 p-0 border-2" style={{ backgroundColor: field.value ?? '#000000' }} />
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0">
                                               <Input type="color" className="h-12 w-14 p-1" {...field} value={field.value ?? '#000000'} />
                                            </PopoverContent>
                                          </Popover>
                                          <FormControl>
                                           <Input {...field} placeholder="#000000" value={field.value ?? ''} />
                                         </FormControl>
                                        </div>
                                        <FormDescription>Controls the color of the toolbar.</FormDescription>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={form.control}
                                    name="pwaBackgroundColor"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Background Color</FormLabel>
                                         <div className="flex items-center gap-2">
                                           <Popover>
                                            <PopoverTrigger asChild>
                                                <Button type="button" variant="outline" className="h-10 w-10 p-0 border-2" style={{ backgroundColor: field.value ?? '#FFFFFF' }} />
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0">
                                               <Input type="color" className="h-12 w-14 p-1" {...field} value={field.value ?? '#FFFFFF'} />
                                            </PopoverContent>
                                          </Popover>
                                          <FormControl>
                                           <Input {...field} placeholder="#FFFFFF" value={field.value ?? ''} />
                                         </FormControl>
                                        </div>
                                        <FormDescription>Used for the splash screen background.</FormDescription>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                            </div>
                             <div className="grid md:grid-cols-3 gap-4">
                                <FormField
                                    control={form.control}
                                    name="pwaIcon192"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Icon (192x192)</FormLabel>
                                            <FormControl><Input type="file" accept="image/png" onChange={(e) => field.onChange(e.target.files?.[0])} /></FormControl>
                                            <FormDescription>A 192x192px PNG icon.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                 <FormField
                                    control={form.control}
                                    name="pwaIcon512"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Icon (512x512)</FormLabel>
                                            <FormControl><Input type="file" accept="image/png" onChange={(e) => field.onChange(e.target.files?.[0])} /></FormControl>
                                             <FormDescription>A 512x512px PNG icon.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                 <FormField
                                    control={form.control}
                                    name="pwaMaskableIcon"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Maskable Icon</FormLabel>
                                            <FormControl><Input type="file" accept="image/png" onChange={(e) => field.onChange(e.target.files?.[0])} /></FormControl>
                                            <FormDescription>A 512x512px icon with safe zones.</FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
          <div className="flex justify-end gap-2">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save PWA Settings
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

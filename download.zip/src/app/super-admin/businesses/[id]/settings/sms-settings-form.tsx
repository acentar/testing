
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2, MessageSquare, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { updateBusiness, sendTestSms } from '../../new/actions';
import { type BusinessFormData, businessSchema } from '../../new/schema';
import type { Business } from '../../actions';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PhoneInput } from '@/components/phone-input';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const smsSettingsSchema = businessSchema.pick({
    enableSms: true,
    allowedPhoneCountries: true,
    smsProvider: true,
    textbeeDeviceId: true,
    vonageApiKey: true,
    vonageApiSecret: true,
    smsLanguage: true,
    smsVerificationTemplate: true,
    smsConfirmationTemplate: true,
    smsReminderTemplate: true,
    smsRescheduleTemplate: true,
    smsCancellationTemplate: true,
    smsYourTurnSoonTemplate: true,
    smsStaffLoginTemplate: true,
    enableNewBookingSmsNotification: true,
    newBookingSmsRecipient: true,
    smsNewBookingTemplate: true,
});

type SmsSettingsFormData = z.infer<typeof smsSettingsSchema>;

interface SmsSettingsFormProps {
  business: Business;
  onSave: () => void;
}

export function SmsSettingsForm({ business, onSave }: SmsSettingsFormProps) {
  const { toast } = useToast();
  const [testNumber, setTestNumber] = React.useState('');
  const [isSendingTest, setIsSendingTest] = React.useState(false);

  const form = useForm<SmsSettingsFormData>({
    resolver: zodResolver(smsSettingsSchema),
    defaultValues: {},
  });

  React.useEffect(() => {
    if (business) {
        form.reset({
          enableSms: business.enableSms ?? false,
          allowedPhoneCountries: business.allowedPhoneCountries ?? [],
          smsProvider: business.smsProvider ?? 'vonage',
          textbeeDeviceId: business.textbeeDeviceId ?? '',
          vonageApiKey: business.vonageApiKey ?? '',
          vonageApiSecret: business.vonageApiSecret ?? '',
          smsLanguage: business.smsLanguage ?? 'bs',
          smsVerificationTemplate: business.smsVerificationTemplate ?? { en: '', bs: '', da: '' },
          smsConfirmationTemplate: business.smsConfirmationTemplate ?? { en: '', bs: '', da: '' },
          smsReminderTemplate: business.smsReminderTemplate ?? { en: '', bs: '', da: '' },
          smsRescheduleTemplate: business.smsRescheduleTemplate ?? { en: '', bs: '', da: '' },
          smsCancellationTemplate: business.smsCancellationTemplate ?? { en: '', bs: '', da: '' },
          smsYourTurnSoonTemplate: business.smsYourTurnSoonTemplate ?? { en: '', bs: '', da: '' },
          smsStaffLoginTemplate: business.smsStaffLoginTemplate ?? { en: '', bs: '', da: '' },
          enableNewBookingSmsNotification: business.enableNewBookingSmsNotification ?? false,
          newBookingSmsRecipient: business.newBookingSmsRecipient ?? '',
          smsNewBookingTemplate: business.smsNewBookingTemplate ?? { en: '', bs: '', da: '' },
        });
    }
  }, [business, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: SmsSettingsFormData) => {
    const formData = new FormData();
    formData.append('jsonData', JSON.stringify(data));
    
    const result = await updateBusiness(business.id, formData);

    if (result.success) {
      toast({ title: "Settings updated successfully", description: "SMS settings have been saved." });
      onSave();
    } else {
      toast({ variant: "destructive", title: "Error updating settings", description: "Could not save settings." });
    }
  };

  const handleSendTestSms = async () => {
    if (!testNumber) {
      toast({ variant: 'destructive', title: 'Phone number required', description: 'Please enter a phone number to send a test to.' });
      return;
    }
    setIsSendingTest(true);
    const result = await sendTestSms(business.id, testNumber);
    if (result.success) {
      toast({ title: 'Test SMS Sent!', description: `A test message has been sent to ${testNumber}.` });
    } else {
      toast({ variant: 'destructive', title: 'Failed to Send Test SMS', description: result.error });
    }
    setIsSendingTest(false);
  }

  const watchEnableSms = form.watch('enableSms');
  const watchSmsProvider = form.watch('smsProvider');

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl">
            <Card>
                <CardHeader>
                    <CardTitle>SMS Settings</CardTitle>
                    <CardDescription>Enable and configure SMS notifications for customers and staff.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <FormField
                        control={form.control}
                        name="enableSms"
                        render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                    <FormLabel className="text-base">Enable SMS</FormLabel>
                                    <FormDescription>
                                        Globally enable or disable sending SMS for this business.
                                    </FormDescription>
                                </div>
                                <FormControl>
                                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                                </FormControl>
                            </FormItem>
                        )}
                    />
                    {watchEnableSms && (
                        <>
                            <div className="pt-4 space-y-4 border-t">
                                <FormField
                                    control={form.control}
                                    name="smsProvider"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Provider</FormLabel>
                                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                <FormControl>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="vonage">Vonage</SelectItem>
                                                    <SelectItem value="textbee">TextBee</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {watchSmsProvider === 'vonage' ? (
                                    <>
                                        <FormField control={form.control} name="vonageApiKey" render={({ field }) => (<FormItem><FormLabel>Vonage API Key</FormLabel><FormControl><Input {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)} />
                                        <FormField control={form.control} name="vonageApiSecret" render={({ field }) => (<FormItem><FormLabel>Vonage API Secret</FormLabel><FormControl><Input type="password" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)} />
                                    </>
                                ) : (
                                    <Alert>
                                        <MessageSquare className="h-4 w-4" />
                                        <AlertTitle>TextBee Configuration</AlertTitle>
                                        <AlertDescription>
                                            TextBee devices are configured in the global platform settings. You can assign a specific device for this business here, or it will use the default.
                                        </AlertDescription>
                                    </Alert>
                                )}
                            </div>
                        </>
                    )}
                </CardContent>
                <CardFooter className="flex-col items-start gap-4">
                     <div className="flex items-end gap-2 w-full max-w-sm">
                        <div className="flex-1">
                            <Label>Send test SMS</Label>
                            <PhoneInput value={testNumber} onChange={setTestNumber} allowedCountries={['DK', 'BA']} />
                        </div>
                        <Button type="button" variant="secondary" onClick={handleSendTestSms} disabled={isSendingTest}>
                            {isSendingTest ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <MessageSquare className="mr-2 h-4 w-4"/>}
                            Send
                        </Button>
                    </div>
                </CardFooter>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>SMS Templates</CardTitle>
                    <CardDescription>Customize the content for automated SMS messages. Use placeholders like `{'{{businessName}}'}` or `{'{{customerName}}'}`.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Tabs defaultValue="bs" className="w-full">
                        <TabsList>
                            <TabsTrigger value="bs">Bosnian</TabsTrigger>
                            <TabsTrigger value="da">Danish</TabsTrigger>
                            <TabsTrigger value="en">English</TabsTrigger>
                        </TabsList>
                        <TabsContent value="bs" className="space-y-4 pt-4">
                            <FormField control={form.control} name="smsConfirmationTemplate.bs" render={({field}) => <FormItem><FormLabel>Booking Confirmation</FormLabel><FormControl><Textarea {...field} value={field.value?.bs || ''}/></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsRescheduleTemplate.bs" render={({field}) => <FormItem><FormLabel>Booking Rescheduled</FormLabel><FormControl><Textarea {...field} value={field.value?.bs || ''} /></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsCancellationTemplate.bs" render={({field}) => <FormItem><FormLabel>Booking Cancelled</FormLabel><FormControl><Textarea {...field} value={field.value?.bs || ''} /></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsYourTurnSoonTemplate.bs" render={({field}) => <FormItem><FormLabel>"Your Turn Soon" (Kiosk)</FormLabel><FormControl><Textarea {...field} value={field.value?.bs || ''} /></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsNewBookingTemplate.bs" render={({field}) => <FormItem><FormLabel>New Booking Alert (Owner)</FormLabel><FormControl><Textarea {...field} value={field.value?.bs || ''} /></FormControl><FormMessage/></FormItem>}/>
                        </TabsContent>
                         <TabsContent value="da" className="space-y-4 pt-4">
                            <FormField control={form.control} name="smsConfirmationTemplate.da" render={({field}) => <FormItem><FormLabel>Booking Confirmation</FormLabel><FormControl><Textarea {...field} value={field.value?.da || ''} /></FormControl><FormMessage/></FormItem>}/>
                            <FormField control={form.control} name="smsRescheduleTemplate.da" render={({field}) => <FormItem><FormLabel>Booking Rescheduled</FormLabel><FormControl><Textarea {...field} value={field.value?.da || ''} /></FormControl><FormMessage/></FormItem>}/>
                            <FormField control={form.control} name="smsCancellationTemplate.da" render={({field}) => <FormItem><FormLabel>Booking Cancelled</FormLabel><FormControl><Textarea {...field} value={field.value?.da || ''} /></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsYourTurnSoonTemplate.da" render={({field}) => <FormItem><FormLabel>"Your Turn Soon" (Kiosk)</FormLabel><FormControl><Textarea {...field} value={field.value?.da || ''} /></FormControl><FormMessage/></FormItem>}/>
                              <FormField control={form.control} name="smsNewBookingTemplate.da" render={({field}) => <FormItem><FormLabel>New Booking Alert (Owner)</FormLabel><FormControl><Textarea {...field} value={field.value?.da || ''} /></FormControl><FormMessage/></FormItem>}/>
                        </TabsContent>
                         <TabsContent value="en" className="space-y-4 pt-4">
                            <FormField control={form.control} name="smsConfirmationTemplate.en" render={({field}) => <FormItem><FormLabel>Booking Confirmation</FormLabel><FormControl><Textarea {...field} value={field.value?.en || ''} /></FormControl><FormMessage/></FormItem>}/>
                            <FormField control={form.control} name="smsRescheduleTemplate.en" render={({field}) => <FormItem><FormLabel>Booking Rescheduled</FormLabel><FormControl><Textarea {...field} value={field.value?.en || ''} /></FormControl><FormMessage/></FormItem>}/>
                            <FormField control={form.control} name="smsCancellationTemplate.en" render={({field}) => <FormItem><FormLabel>Booking Cancelled</FormLabel><FormControl><Textarea {...field} value={field.value?.en || ''} /></FormControl><FormMessage/></FormItem>}/>
                             <FormField control={form.control} name="smsYourTurnSoonTemplate.en" render={({field}) => <FormItem><FormLabel>"Your Turn Soon" (Kiosk)</FormLabel><FormControl><Textarea {...field} value={field.value?.en || ''} /></FormControl><FormMessage/></FormItem>}/>
                              <FormField control={form.control} name="smsNewBookingTemplate.en" render={({field}) => <FormItem><FormLabel>New Booking Alert (Owner)</FormLabel><FormControl><Textarea {...field} value={field.value?.en || ''} /></FormControl><FormMessage/></FormItem>}/>
                        </TabsContent>
                    </Tabs>
                </CardContent>
            </Card>
          <div className="flex justify-end gap-2">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save SMS Settings
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

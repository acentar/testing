
'use client';

import * as React from 'react';
import { notFound } from "next/navigation";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Smartphone, Globe, Settings as SettingsIcon, MessageSquare, Fingerprint } from 'lucide-react';
import { GeneralSettingsForm } from './general-settings-form';
import { ClientAppSettingsForm } from './client-app-settings-form';
import { StaffAppSettingsForm } from './staff-app-settings-form';
import { PwaSettingsForm } from './pwa-settings-form';
import { SmsSettingsForm } from './sms-settings-form';
import { useStaffScreen } from '@/app/[id]/staff-app/staff-screen-context';

export default function SettingsPage() {
    const { business, refreshData } = useStaffScreen();
    
    if (!business) {
        return notFound();
    }
  
  return (
    <div className="space-y-8">
       <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
          <p className="text-muted-foreground">
            Manage all settings for this business.
          </p>
        </div>
      </div>
      <Tabs defaultValue="general" className="w-full md:grid md:grid-cols-[180px_1fr] md:gap-6" orientation="vertical">
        <TabsList className="w-full md:w-auto h-auto bg-transparent p-0 flex-col items-start space-y-1">
            <TabsTrigger value="general" className="w-full justify-start data-[state=active]:bg-muted"><SettingsIcon className="mr-2 h-4 w-4"/>General</TabsTrigger>
            <TabsTrigger value="client-app" className="w-full justify-start data-[state=active]:bg-muted"><Globe className="mr-2 h-4 w-4"/>Client App</TabsTrigger>
            <TabsTrigger value="sms" className="w-full justify-start data-[state=active]:bg-muted"><MessageSquare className="mr-2 h-4 w-4"/>SMS</TabsTrigger>
            <TabsTrigger value="staff-app" className="w-full justify-start data-[state=active]:bg-muted"><Fingerprint className="mr-2 h-4 w-4"/>Staff App</TabsTrigger>
            <TabsTrigger value="pwa" className="w-full justify-start data-[state=active]:bg-muted"><Smartphone className="mr-2 h-4 w-4"/>PWA</TabsTrigger>
        </TabsList>
        <div className="mt-6 md:mt-0">
            <TabsContent value="general" className="pt-0 mt-0">
                <GeneralSettingsForm business={business} onSave={refreshData}/>
            </TabsContent>
            <TabsContent value="client-app" className="pt-0 mt-0">
                <ClientAppSettingsForm business={business} onSave={refreshData} />
            </TabsContent>
            <TabsContent value="sms" className="pt-0 mt-0">
                <SmsSettingsForm business={business} onSave={refreshData} />
            </TabsContent>
            <TabsContent value="staff-app" className="pt-0 mt-0">
                <StaffAppSettingsForm business={business} />
            </TabsContent>
            <TabsContent value="pwa" className="pt-0 mt-0">
                <PwaSettingsForm business={business} onSave={refreshData} />
            </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

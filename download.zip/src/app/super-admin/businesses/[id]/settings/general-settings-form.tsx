
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { updateBusiness } from '../../new/actions';
import { type BusinessFormData, businessSchema } from '../../new/schema';
import type { Business } from '../../actions';
import { ImageCropper } from '@/components/image-cropper';
import { Checkbox } from '@/components/ui/checkbox';
import Image from 'next/image';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const generalSettingsSchema = businessSchema.pick({
    businessName: true,
    businessEmail: true,
    businessPhone: true,
    logo: true,
    logoToRemove: true,
    address: true,
    operatingHours: true,
    timezone: true,
    language: true,
    currency: true,
    theme: true,
    slug: true,
});

type GeneralSettingsFormData = BusinessFormData;

interface GeneralSettingsFormProps {
  business: Business;
  onSave: () => void;
}

const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];


export function GeneralSettingsForm({ business, onSave }: GeneralSettingsFormProps) {
  const { toast } = useToast();

  const form = useForm<GeneralSettingsFormData>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      operatingHours: daysOfWeek.map(day => ({
          day,
          working: true,
          from: '09:00',
          to: '17:00',
        })),
    },
  });

  React.useEffect(() => {
    if (business) {
      form.reset({
        businessName: business.businessName,
        businessEmail: business.businessEmail,
        businessPhone: business.businessPhone,
        address: business.address,
        operatingHours: business.operatingHours ?? daysOfWeek.map(day => ({
          day,
          working: true,
          from: '09:00',
          to: '17:00',
        })),
        timezone: business.timezone,
        language: business.language,
        currency: business.currency,
        theme: business.theme,
        slug: business.slug,
        logoToRemove: false,
      });
    }
  }, [business, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: GeneralSettingsFormData) => {
    const formData = new FormData();
    const { logo, ...jsonData } = data;
    formData.append('jsonData', JSON.stringify(jsonData));
    
    if (logo instanceof File) {
        formData.append('logo', logo);
    }
    
    const result = await updateBusiness(business.id, formData);

    if (result.success) {
      toast({ title: "Settings updated successfully", description: "General business settings have been saved." });
      onSave();
    } else {
      toast({ variant: "destructive", title: "Error updating settings", description: "Could not save settings." });
    }
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl">
            <Card>
                <CardHeader>
                    <CardTitle>General Information</CardTitle>
                    <CardDescription>Update your business's public details.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <FormField
                        control={form.control}
                        name="businessName"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Business Name</FormLabel>
                                <FormControl><Input placeholder="e.g., The Royal Cut" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={form.control} name="businessEmail" render={({ field }) => (<FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="contact@royalcut.com" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)}/>
                        <FormField control={form.control} name="businessPhone" render={({ field }) => (<FormItem><FormLabel>Phone</FormLabel><FormControl><Input type="tel" placeholder="+1234567890" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)}/>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Branding</CardTitle>
                </CardHeader>
                 <CardContent className="space-y-4">
                     <FormField
                        control={form.control}
                        name="logo"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Business Logo</FormLabel>
                                {business.logoUrl && !form.watch('logoToRemove') && (
                                    <div className="my-2 relative h-20">
                                        <Image src={business.logoUrl} alt="Current Logo" fill className="object-contain rounded-md border p-2" unoptimized/>
                                    </div>
                                )}
                                <ImageCropper aspectRatio={16/9} onFileChange={(file) => field.onChange(file)} />
                                {business.logoUrl && (
                                    <FormField
                                        control={form.control}
                                        name="logoToRemove"
                                        render={({ field: removeField }) => (
                                            <FormItem className="flex items-center gap-2 pt-2">
                                                <FormControl>
                                                    <Checkbox checked={removeField.value} onCheckedChange={removeField.onChange} id="remove-logo" />
                                                </FormControl>
                                                <Label htmlFor="remove-logo" className="flex items-center gap-1 cursor-pointer"><Trash2 className="h-4 w-4"/> Remove Current Logo</Label>
                                            </FormItem>
                                        )}
                                    />
                                )}
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </CardContent>
            </Card>
            
          <div className="flex justify-end gap-2">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

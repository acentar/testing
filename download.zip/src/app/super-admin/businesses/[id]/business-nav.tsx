
'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarSeparator, SidebarFooter } from '@/components/ui/sidebar';
import type { Business } from '../actions';
import Image from 'next/image';
import { LayoutDashboard, Users, Scissors, Settings, ArrowLeft, ExternalLink, Smartphone } from 'lucide-react';

interface BusinessNavProps extends React.HTMLAttributes<HTMLElement> {
    business: Business;
}

export function BusinessNav({ className, business, ...props }: BusinessNavProps) {
  const pathname = usePathname();
  const businessId = business.id;

  const businessRoutes = [
    { href: `/super-admin/businesses/${businessId}/dashboard`, label: 'Dashboard', icon: <LayoutDashboard /> },
    { href: `/super-admin/businesses/${businessId}/staff`, label: 'Staff', icon: <Users /> },
    { href: `/super-admin/businesses/${businessId}/services`, label: 'Services', icon: <Scissors /> },
    { href: `/super-admin/businesses/${businessId}/settings`, label: 'Settings', icon: <Settings /> },
  ];

  return (
    <>
      <div className="flex items-center justify-between p-4 border-b">
         <div className="flex items-center gap-3 min-w-0">
            {business.logoUrl ? (
                <div className="relative h-10 w-10 rounded-md overflow-hidden border">
                    <Image 
                        src={business.logoUrl} 
                        alt={`${business.businessName} logo`}
                        fill
                        className="object-contain"
                        unoptimized
                    />
                </div>
            ) : null}
           <div className="min-w-0">
            <p className="font-semibold truncate">{business.businessName}</p>
            <p className="text-xs text-muted-foreground">Editing business</p>
           </div>
        </div>
      </div>
        <SidebarMenu>
            <SidebarMenuItem>
                 <SidebarMenuButton asChild>
                    <Link href="/super-admin/businesses">
                        <ArrowLeft />
                        Back to Businesses
                    </Link>
                </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarSeparator />
            {businessRoutes.map((route) => (
                <SidebarMenuItem key={route.href}>
                    <SidebarMenuButton 
                        asChild 
                        isActive={pathname.startsWith(route.href)}
                    >
                        <Link href={route.href}>
                            {route.icon}
                            {route.label}
                        </Link>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            ))}
        </SidebarMenu>
        <SidebarFooter>
            <SidebarSeparator />
             <SidebarMenu>
                <SidebarMenuItem>
                    <SidebarMenuButton asChild variant="outline">
                        <a href={`/${business.slug || business.id}/client-app`} target="_blank" rel="noopener noreferrer">
                            <ExternalLink />
                            View Client App
                        </a>
                    </SidebarMenuButton>
                </SidebarMenuItem>
                 <SidebarMenuItem>
                    <SidebarMenuButton asChild variant="outline">
                        <a href={`/${business.id}/staff-app`} target="_blank" rel="noopener noreferrer">
                             <ExternalLink />
                            View Staff App
                        </a>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            </SidebarMenu>
        </SidebarFooter>
    </>
  );
}

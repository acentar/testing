
import * as React from 'react';
import { getBusiness } from "../../actions";
import { notFound } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';


export default async function BusinessDashboardPage({ params }: { params: { id: string } }) {
  const { id } = params;
  const business = await getBusiness(id);

  if (!business) {
    notFound();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{business.businessName}</h2>
          <p className="text-muted-foreground">
            Welcome to the dashboard.
          </p>
        </div>
      </div>
       <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Coming Soon</CardTitle>
              <CardDescription>
                A detailed dashboard with analytics and insights is coming soon for this business.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>This page will contain specific metrics for {business.businessName}.</p>
            </CardContent>
          </Card>
        </TabsContent>
       </Tabs>
    </div>
  );
}

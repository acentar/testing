
import * as React from 'react';
import { getBusiness } from "../actions";
import { notFound } from "next/navigation";
import { Sidebar, SidebarContent, SidebarProvider } from '@/components/ui/sidebar';
import { BusinessNav } from './business-nav';

export default async function EditBusinessLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { id: string };
}) {
  const { id } = params;
  const business = await getBusiness(id);

  if (!business) {
    notFound();
  }
  
  return (
    <SidebarProvider>
      <div className="grid grid-cols-1 md:grid-cols-[16rem_1fr] gap-8 items-start">
        <Sidebar className="hidden md:block">
            <SidebarContent>
                <BusinessNav business={business} />
            </SidebarContent>
        </Sidebar>
        <div className="min-w-0 p-4 md:p-8">{children}</div>
      </div>
    </SidebarProvider>
  )
}

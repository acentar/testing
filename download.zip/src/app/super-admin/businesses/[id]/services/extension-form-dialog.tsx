
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { addExtension, updateExtension } from './actions';
import { serviceExtensionSchema, type Extension } from './schema';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Loader2 } from 'lucide-react';
import { z } from 'zod';

type ExtensionFormData = z.infer<typeof serviceExtensionSchema>;

interface ExtensionFormDialogProps {
  children: React.ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  businessId: string;
  extension?: Extension | null;
  onFinished: () => void;
}

export function ExtensionFormDialog({ children, open, onOpenChange, businessId, extension, onFinished }: ExtensionFormDialogProps) {
  const { toast } = useToast();
  const isEditMode = !!extension;

  const form = useForm<ExtensionFormData>({
    resolver: zodResolver(serviceExtensionSchema),
    defaultValues: { name: '', price: 0, duration: 0 },
  });

  React.useEffect(() => {
    if (open && extension) {
      form.reset({ name: extension.name, price: extension.price, duration: extension.duration });
    } else if (open) {
      form.reset({ name: '', price: 0, duration: 0 });
    }
  }, [open, extension, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: ExtensionFormData) => {
    const result = isEditMode
      ? await updateExtension(businessId, extension.id, data)
      : await addExtension(businessId, data);
    
    if (result.success) {
      toast({ title: `Extension ${isEditMode ? 'updated' : 'added'} successfully!` });
      onOpenChange(false);
      onFinished();
    } else {
      toast({ variant: "destructive", title: "Error", description: (result.errors as any)._root[0] });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit Extension' : 'Add New Extension'}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="name" render={({ field }) => (<FormItem><FormLabel>Extension Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)}/>
            <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="price" render={({ field }) => (<FormItem><FormLabel>Price</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)}/>
                <FormField control={form.control} name="duration" render={({ field }) => (<FormItem><FormLabel>Duration (minutes)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)}/>
            </div>
            <DialogFooter className="pt-4">
              <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isEditMode ? 'Save Changes' : 'Add Extension'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}


'use server';

import { z } from 'zod';
import { serviceCategorySchema, serviceExtensionSchema, serviceSchema } from './schema';
import admin from '@/lib/firebase-admin';
import { revalidatePath } from 'next/cache';

const db = admin.database();

// --- Service Category Actions ---

export async function addCategory(businessId: string, data: z.infer<typeof serviceCategorySchema>) {
    const validationResult = serviceCategorySchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        const categoriesRef = db.ref(`businesses/${businessId}/serviceCategories`);
        const snapshot = await categoriesRef.once('value');
        const count = snapshot.exists() ? snapshot.numChildren() : 0;
        
        const newCategoryRef = categoriesRef.push();
        await newCategoryRef.set({ ...validationResult.data, position: count });
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to add category.'] } };
    }
}

export async function updateCategory(businessId: string, categoryId: string, data: z.infer<typeof serviceCategorySchema>) {
     const validationResult = serviceCategorySchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const categoryRef = db.ref(`businesses/${businessId}/serviceCategories/${categoryId}`);
        await categoryRef.update(validationResult.data);
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update category.'] } };
    }
}

export async function deleteCategory(businessId: string, categoryId: string) {
    try {
        const categoryRef = db.ref(`businesses/${businessId}/serviceCategories/${categoryId}`);
        await categoryRef.remove();
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, error: 'Failed to delete category.' };
    }
}

export async function updateCategoryOrder(businessId: string, categories: { id: string; position: number }[]) {
  try {
    const updates: { [key: string]: any } = {};
    categories.forEach(cat => {
      updates[`businesses/${businessId}/serviceCategories/${cat.id}/position`] = cat.position;
    });
    await db.ref().update(updates);
    revalidatePath(`/super-admin/businesses/${businessId}/services`);
    return { success: true };
  } catch (error) {
    console.error("Error updating category order:", error);
    return { success: false, error: 'Failed to update order.' };
  }
}

// --- Service Actions ---

export async function addService(businessId: string, categoryId: string, data: z.infer<typeof serviceSchema>) {
    const validationResult = serviceSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        const servicesRef = db.ref(`businesses/${businessId}/serviceCategories/${categoryId}/services`);
        const newServiceRef = servicesRef.push();
        await newServiceRef.set(validationResult.data);
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true, serviceId: newServiceRef.key };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to add service.'] } };
    }
}

export async function updateService(businessId: string, categoryId: string, serviceId: string, data: z.infer<typeof serviceSchema>) {
    const validationResult = serviceSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        const serviceRef = db.ref(`businesses/${businessId}/serviceCategories/${categoryId}/services/${serviceId}`);
        await serviceRef.update(validationResult.data);
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update service.'] } };
    }
}

export async function deleteService(businessId: string, categoryId: string, serviceId: string) {
    try {
        const serviceRef = db.ref(`businesses/${businessId}/serviceCategories/${categoryId}/services/${serviceId}`);
        await serviceRef.remove();
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, error: 'Failed to delete service.' };
    }
}

// --- Service Extension Actions ---

export async function addExtension(businessId: string, data: z.infer<typeof serviceExtensionSchema>) {
    const validationResult = serviceExtensionSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const extensionsRef = db.ref(`businesses/${businessId}/serviceExtensions`);
        const newExtensionRef = extensionsRef.push();
        await newExtensionRef.set(validationResult.data);
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to add extension.'] } };
    }
}

export async function updateExtension(businessId: string, extensionId: string, data: z.infer<typeof serviceExtensionSchema>) {
    const validationResult = serviceExtensionSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const extensionRef = db.ref(`businesses/${businessId}/serviceExtensions/${extensionId}`);
        await extensionRef.update(validationResult.data);
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update extension.'] } };
    }
}

export async function deleteExtension(businessId: string, extensionId: string) {
    try {
        const extensionRef = db.ref(`businesses/${businessId}/serviceExtensions/${extensionId}`);
        await extensionRef.remove();
        revalidatePath(`/super-admin/businesses/${businessId}/services`);
        return { success: true };
    } catch (error) {
        return { success: false, error: 'Failed to delete extension.' };
    }
}


// --- Data Fetching ---

export async function getCategories(businessId: string) {
    try {
        const categoriesRef = db.ref(`businesses/${businessId}/serviceCategories`);
        const snapshot = await categoriesRef.orderByChild('position').once('value');
        if (!snapshot.exists()) {
            return [];
        }
        const categoriesData = snapshot.val();
        const categories = Object.keys(categoriesData).map(key => ({
            id: key,
            ...categoriesData[key],
            services: categoriesData[key].services 
                ? Object.keys(categoriesData[key].services).map(sKey => ({ id: sKey, ...categoriesData[key].services[sKey] }))
                : []
        }));
        return categories;
    } catch (error) {
        console.error("Error fetching categories:", error);
        return [];
    }
}

export async function getExtensions(businessId: string) {
    try {
        const extensionsRef = db.ref(`businesses/${businessId}/serviceExtensions`);
        const snapshot = await extensionsRef.orderByChild('name').once('value');
        if (!snapshot.exists()) {
            return [];
        }
        const extensionsData = snapshot.val();
        const extensions = Object.keys(extensionsData).map(key => ({
            id: key,
            ...extensionsData[key]
        }));
        return extensions;
    } catch (error) {
        console.error("Error fetching extensions:", error);
        return [];
    }
}


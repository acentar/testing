
import { z } from 'zod';

export const serviceExtensionSchema = z.object({
  name: z.string().min(1, 'Extension name is required.'),
  price: z.coerce.number().min(0, 'Price must be a positive number.'),
  duration: z.coerce.number().int().min(0, 'Duration must be a positive integer.'),
});

export const serviceSchema = z.object({
  name: z.string().min(1, 'Service name is required.'),
  description: z.string().optional(),
  price: z.coerce.number().min(0, 'Price must be a positive number.'),
  duration: z.coerce.number().int().min(0, 'Duration must be a positive integer.'),
  canBeBookedOnline: z.boolean().default(true),
  extensions: z.array(z.string()).optional(),
  assignedStaff: z.array(z.string()).optional(),
});

export const serviceCategorySchema = z.object({
    name: z.string().min(1, 'Category name is required.'),
    services: z.array(serviceSchema).optional(),
    position: z.number().optional(),
});

export type Service = z.infer<typeof serviceSchema> & { id: string };
export type Extension = z.infer<typeof serviceExtensionSchema> & { id: string };
export type Category = z.infer<typeof serviceCategorySchema> & { id: string };

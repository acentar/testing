
'use client';

import * as React from 'react';
import { MoreHorizontal, PlusCircle, Trash2, GripVertical, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Skeleton } from '@/components/ui/skeleton';
import { deleteCategory, deleteExtension, updateCategoryOrder, deleteService } from './actions';
import type { Category, Extension, Service } from './schema';
import { ServiceFormDialog } from './service-form-dialog';
import { CategoryFormDialog } from './category-form-dialog';
import { ExtensionFormDialog } from './extension-form-dialog';
import { useStaffScreen } from '@/app/[id]/staff-app/staff-screen-context';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { FormattedPrice } from '@/components/formatted-price';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const SortableCategoryRow = ({ category, onEdit, onDelete, onAddService }: { category: Category, onEdit: (category: Category) => void, onDelete: (category: Category) => void, onAddService: (categoryId: string) => void }) => {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: category.id });
    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };
    
    return (
        <div ref={setNodeRef} style={style} className="flex items-center border-b" {...attributes}>
            <Button variant="ghost" size="icon" {...listeners} className="cursor-grab">
                <GripVertical className="h-4 w-4" />
            </Button>
            <div className="flex-1 font-medium p-4">{category.name}</div>
            <div className="p-4 w-24 text-center">{(category.services || []).length}</div>
            <div className="p-4 w-32 text-right">
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button size="icon" variant="ghost"><MoreHorizontal className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(category)}>Edit Category</DropdownMenuItem>
                         <DropdownMenuItem onSelect={() => onAddService(category.id)}>Add Service</DropdownMenuItem>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-500">Delete Category</DropdownMenuItem>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This will permanently delete the category "{category.name}" and all its services.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => onDelete(category)}>Delete</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </div>
    )
}

export default function ServicesPage() {
    const { business, categories, allStaff, extensions, refreshData, loadingStaff } = useStaffScreen();
    const { toast } = useToast();

    const [selectedCategory, setSelectedCategory] = React.useState<Category | null>(null);
    const [selectedService, setSelectedService] = React.useState<Service | null>(null);
    const [selectedExtension, setSelectedExtension] = React.useState<Extension | null>(null);
    const [categoryFormOpen, setCategoryFormOpen] = React.useState(false);
    const [serviceFormOpen, setServiceFormOpen] = React.useState(false);
    const [extensionFormOpen, setExtensionFormOpen] = React.useState(false);
    const [serviceDialogCategoryId, setServiceDialogCategoryId] = React.useState<string>('');

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleCategoryEdit = (category: Category) => {
        setSelectedCategory(category);
        setCategoryFormOpen(true);
    }
    
    const handleCategoryDelete = async (category: Category) => {
        const result = await deleteCategory(business.id, category.id);
        if(result.success) {
            toast({ title: "Category deleted", description: `"${category.name}" has been removed.`});
            refreshData();
        } else {
            toast({ variant: "destructive", title: "Error", description: result.error });
        }
    }

    const handleAddService = (categoryId: string) => {
        setSelectedService(null);
        setServiceDialogCategoryId(categoryId);
        setServiceFormOpen(true);
    }

    const handleEditService = (service: Service, categoryId: string) => {
        setSelectedService(service);
        setServiceDialogCategoryId(categoryId);
        setServiceFormOpen(true);
    }

    const handleDeleteService = async (service: Service, categoryId: string) => {
        const result = await deleteService(business.id, categoryId, service.id);
        if(result.success) {
            toast({ title: "Service deleted" });
            refreshData();
        } else {
            toast({ variant: "destructive", title: "Error", description: result.error });
        }
    }

    const handleExtensionEdit = (extension: Extension) => {
        setSelectedExtension(extension);
        setExtensionFormOpen(true);
    }

    const handleExtensionDelete = async (extension: Extension) => {
        const result = await deleteExtension(business.id, extension.id);
        if(result.success) {
            toast({ title: "Extension deleted", description: `"${extension.name}" has been removed.`});
            refreshData();
        } else {
            toast({ variant: "destructive", title: "Error", description: result.error });
        }
    }

    const handleDragEnd = async (event: any) => {
        const { active, over } = event;

        if (active.id !== over.id) {
            const oldIndex = categories.findIndex(c => c.id === active.id);
            const newIndex = categories.findIndex(c => c.id === over.id);
            const newOrder = arrayMove(categories, oldIndex, newIndex);
            refreshData(); // Optimistic update
            await updateCategoryOrder(business.id, newOrder.map((c, index) => ({ id: c.id, position: index })));
        }
    };
    
    const onServiceFormFinished = () => {
        setServiceFormOpen(false);
        refreshData();
    }

    if (loadingStaff) {
        return (
            <div className="space-y-6">
                <Skeleton className="h-10 w-36" />
                <Skeleton className="h-48 w-full" />
                <Skeleton className="h-32 w-full" />
            </div>
        )
    }

  return (
    <div className="space-y-6">
        <div className="flex items-center justify-between">
            <div>
                <h2 className="text-3xl font-bold tracking-tight">Services</h2>
                <p className="text-muted-foreground">
                    Manage service categories, services, and add-on extensions for this business.
                </p>
            </div>
        </div>

        <Card>
            <CardHeader>
                <CardTitle>Service Menu</CardTitle>
            </CardHeader>
            <CardContent>
                <Accordion type="multiple" className="w-full" defaultValue={categories.map(c => c.id)}>
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                    <SortableContext items={categories.map(c => c.id)} strategy={verticalListSortingStrategy}>
                        {categories.map(category => (
                             <AccordionItem value={category.id} key={category.id}>
                                 <SortableCategoryRow
                                    category={category}
                                    onEdit={handleCategoryEdit}
                                    onDelete={handleCategoryDelete}
                                    onAddService={handleAddService}
                                />
                                <AccordionContent className="bg-muted/50">
                                    <div className="p-4 space-y-2">
                                    {category.services?.map(service => (
                                        <div key={service.id} className="flex justify-between items-center p-3 border rounded-md bg-background">
                                            <div>
                                                <p className="font-semibold">{service.name}</p>
                                                <p className="text-sm text-muted-foreground">{service.duration} min &middot; <FormattedPrice price={service.price} currency={business.currency || 'DKK'} /></p>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Button variant="ghost" size="icon" onClick={() => handleEditService(service, category.id)}><Edit className="h-4 w-4" /></Button>
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild>
                                                        <Button variant="ghost" size="icon"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                                    </AlertDialogTrigger>
                                                    <AlertDialogContent>
                                                        <AlertDialogHeader>
                                                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                                            <AlertDialogDescription>This will delete the service "{service.name}".</AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                            <AlertDialogAction onClick={() => handleDeleteService(service, category.id)}>Delete</AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            </div>
                                        </div>
                                    ))}
                                    {(!category.services || category.services.length === 0) && <p className="text-center text-sm text-muted-foreground py-4">No services in this category.</p>}
                                    </div>
                                </AccordionContent>
                             </AccordionItem>
                        ))}
                    </SortableContext>
                </DndContext>
                </Accordion>
                {categories.length === 0 && <p className="text-center text-sm text-muted-foreground py-8">No categories created yet.</p>}
            </CardContent>
        </Card>
        
        <CategoryFormDialog 
            open={categoryFormOpen} 
            onOpenChange={setCategoryFormOpen} 
            businessId={business.id}
            category={selectedCategory} 
            onFinished={() => { setSelectedCategory(null); refreshData(); }}
        >
             <Button><PlusCircle className="mr-2 h-4 w-4" /> Add Category</Button>
        </CategoryFormDialog>
        
        <ServiceFormDialog
            open={serviceFormOpen}
            onOpenChange={setServiceFormOpen}
            categoryId={serviceDialogCategoryId}
            service={selectedService!}
            allExtensions={extensions}
            allStaff={allStaff}
            onFinished={onServiceFormFinished}
        >
        </ServiceFormDialog>
        
        <Card>
            <CardHeader>
                <CardTitle>Service Extensions (Add-ons)</CardTitle>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Extension Name</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Duration</TableHead>
                            <TableHead><span className="sr-only">Actions</span></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {extensions.map(ext => (
                            <TableRow key={ext.id}>
                                <TableCell className="font-medium">{ext.name}</TableCell>
                                <TableCell><FormattedPrice price={ext.price} currency={business.currency || 'DKK'} /></TableCell>
                                <TableCell>{ext.duration} min</TableCell>
                                <TableCell className="text-right">
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild><Button size="icon" variant="ghost"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem onClick={() => handleExtensionEdit(ext)}>Edit</DropdownMenuItem>
                                            <AlertDialog>
                                                <AlertDialogTrigger asChild><DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-500">Delete</DropdownMenuItem></AlertDialogTrigger>
                                                <AlertDialogContent>
                                                    <AlertDialogHeader>
                                                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                                        <AlertDialogDescription>This will permanently delete the extension "{ext.name}".</AlertDialogDescription>
                                                    </AlertDialogHeader>
                                                    <AlertDialogFooter>
                                                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                        <AlertDialogAction onClick={() => handleExtensionDelete(ext)}>Delete</AlertDialogAction>
                                                    </AlertDialogFooter>
                                                </AlertDialogContent>
                                            </AlertDialog>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                        {extensions.length === 0 && <TableRow><TableCell colSpan={4} className="text-center h-24">No extensions created yet.</TableCell></TableRow>}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>

        <ExtensionFormDialog
            open={extensionFormOpen}
            onOpenChange={setExtensionFormOpen}
            businessId={business.id}
            extension={selectedExtension}
            onFinished={() => { setSelectedExtension(null); refreshData(); }}
        >
             <Button><PlusCircle className="mr-2 h-4 w-4" /> Add Extension</Button>
        </ExtensionFormDialog>
    </div>
  );
}

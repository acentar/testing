
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { addCategory, updateCategory } from './actions';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Loader2 } from 'lucide-react';

const categoryFormSchema = z.object({
  name: z.string().min(1, 'Category name is required.'),
});
type CategoryFormData = z.infer<typeof categoryFormSchema>;

interface CategoryFormDialogProps {
  children?: React.ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  businessId: string;
  category?: { id: string, name: string } | null;
  onFinished: () => void;
}

export function CategoryFormDialog({ children, open, onOpenChange, businessId, category, onFinished }: CategoryFormDialogProps) {
  const { toast } = useToast();
  const isEditMode = !!category;

  const form = useForm<CategoryFormData>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues: { name: '' },
  });

  React.useEffect(() => {
    if (open && category) {
      form.reset({ name: category.name });
    } else if (open) {
      form.reset({ name: '' });
    }
  }, [open, category, form]);

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: CategoryFormData) => {
    const result = isEditMode
      ? await updateCategory(businessId, category.id, data)
      : await addCategory(businessId, data);
    
    if (result.success) {
      toast({ title: `Category ${isEditMode ? 'updated' : 'added'} successfully!` });
      onOpenChange(false);
      onFinished();
    } else {
      toast({ variant: "destructive", title: "Error", description: (result.errors as any)._root[0] });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {children && <DialogTrigger asChild>{children}</DialogTrigger>}
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit Category' : 'Add New Category'}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="pt-4">
              <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isEditMode ? 'Save Changes' : 'Add Category'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

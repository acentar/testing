
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { type Service, serviceSchema, type Extension } from './schema';
import type { Staff } from '../staff/schema';
import { useToast } from '@/hooks/use-toast';
import { addService, updateService } from './actions';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useStaffScreen } from '@/app/[id]/staff-app/staff-screen-context';

interface ServiceFormDialogProps {
  children?: React.ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categoryId: string;
  service?: Service;
  allExtensions: Extension[];
  allStaff: Staff[];
  onFinished?: () => void;
}

export function ServiceFormDialog({ children, open, onOpenChange, categoryId, service, allExtensions, allStaff, onFinished }: ServiceFormDialogProps) {
    const { toast } = useToast();
    const { business, refreshData } = useStaffScreen();
    const isEditMode = !!service;

    const form = useForm<Service>({
        resolver: zodResolver(serviceSchema),
        defaultValues: {
            name: '',
            description: '',
            price: 0,
            duration: 30,
            canBeBookedOnline: true,
            extensions: [],
            assignedStaff: [],
        },
    });

    React.useEffect(() => {
        if(open) {
            form.reset(service || {
                name: '',
                description: '',
                price: 0,
                duration: 30,
                canBeBookedOnline: true,
                extensions: [],
                assignedStaff: [],
            });
        }
    }, [open, service, form]);

    const { isSubmitting, watch } = form;
    const canBeBookedOnline = watch('canBeBookedOnline');

    const onSubmit = async (data: Service) => {
        const result = isEditMode
            ? await updateService(business.id, categoryId, service.id, data)
            : await addService(business.id, categoryId, data);
        
        if (result.success) {
            toast({ title: `Service ${isEditMode ? 'updated' : 'added'} successfully!` });
            onOpenChange(false);
            refreshData();
            if (onFinished) onFinished();
        } else {
            toast({ variant: "destructive", title: "Error", description: (result as any).errors?._root?.[0] || 'Failed to save service.' });
        }
    };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
        {children && <DialogTrigger asChild>{children}</DialogTrigger>}
        <DialogContent className="sm:max-w-xl">
            <DialogHeader>
                <DialogTitle>{isEditMode ? 'Edit Service' : 'Add New Service'}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto p-1 pr-4">
                     <FormField control={form.control} name="name" render={({ field }) => (<FormItem><FormLabel>Service Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)}/>
                     <FormField control={form.control} name="description" render={({ field }) => (<FormItem><FormLabel>Description</FormLabel><FormControl><Textarea {...field} /></FormControl><FormMessage /></FormItem>)}/>
                    <div className="grid grid-cols-2 gap-4">
                        <FormField control={form.control} name="price" render={({ field }) => (<FormItem><FormLabel>Price</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)}/>
                        <FormField control={form.control} name="duration" render={({ field }) => (<FormItem><FormLabel>Duration (minutes)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)}/>
                    </div>
                     <FormField
                        control={form.control}
                        name="canBeBookedOnline"
                        render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                                <div className="space-y-0.5">
                                    <FormLabel>Bookable Online</FormLabel>
                                    <FormDescription>Can customers book this service themselves?</FormDescription>
                                </div>
                                <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                            </FormItem>
                        )}
                    />
                    {canBeBookedOnline && (
                        <>
                         <FormField
                            control={form.control}
                            name="assignedStaff"
                            render={() => (
                                <FormItem>
                                    <FormLabel>Assigned Staff</FormLabel>
                                    <FormDescription>Which staff members can perform this service?</FormDescription>
                                    <div className="max-h-40 overflow-y-auto rounded-md border p-4 space-y-2">
                                        {allStaff.map((staff) => (
                                            <FormField
                                                key={staff.id}
                                                control={form.control}
                                                name="assignedStaff"
                                                render={({ field }) => (
                                                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                                                        <FormControl>
                                                            <Checkbox
                                                                checked={field.value?.includes(staff.id)}
                                                                onCheckedChange={(checked) => {
                                                                    return checked
                                                                    ? field.onChange([...(field.value || []), staff.id])
                                                                    : field.onChange(field.value?.filter((value) => value !== staff.id))
                                                                }}
                                                            />
                                                        </FormControl>
                                                        <FormLabel className="font-normal">{staff.fullName}</FormLabel>
                                                    </FormItem>
                                                )}
                                            />
                                        ))}
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="extensions"
                            render={() => (
                                <FormItem>
                                    <FormLabel>Available Extensions</FormLabel>
                                    <FormDescription>Which add-ons can be selected with this service?</FormDescription>
                                    <div className="max-h-40 overflow-y-auto rounded-md border p-4 space-y-2">
                                        {allExtensions.map((ext) => (
                                             <FormField
                                                key={ext.id}
                                                control={form.control}
                                                name="extensions"
                                                render={({ field }) => (
                                                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                                                        <FormControl>
                                                            <Checkbox
                                                                checked={field.value?.includes(ext.id)}
                                                                onCheckedChange={(checked) => {
                                                                    return checked
                                                                    ? field.onChange([...(field.value || []), ext.id])
                                                                    : field.onChange(field.value?.filter((value) => value !== ext.id))
                                                                }}
                                                            />
                                                        </FormControl>
                                                        <FormLabel className="font-normal">{ext.name}</FormLabel>
                                                    </FormItem>
                                                )}
                                            />
                                        ))}
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        </>
                    )}
                    <DialogFooter className="pt-4">
                        <DialogClose asChild><Button type="button" variant="ghost">Cancel</Button></DialogClose>
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {isEditMode ? 'Save Changes' : 'Add Service'}
                        </Button>
                    </DialogFooter>
                </form>
            </Form>
        </DialogContent>
    </Dialog>
  );
}

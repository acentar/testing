
'use client';

import * as React from 'react';
import { MoreHorizontal, Trash2, Eye, Link as LinkIcon, Tablet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { getBusinesses, deleteBusiness, type Business } from './actions';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useToast } from '@/hooks/use-toast';
import { useSidebar } from '@/components/ui/sidebar';

interface BusinessesClientPageProps {
  initialBusinesses: Business[];
}

export function BusinessesClientPage({ initialBusinesses }: BusinessesClientPageProps) {
  const [businesses, setBusinesses] = React.useState<Business[]>(initialBusinesses);
  const [loading, setLoading] = React.useState(false);
  const { toast } = useToast();
  const { setOpen: setSidebarOpen } = useSidebar();

  const loadBusinesses = React.useCallback(async () => {
    setLoading(true);
    const fetchedBusinesses = await getBusinesses();
    setBusinesses(fetchedBusinesses);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    setBusinesses(initialBusinesses);
  }, [initialBusinesses]);

  const handleDelete = async (business: Business) => {
    const result = await deleteBusiness(business.id);
    if (result.success) {
      toast({
        title: "Business Deleted",
        description: `"${business.businessName}" has been permanently deleted.`
      });
      loadBusinesses();
    } else {
      toast({
        variant: "destructive",
        title: "Error Deleting Business",
        description: result.error || "An unexpected error occurred.",
      });
    }
  };

  const formatAddress = (address: Business['address']) => {
    if (!address || !address.city) return 'N/A';
    return `${address.city}${address.state ? `, ${address.state}`: ''}`;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Business accounts</CardTitle>
        <CardDescription>
          You can create, edit, or delete business accounts from here.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Total bookings</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                      Loading businesses...
                  </TableCell>
              </TableRow>
            ) : businesses.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  No businesses found.
                </TableCell>
              </TableRow>
            ) : (
              businesses.map((business) => (
                <TableRow key={business.id}>
                  <TableCell className="font-medium">
                    <Link href={`/super-admin/businesses/${business.id}/dashboard`} className="hover:underline">
                      {business.businessName}
                    </Link>
                  </TableCell>
                  <TableCell>
                    {business.slug ? <Badge variant="outline">/{business.slug}</Badge> : '-'}
                  </TableCell>
                  <TableCell>{formatAddress(business.address)}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        business.status === 'Active' ? 'default' :
                        business.status === 'Pending' ? 'secondary' : 'destructive'
                      }
                    >
                      {business.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{business.bookings}</TableCell>
                  <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                          <Button asChild variant="ghost" size="icon">
                              <Link href={`/${business.slug || business.id}/client-app`} target="_blank"><LinkIcon className="h-4 w-4" /></Link>
                          </Button>
                          <Button asChild variant="ghost" size="icon">
                              <Link href={`/${business.id}/staff-app`} target="_blank"><Tablet className="h-4 w-4" /></Link>
                          </Button>
                          <AlertDialog>
                              <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                  <Button
                                      aria-haspopup="true"
                                      size="icon"
                                      variant="ghost"
                                  >
                                      <MoreHorizontal className="h-4 w-4" />
                                      <span className="sr-only">Toggle menu</span>
                                  </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem asChild>
                                      <Link href={`/super-admin/businesses/${business.id}/dashboard`}>Edit</Link>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>Assign sub-admin</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <AlertDialogTrigger asChild>
                                      <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}>
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete
                                      </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  </DropdownMenuContent>
                              </DropdownMenu>
                              <AlertDialogContent>
                                      <AlertDialogHeader>
                                          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                          <AlertDialogDescription>
                                              This action cannot be undone. This will permanently delete the business "{business.businessName}" and all associated data, including bookings, staff, and services.
                                          </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                                          <AlertDialogAction onClick={() => handleDelete(business)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                                      </AlertDialogFooter>
                                  </AlertDialogContent>
                              </AlertDialog>
                      </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}


'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { createBusiness } from './actions';
import { createBusinessSchema } from './schema';
import { useRouter } from 'next/navigation';

type CreateBusinessFormData = z.infer<typeof createBusinessSchema>;

export default function NewBusinessPage() {
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<CreateBusinessFormData>({
    resolver: zodResolver(createBusinessSchema),
    defaultValues: {
      businessName: '',
    },
  });

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: CreateBusinessFormData) => {
    const result = await createBusiness(data);
    
    if (result?.errors) {
       if (result.errors) {
        Object.entries(result.errors).forEach(([key, value]) => {
           if (Array.isArray(value) && value.length > 0) {
            form.setError(key as keyof CreateBusinessFormData, {
              type: 'manual',
              message: value.join(', '),
            });
          }
        });
      }
      const errorMessage = result.errors?._root?.[0] || `Failed to create business.`;
       toast({
        variant: 'destructive',
        title: `Error creating business`,
        description: errorMessage,
      });
    }
  };

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Create a new business</h2>
          <p className="text-muted-foreground">
            Start by giving your new business a name. You can configure all other settings after creation.
          </p>
        </div>
      </div>
      <Card className="max-w-xl">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardHeader>
              <CardTitle>Business name</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Enter the name for the new business</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., The Royal Cut" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create & continue to settings
              </Button>
            </CardContent>
          </form>
        </Form>
      </Card>
    </div>
  );
}

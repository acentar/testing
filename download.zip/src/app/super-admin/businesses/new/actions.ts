
'use server';

import { z } from 'zod';
import { businessSchema, createBusinessSchema, BusinessFormData, staffKioskUserSchema, StaffKioskUserFormData, updateStaffKioskUserPinSchema } from './schema';
import admin from '@/lib/firebase-admin';
import { storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { getSmsClient, getGlobalSettings } from '../../settings/actions';
import sharp from 'sharp';
import bcrypt from 'bcryptjs';
import { getBusiness } from '../actions';

async function streamToBuffer(stream: ReadableStream<Uint8Array>): Promise<Buffer> {
    const reader = stream.getReader();
    const chunks: Uint8Array[] = [];
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}


async function handleFileUpload(file: File | null): Promise<string> {
    if (!file) return '';

    const fileBuffer = await streamToBuffer(file.stream());
    const fileName = file.name.split('.')[0];
    let processedBuffer: Buffer;
    let contentType: string;
    let extension: string;

    if (file.type === 'audio/wav') {
        processedBuffer = fileBuffer;
        contentType = 'audio/wav';
        extension = 'wav';
    } else if (file.type === 'image/svg+xml') {
        processedBuffer = fileBuffer;
        contentType = 'image/svg+xml';
        extension = 'svg';
    } else if (file.type === 'image/png') {
        processedBuffer = await sharp(fileBuffer).png({ quality: 80 }).toBuffer();
        contentType = 'image/png';
        extension = 'png';
    } else if (file.type === 'image/jpeg' || file.type === 'image/jpg') {
        processedBuffer = await sharp(fileBuffer).jpeg({ quality: 80 }).toBuffer();
        contentType = 'image/jpeg';
        extension = 'jpg';
    } else if (file.type === 'image/webp') {
        processedBuffer = await sharp(fileBuffer).webp({ quality: 80 }).toBuffer();
        contentType = 'image/webp';
        extension = 'webp';
    }
     else {
         processedBuffer = await sharp(fileBuffer).webp({ quality: 80 }).toBuffer();
        contentType = 'image/webp';
        extension = 'webp';
        
    }

    const filePath = `uploads/settings/${Date.now()}_${fileName}.${extension}`;
    const fileStorageRef = storageRef(storage, filePath);

    const uploadResult = await uploadBytes(fileStorageRef, processedBuffer, { contentType });
    return getDownloadURL(uploadResult.ref);
}

export async function sendTestSms(businessId: string, phoneNumber: string) {
    const business = await getBusiness(businessId);
    if (!business) {
        return { success: false, error: "Business not found." };
    }
    const smsClient = await getSmsClient(businessId);
    if (!smsClient) {
        return { success: false, error: "SMS client is not configured for this business." };
    }
    try {
        const globalSettings = await getGlobalSettings();
        const appName = globalSettings.general?.appName || 'QueuePilot';
        await smsClient.send({
            to: phoneNumber,
            from: business.businessName || appName,
            text: `This is a test message from your ${appName} setup. Your SMS integration is working correctly!`
        });
        return { success: true };
    } catch (error: any) {
        console.error("Error sending test SMS:", error);
        return { success: false, error: error.message || "Failed to send test SMS." };
    }
}

export async function createBusiness(businessData: Pick<BusinessFormData, 'businessName'>) {
  const validationResult = createBusinessSchema.safeParse(businessData);
  
  if (!validationResult.success) {
    const errors = validationResult.error.flatten().fieldErrors;
    return { success: false, errors };
  }

  try {
    const { businessName } = validationResult.data;
    const db = admin.database();

    const businessesRef = db.ref('businesses');
    const snapshot = await businessesRef.orderByChild('businessName').equalTo(businessName).once('value');
    if (snapshot.exists()) {
        return { success: false, errors: { businessName: ["A business with this name already exists."] } };
    }

    const newBusinessRef = businessesRef.push();

    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    await newBusinessRef.set({
      businessName,
      address: { street: '', city: '', state: '', postalCode: '', country: 'Denmark' },
      operatingHours: daysOfWeek.map(day => ({ day, working: true, from: '09:00', to: '17:00' })),
      description: '',
      enableSms: false,
      enableCalendar: true,
      theme: 'dark',
      language: 'bs',
      smsLanguage: 'bs',
      currency: 'DKK',
      logoUrl: '',
      slug: '',
      businessPictures: [],
      enableCustomDesign: false,
      primaryColor: '#64B5F6',
      backgroundColor: '#E3F2FD',
      allowedPhoneCountries: [],
      smsProvider: 'vonage',
      vonageApiKey: '',
      vonageApiSecret: '',
      smsVerificationTemplate: {
          en: 'Your verification code for {{businessName}} is {{code}}.',
          bs: 'Vaš verifikacijski kod za {{businessName}} je {{code}}.',
          da: 'Din bekræftelseskode til {{businessName}} er {{code}}.',
      },
      smsConfirmationTemplate: {
          en: 'Your booking for {{serviceName}} at {{businessName}} on {{date}} at {{time}} is confirmed.',
          bs: 'Vaša rezervacija za {{serviceName}} u {{businessName}} na dan {{date}} u {{time}} je potvrđena.',
          da: 'Din booking for {{serviceName}} hos {{businessName}} den {{date}} kl. {{time}} er bekræftet.',
      },
      smsReminderTemplate: {
          en: 'Reminder: Your appointment at {{businessName}} is at {{time}} on {{date}}.',
          bs: 'Podsjetnik: Vaš termin u {{businessName}} je u {{time}} na dan {{date}}.',
          da: 'Påmindelse: Din aftale hos {{businessName}} er kl. {{time}} den {{date}}.',
      },
      smsRescheduleTemplate: {
          en: 'Your appointment at {{businessName}} for {{serviceName}} has been rescheduled to {{date}} at {{time}}.',
          bs: 'Vaš termin u {{businessName}} za {{serviceName}} je premješten na {{date}} u {{time}}.',
          da: 'Din aftale hos {{businessName}} for {{serviceName}} er blevet flyttet til {{date}} kl. {{time}}.',
      },
       smsCancellationTemplate: {
          en: 'Your booking for {{serviceName}} at {{businessName}} on {{date}} at {{time}} has been cancelled.',
          bs: 'Vaša rezervacija za {{serviceName}} u {{businessName}} na dan {{date}} u {{time}} je otkazana.',
          da: 'Din booking for {{serviceName}} hos {{businessName}} den {{date}} kl. {{time}} er blevet annulleret.',
      },
      smsYourTurnSoonTemplate: {
          en: 'Your turn is soon at {{businessName}}. Please head to our location.',
          bs: 'Vi ste na redu u {{businessName}}. Molimo vas da dođete na našu lokaciju.',
          da: 'Det er snart din tur hos {{businessName}}. Venligst gå til vores lokation.' },
      smsStaffLoginTemplate: {
          en: 'Hi {{fullName}}, you have been set up with a staff account. Use your phone number and this 4-digit PIN to log in: {{pin}}. Go to {{loginUrl}} to sign in.',
          bs: 'Zdravo {{fullName}}, kreiran vam je račun za osoblje. Koristite svoj broj telefona i ovaj 4-cifreni PIN za prijavu: {{pin}}. Idite na {{loginUrl}} da se prijavite.',
          da: 'Hej {{fullName}}, du er blevet oprettet med en personalekonto. Brug dit telefonnummer og denne 4-cifrede PIN-kode for at logge ind: {{pin}}. Gå til {{loginUrl}} for at logge ind.' },
      enableNewBookingSmsNotification: false,
      newBookingSmsRecipient: '',
      smsNewBookingTemplate: {
          en: 'New booking for {{serviceName}} from {{customerName}} on {{date}} at {{time}} with {{staffName}}.',
          bs: 'Nova rezervacija za {{serviceName}} od {{customerName}} na dan {{date}} u {{time}} kod {{staffName}}.',
          da: 'Ny booking for {{serviceName}} fra {{customerName}} den {{date}} kl. {{time}} med {{staffName}}.',
      },
      createdAt: new Date().toISOString(),
      status: 'Active',
      bookingsCount: 0,
      maxBookingsPerUser: null,
      timezone: 'Europe/Copenhagen',
      metaTitle: '',
      metaDescription: '',
      metaImageUrl: '',
    });
    
    revalidatePath('/super-admin/businesses');
    
  } catch (error) {
    console.error("Error creating business:", error);
    return { success: false, errors: { _root: ['Failed to create business due to a server error.'] } };
  }

  // Find the created business to get its ID for redirection
  const db = admin.database();
  const businessesRef = db.ref('businesses');
  const snapshot = await businessesRef.orderByChild('businessName').equalTo(validationResult.data.businessName).once('value');
  if(snapshot.exists()){
      const businessId = Object.keys(snapshot.val())[0];
      redirect(`/super-admin/businesses/${businessId}/settings`);
  } 
  
  return { success: true };
}

export async function updateBusiness(id: string, formData: FormData) {
  
  const jsonData = formData.get('jsonData') as string;
  if (!jsonData) {
    return { success: false, errors: { _root: ["Missing form data."] } };
  }
  const data = JSON.parse(jsonData);
  
  const validationResult = businessSchema.partial().safeParse(data);

  if (!validationResult.success) {
      const errors = validationResult.error.flatten().fieldErrors;
      console.log("Validation errors:", errors);
      return { success: false, errors };
  }

  try {
    const { picturesToRemove, metaImageToRemove, ...businessData } = validationResult.data;
    const logoFile = formData.get('logo') as File | null;
    const metaImageFile = formData.get('metaImage') as File | null;
    const pwaIcon192File = formData.get('pwaIcon192') as File | null;
    const pwaIcon512File = formData.get('pwaIcon512') as File | null;
    const pwaMaskableIconFile = formData.get('pwaMaskableIcon') as File | null;
    
    const db = admin.database();
    const businessesRef = db.ref('businesses');
    const businessRef = db.ref(`businesses/${id}`);

    const existingDataSnapshot = await businessRef.once('value');
    if (!existingDataSnapshot.exists()) {
      return { success: false, errors: { _root: ["Business not found."] } };
    }
    const existingData = existingDataSnapshot.val();
    
    // Handle specific field validations for partial updates
    if (businessData.businessName && businessData.businessName !== existingData.businessName) {
        const snapshot = await businessesRef.orderByChild('businessName').equalTo(businessData.businessName).once('value');
        if (snapshot.exists()) {
            return { success: false, errors: { businessName: ["A business with this name already exists."] } };
        }
    }

    if (businessData.slug && businessData.slug !== existingData.slug) {
        const snapshot = await businessesRef.orderByChild('slug').equalTo(businessData.slug).once('value');
        if (snapshot.exists()) {
            const foundId = Object.keys(snapshot.val())[0];
            if (foundId !== id) {
                return { success: false, errors: { slug: ["This URL slug is already in use."] } };
            }
        }
    }
    
    if (logoFile) {
        businessData.logoUrl = await handleFileUpload(logoFile);
    }

    if (metaImageFile) {
        businessData.metaImageUrl = await handleFileUpload(metaImageFile);
    } else if (metaImageToRemove) {
        if (existingData.metaImageUrl) {
            try {
                const metaImageStorageRef = storageRef(storage, existingData.metaImageUrl);
                await deleteObject(metaImageStorageRef);
            } catch (e: any) {
                if (e.code !== 'storage/object-not-found') {
                    console.warn(`Failed to delete meta image from storage: ${existingData.metaImageUrl}`, e);
                }
            }
        }
        businessData.metaImageUrl = '';
    }

    if (pwaIcon192File) {
        businessData.pwaIcon192Url = await handleFileUpload(pwaIcon192File);
    }
    if (pwaIcon512File) {
        businessData.pwaIcon512Url = await handleFileUpload(pwaIcon512File);
    }
    if (pwaMaskableIconFile) {
        businessData.pwaMaskableIconUrl = await handleFileUpload(pwaMaskableIconFile);
    }
    
    const updatePayload: any = {
        ...businessData,
        updatedAt: new Date().toISOString(),
    };
    
    await businessRef.update(updatePayload);

    revalidatePath('/super-admin/businesses');
    revalidatePath(`/super-admin/businesses/${id}`, 'layout');
    revalidatePath(`/${id}`);
    if (businessData.slug) {
        revalidatePath(`/${businessData.slug}`);
    }


    return { success: true, businessId: id };

  } catch (error) {
      console.error("Error updating business:", error);
      return { success: false, errors: { _root: ['Failed to update business due to a server error.'] } };
  }
}

export async function createStaffKioskUser(businessId: string, data: StaffKioskUserFormData) {
  const validationResult = staffKioskUserSchema.safeParse(data);
  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }

  try {
    const usersRef = admin.database().ref(`businesses/${businessId}/staffKioskUsers`);
    
    const existingUserSnapshot = await usersRef.orderByChild('phone').equalTo(data.phone).once('value');
    if (existingUserSnapshot.exists()) {
      return { success: false, errors: { phone: ["A user with this phone number already exists."] } };
    }
    
    const pin = Math.floor(1000 + Math.random() * 9000).toString();
    const salt = await bcrypt.genSalt(10);
    const hashedPin = await bcrypt.hash(pin, salt);

    const newUserRef = usersRef.push();
    await newUserRef.set({ ...data, pin: hashedPin });

    // Send SMS with login details
    const businessRef = admin.database().ref(`businesses/${businessId}`);
    const businessSnapshot = await businessRef.once('value');
    const business = businessSnapshot.val();

    const smsClient = await getSmsClient(businessId);
    if (smsClient) {
      const globalSettings = await getGlobalSettings();
      const appName = globalSettings.general?.appName || 'QueuePilot';
      const lang = business.smsLanguage || 'bs';
      const loginUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/staff/login`;
      const template = business.smsStaffLoginTemplate?.[lang] || 'Hi {{fullName}}, you have been set up with a staff account. Use your phone number and this 4-digit PIN to log in: {{pin}}. Go to {{loginUrl}} to sign in.';
      const text = template
        .replace('{{fullName}}', data.fullName)
        .replace('{{pin}}', pin)
        .replace('{{loginUrl}}', loginUrl);
      
      await smsClient.send({ to: data.phone, text, from: business.businessName || appName });
    }

    revalidatePath(`/super-admin/businesses/${businessId}/settings`);
    return { success: true };
  } catch (error: any) {
    return { success: false, errors: { _root: [error.message || 'Failed to create user.'] } };
  }
}

export async function updateStaffKioskUser(businessId: string, userId: string, data: Partial<StaffKioskUserFormData>) {
  const validationResult = staffKioskUserSchema.partial().safeParse(data); // Use partial for updates
  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }
  try {
    const userRef = admin.database().ref(`businesses/${businessId}/staffKioskUsers/${userId}`);
    await userRef.update(validationResult.data);
    revalidatePath(`/super-admin/businesses/${businessId}/settings`);
    return { success: true };
  } catch (error) {
    return { success: false, errors: { _root: ['Failed to update user.'] } };
  }
}

export async function resetStaffKioskUserPin(businessId: string, userId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const userRef = admin.database().ref(`businesses/${businessId}/staffKioskUsers/${userId}`);
        const userSnapshot = await userRef.once('value');
        if (!userSnapshot.exists()) {
            return { success: false, error: "User not found." };
        }
        const userData = userSnapshot.val();

        const newPin = Math.floor(1000 + Math.random() * 9000).toString();
        const salt = await bcrypt.genSalt(10);
        const hashedPin = await bcrypt.hash(newPin, salt);
        await userRef.update({ pin: hashedPin });

        const businessRef = admin.database().ref(`businesses/${businessId}`);
        const businessSnapshot = await businessRef.once('value');
        const business = businessSnapshot.val();

        const smsClient = await getSmsClient(businessId);
        if (smsClient) {
            const globalSettings = await getGlobalSettings();
            const appName = globalSettings.general?.appName || 'QueuePilot';
            const lang = business.smsLanguage || 'bs';
            const loginUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/staff/login`;
            const template = business.smsStaffLoginTemplate?.[lang] || 'Hi {{fullName}}, you have been set up with a staff account. Use your phone number and this 4-digit PIN to log in: {{pin}}. Go to {{loginUrl}} to sign in.';
            const text = template
                .replace('{{fullName}}', userData.fullName)
                .replace('{{pin}}', newPin)
                .replace('{{loginUrl}}', loginUrl);
            
            await smsClient.send({ to: userData.phone, text, from: business.businessName || appName });
        }
        
        revalidatePath(`/super-admin/businesses/${businessId}/settings`);
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || 'Failed to reset PIN.' };
    }
}


export async function deleteStaffKioskUser(businessId: string, userId: string) {
  try {
    const userRef = admin.database().ref(`businesses/${businessId}/staffKioskUsers/${userId}`);
    await userRef.remove();
    revalidatePath(`/super-admin/businesses/${businessId}/settings`);
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message || 'Failed to delete user.' };
  }
}

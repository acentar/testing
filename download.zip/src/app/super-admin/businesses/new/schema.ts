
import { z } from 'zod';

const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/; // HH:mm format

const dayAvailabilitySchema = z.object({
  day: z.string(),
  working: z.boolean().optional(),
  from: z.string().regex(timeRegex, 'Invalid time format').optional().nullable(),
  to: z.string().regex(timeRegex, 'Invalid time format').optional().nullable(),
}).refine(data => {
    if (!data.working) {
        return true;
    }
    return !!data.from && !!data.to && data.from < data.to;
}, {
  message: "For working days, 'from' and 'to' times are required, and 'from' must be earlier than 'to'.",
  path: ['from'] 
});


export const createBusinessSchema = z.object({
  businessName: z.string().min(2, 'Business name must be at least 2 characters long.'),
});

const imageFileSchema = z.instanceof(File, { message: "Please upload a file." })
  .refine(file => file.size < 50 * 1024 * 1024, "File size should be less than 50MB.")
  .refine(file => ["image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml"].includes(file.type), "Only .jpg, .png, .gif, .webp and .svg formats are supported.")
  .optional()
  .nullable();

const pngFileSchema = z.instanceof(File, { message: "Please upload a PNG file." })
  .refine(file => file.size < 2 * 1024 * 1024, "File size should be less than 2MB.")
  .refine(file => file.type === "image/png", "Only .png format is supported.")
  .optional()
  .nullable();

export const staffKioskUserSchema = z.object({
  fullName: z.string().min(2, 'Full name is required.'),
  phone: z.string().min(8, 'A valid phone number is required.'),
  phoneCountry: z.enum(['DK', 'BA']).default('BA').optional(),
});
export type StaffKioskUserFormData = z.infer<typeof staffKioskUserSchema>;
export type StaffKioskUser = StaffKioskUserFormData & { id: string, pin: string };

export const updateStaffKioskUserPinSchema = z.object({
  pin: z.string().length(4, "PIN must be 4 digits.").optional(),
  fullName: z.string().min(2, 'Full name is required.').optional(),
  phone: z.string().min(8, 'A valid phone number is required.').optional(),
  phoneCountry: z.enum(['DK', 'BA']).default('BA').optional(),
});


const staffAppSettingsSchema = z.object({
    autoCompleteBookings: z.boolean().default(false),
    autoStartBookings: z.boolean().default(false),
});

export const businessSchema = z.object({
    businessName: z.string().min(2, 'Business name must be at least 2 characters long.'),
    businessEmail: z.string().email('Please enter a valid email address.').optional().nullable().or(z.literal('')),
    businessPhone: z.string().optional().nullable().or(z.literal('')),
    logo: z.any().optional(),
    logoToRemove: z.boolean().optional(),
    address: z.object({
        street: z.string().optional().nullable(),
        city: z.string().optional().nullable(),
        state: z.string().optional().nullable(),
        postalCode: z.string().optional().nullable(),
        country: z.string().optional().nullable(),
    }).optional(),
    operatingHours: z.array(dayAvailabilitySchema).optional(),
    timezone: z.string().optional(),
    language: z.enum(['en', 'bs', 'da']).default('bs'),
    currency: z.enum(['DKK', 'BAM']).default('DKK'),

    // Booking Page settings
    description: z.string().optional().nullable(),
    showAboutUs: z.boolean().default(true),
    showLocation: z.boolean().default(true),
    showOperatingHours: z.boolean().default(true),
    
    // Booking Policies
    maxBookingsPerUser: z.coerce.number().nullable().optional(),
    leadTimeValue: z.coerce.number().nullable().optional(),
    leadTimeUnit: z.enum(['minutes', 'hours', 'days']).default('minutes'),
    schedulingWindowValue: z.coerce.number().nullable().optional(),
    schedulingWindowUnit: z.enum(['days', 'months']).default('days'),
    cancellationPolicy: z.string().default('anytime'),
    bookingPolicy: z.string().optional().nullable(),
    weekStartsOn: z.number().min(0).max(6).default(1),

    // URL / Domain settings
    slug: z.string().optional().nullable(),
    
    // SEO
    metaTitle: z.string().max(60).optional().nullable(),
    metaDescription: z.string().max(150).optional().nullable(),
    metaImage: imageFileSchema,
    metaImageToRemove: z.boolean().optional(),
    
    // Appearance
    theme: z.enum(['light', 'dark']).default('dark'),
    enableCustomDesign: z.boolean().optional(),
    primaryColor: z.string().optional().nullable(),
    backgroundColor: z.string().optional().nullable(),
    buttonShape: z.enum(['rectangle', 'rounded', 'pill']).default('rounded'),

    // SMS Settings
    enableSms: z.boolean().default(false),
    allowedPhoneCountries: z.array(z.enum(['DK', 'BA'])).optional(),
    smsProvider: z.enum(['vonage', 'textbee']).default('vonage'),
    textbeeDeviceId: z.string().optional().nullable(),
    vonageApiKey: z.string().optional().nullable(),
    vonageApiSecret: z.string().optional().nullable(),
    smsLanguage: z.enum(['en', 'bs', 'da']).default('bs'),
    smsVerificationTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsConfirmationTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsReminderTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsRescheduleTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsCancellationTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsYourTurnSoonTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    smsStaffLoginTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    enableNewBookingSmsNotification: z.boolean().default(false),
    newBookingSmsRecipient: z.string().optional().nullable(),
    smsNewBookingTemplate: z.object({ en: z.string(), bs: z.string(), da: z.string() }).optional(),
    
    // Platform features
    enableCalendar: z.boolean().default(true),

    // Staff App settings
    staffAppSettings: staffAppSettingsSchema.optional(),
    staffKioskUsers: z.record(staffKioskUserSchema).optional(),

    // PWA settings
    enablePwa: z.boolean().default(false),
    pwaShortName: z.string().max(20).optional().nullable(),
    pwaThemeColor: z.string().optional().nullable(),
    pwaBackgroundColor: z.string().optional().nullable(),
    pwaIcon512: pngFileSchema,
    pwaIcon192: pngFileSchema,
    pwaMaskableIcon: pngFileSchema,
});

export type BusinessFormData = z.infer<typeof businessSchema>;


'use client';

import * as React from 'react';
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { ArrowUpDown, ChevronDown, MoreHorizontal, Edit, Trash2 } from "lucide-react"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { type AggregatedBooking, deleteBooking } from './actions';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

const statusVariantMap: Record<AggregatedBooking['status'], 'default' | 'secondary' | 'destructive'> = {
    'waiting': 'secondary',
    'in-progress': 'default',
    'completed': 'default',
    'cancelled': 'destructive',
};

const statusClassMap: Record<AggregatedBooking['status'], string> = {
    'waiting': 'bg-yellow-500/80',
    'in-progress': 'bg-blue-500/80',
    'completed': 'bg-green-600/80',
    'cancelled': '', // uses default destructive
};

// Client-side only component to prevent hydration mismatch on dates
const FormattedDateCell = ({ dateTime }: { dateTime: number }) => {
    const [formattedDate, setFormattedDate] = React.useState('');

    React.useEffect(() => {
        if (dateTime && !isNaN(dateTime)) {
            setFormattedDate(format(new Date(dateTime), 'LLL d, yyyy HH:mm'));
        } else {
            setFormattedDate('N/A');
        }
    }, [dateTime]);

    // Render a placeholder on the server and initial client render
    if (!formattedDate) {
        return <div className="text-left font-medium">Loading date...</div>;
    }

    return <div className="text-left font-medium">{formattedDate}</div>;
}


interface BookingsClientPageProps {
  bookings: AggregatedBooking[];
  onUpdate: () => void;
}

export function BookingsClientPage({ bookings: initialBookings, onUpdate }: BookingsClientPageProps) {
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({})
  const [globalFilter, setGlobalFilter] = React.useState('')
  const { toast } = useToast();
  const router = useRouter();


  const handleEditBooking = (booking: AggregatedBooking) => {
    const query = new URLSearchParams({ booking: JSON.stringify(booking) }).toString();
    router.push(`/${booking.businessId}/staff-screen/schedule?${query}`);
  }

  const handleDeleteBooking = async (booking: AggregatedBooking) => {
    const result = await deleteBooking(booking.businessId, booking.staffId, booking.bookingId);
    if (result.success) {
      toast({ title: "Booking deleted", description: "The booking has been successfully deleted."});
      onUpdate();
    } else {
      toast({ variant: "destructive", title: "Error", description: result.error });
    }
  }


  const columns: ColumnDef<AggregatedBooking>[] = [
    {
      accessorKey: "businessName",
      header: "Business",
      cell: ({ row }) => (
        <Link href={`/super-admin/businesses/${row.original.businessId}/edit`} className="hover:underline font-medium">
            {row.getValue("businessName")}
        </Link>
      ),
    },
    {
      accessorKey: "serviceName",
      header: "Service",
    },
    {
      accessorKey: "customerName",
      header: "Customer",
      cell: ({ row }) => (
          <div>
              <div>{row.getValue("customerName")}</div>
              <div className="text-xs text-muted-foreground">{row.original.customerPhone}</div>
          </div>
      )
    },
    {
      accessorKey: "dateTime",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Date & Time
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        )
      },
      cell: ({ row }) => {
        const dateTime: number = row.getValue("dateTime");
        return <FormattedDateCell dateTime={dateTime} />
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
          const status: AggregatedBooking['status'] = row.getValue("status");
          
          if (!status) {
              return <Badge variant="secondary">Unknown</Badge>;
          }
          
          return (
              <Badge 
                  variant={statusVariantMap[status] || 'secondary'} 
                  className={cn('capitalize', statusClassMap[status])}
              >
                  {status.replace('-', ' ')}
              </Badge>
          );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const booking = row.original

        return (
          <AlertDialog>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleEditBooking(booking)}>
                  <Edit className="mr-2 h-4 w-4" /> Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <AlertDialogTrigger asChild>
                    <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}>
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                    </DropdownMenuItem>
                </AlertDialogTrigger>
              </DropdownMenuContent>
            </DropdownMenu>
             <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                    This will permanently delete the booking for {booking.customerName}. This action cannot be undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => handleDeleteBooking(booking)} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )
      },
    },
  ]


  const table = useReactTable({
    data: initialBookings,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onGlobalFilterChange: setGlobalFilter,
    globalFilterFn: (row, columnId, filterValue) => {
        const safeValue = (value: any) => String(value ?? '').toLowerCase();
        const businessName = safeValue(row.original.businessName);
        const customerName = safeValue(row.original.customerName);
        const serviceName = safeValue(row.original.serviceName);
        return businessName.includes(filterValue) || customerName.includes(filterValue) || serviceName.includes(filterValue);
    },
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      globalFilter,
    },
  })


  return (
    <Card>
      <CardHeader>
        <div className="flex items-center py-4">
            <Input
            placeholder="Filter by customer, service or business..."
            value={globalFilter}
            onChange={(event) => setGlobalFilter(event.target.value)}
            className="max-w-sm"
            />
            <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                Columns <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                {table
                .getAllColumns()
                .filter((column) => column.getCanHide())
                .map((column) => {
                    return (
                    <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                        column.toggleVisibility(!!value)
                        }
                    >
                        {column.id}
                    </DropdownMenuCheckboxItem>
                    )
                })}
            </DropdownMenuContent>
            </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
         <div className="flex items-center justify-end space-x-2 py-4">
            <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
            >
            Previous
            </Button>
            <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
            >
            Next
            </Button>
        </div>
      </CardContent>
    </Card>
  );
}

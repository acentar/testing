
'use client';

import * as React from 'react';
import { getBookingsAcrossBusinesses, type AggregatedBooking } from './actions';
import { BookingsClientPage } from './client-page';
import { Skeleton } from '@/components/ui/skeleton';

export default function SuperAdminBookingsPage() {
  const [bookings, setBookings] = React.useState<AggregatedBooking[]>([]);
  const [loading, setLoading] = React.useState(true);

  const fetchBookings = React.useCallback(async () => {
    setLoading(true);
    const fetchedBookings = await getBookingsAcrossBusinesses();
    setBookings(fetchedBookings);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  return (
     <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">All bookings</h2>
          <p className="text-muted-foreground">
            View and manage all bookings across the platform.
          </p>
        </div>
      </div>
      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      ) : (
        <BookingsClientPage bookings={bookings} onUpdate={fetchBookings} />
      )}
    </>
  );
}

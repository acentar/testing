
'use server';

import { rtdb } from '@/lib/firebase';
import { ref, get, remove } from 'firebase/database';
import { parse } from 'date-fns';
import { revalidatePath } from 'next/cache';

export type AggregatedBooking = {
    id: string; // combination of businessId and bookingId
    businessId: string;
    businessName: string;
    bookingId: string;
    customerName: string;
    customerPhone: string;
    serviceId: string;
    serviceName: string;
    staffId: string; // Added staffId
    date: string;
    time: string;
    status: 'waiting' | 'in-progress' | 'completed' | 'cancelled';
    dateTime: number; // For sorting
    // Include all other booking properties for editing
    [key: string]: any;
};

export async function getBookingsAcrossBusinesses(): Promise<AggregatedBooking[]> {
  try {
    const [businessesSnapshot, schedulesSnapshot] = await Promise.all([
        get(ref(rtdb, 'businesses')),
        get(ref(rtdb, 'schedules'))
    ]);

    if (!businessesSnapshot.exists()) {
      return [];
    }

    const allBookings: AggregatedBooking[] = [];
    const businessesData = businessesSnapshot.val();
    const allSchedules = schedulesSnapshot.exists() ? schedulesSnapshot.val() : {};

    for (const businessId in businessesData) {
      const business = businessesData[businessId];
      const businessSchedule = allSchedules[businessId] || {};
      
      for (const staffId in businessSchedule) {
        const staffSchedule = businessSchedule[staffId];
        for (const eventId in staffSchedule) {
            const event = staffSchedule[eventId];
            if (event.type === 'booking') {
                 allBookings.push({
                    ...event, // Spread all event properties
                    id: `${businessId}-${eventId}`,
                    businessId,
                    businessName: business.businessName,
                    bookingId: eventId,
                    staffId, // Include staffId
                    dateTime: parse(`${event.date} ${event.time}`, 'yyyy-MM-dd HH:mm', new Date()).getTime(),
                });
            }
        }
      }
    }

    // Sort by most recent date first
    return allBookings.sort((a, b) => b.dateTime - a.dateTime);
  } catch (error) {
    console.error("Error fetching bookings across businesses:", error);
    return [];
  }
}

export async function deleteBooking(businessId: string, staffId: string, bookingId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const bookingRef = ref(rtdb, `schedules/${businessId}/${staffId}/${bookingId}`);
        await remove(bookingRef);
        revalidatePath('/super-admin/bookings');
        return { success: true };
    } catch (error) {
        console.error("Error deleting booking:", error);
        return { success: false, error: "Failed to delete booking." };
    }
}

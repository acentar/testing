
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { sendCustomSms } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, MessageSquare } from 'lucide-react';
import { PhoneInput } from '@/components/phone-input';

const smsSchema = z.object({
  to: z.string().min(1, 'Recipient phone number is required.'),
  text: z.string().min(1, 'SMS content cannot be empty.'),
});

type SmsFormData = z.infer<typeof smsSchema>;

export function SendSmsForm() {
    const { toast } = useToast();
    const form = useForm<SmsFormData>({
        resolver: zodResolver(smsSchema),
        defaultValues: {
            to: '',
            text: '',
        }
    });

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: SmsFormData) => {
        const result = await sendCustomSms(data);
        if (result.success) {
            toast({
                title: 'SMS Sent Successfully!',
                description: `The message has been sent to ${data.to}.`,
            });
            form.reset({
              ...form.getValues(),
              to: '',
              text: '',
            });
        } else {
            const errorMessage = result.errors?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Send SMS',
                description: errorMessage,
            });
        }
    }

    return (
        <Card>
            <CardHeader>
                <div className='flex items-center gap-2'>
                    <MessageSquare className="h-5 w-5" />
                    <CardTitle>Send a Custom SMS (via TextBee)</CardTitle>
                </div>
                <CardDescription>
                    Send a one-off SMS message for testing or administrative purposes using the globally configured TextBee provider.
                </CardDescription>
            </CardHeader>
             <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardContent className="space-y-6">
                        <FormField
                            control={form.control}
                            name="to"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Recipient Phone Number</FormLabel>
                                    <FormControl>
                                        <PhoneInput {...field} allowedCountries={['DK', 'BA']} defaultCountry="BA" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="text"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>SMS Content</FormLabel>
                                    <FormControl>
                                        <Textarea rows={4} placeholder="Your message here..." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Send Message
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    );
}

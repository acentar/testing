
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { getGlobalSettings, updateGeneralSettings } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Settings, Play } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const generalSettingsSchema = z.object({
  appName: z.string().min(2, "App name must be at least 2 characters."),
  appVersion: z.string().optional(),
  appLogo: z.any().optional(),
  adminLogo: z.any().optional(),
  staffKioskLogo: z.any().optional(),
  staffKioskBgImage: z.any().optional(),
  appFavicon: z.any().optional(),
  newBookingSound: z.any().optional(),
});

type GeneralSettingsFormData = z.infer<typeof generalSettingsSchema>;

export function GeneralSettingsForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);
    const [globalSettings, setGlobalSettings] = React.useState<any>({});
    const [soundPreviewUrl, setSoundPreviewUrl] = React.useState<string | null>(null);
    const audioRef = React.useRef<HTMLAudioElement>(null);


    const form = useForm<GeneralSettingsFormData>({
        resolver: zodResolver(generalSettingsSchema),
        defaultValues: {
            appName: 'Bestiller.com',
            appVersion: '1.4.0',
        }
    });

    const newBookingSoundFile = form.watch('newBookingSound');

    React.useEffect(() => {
        if (newBookingSoundFile instanceof File) {
            const url = URL.createObjectURL(newBookingSoundFile);
            setSoundPreviewUrl(url);
            return () => URL.revokeObjectURL(url);
        } else if (globalSettings?.newBookingSoundUrl) {
            setSoundPreviewUrl(globalSettings.newBookingSoundUrl);
        } else {
            setSoundPreviewUrl(null);
        }
    }, [newBookingSoundFile, globalSettings.newBookingSoundUrl]);

    React.useEffect(() => {
        async function loadSettings() {
            setLoading(true);
            const settings = await getGlobalSettings();
            setGlobalSettings(settings.general || {});
            if (settings.general) {
                form.reset({
                  appName: settings.general.appName || 'Bestiller.com',
                  appVersion: settings.general.appVersion ?? '',
                });
            }
            setLoading(false);
        }
        loadSettings();
    }, [form]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: GeneralSettingsFormData) => {
        const formData = new FormData();
        const { appLogo, appFavicon, adminLogo, staffKioskLogo: staffAppSettingsLogo, staffKioskBgImage: staffAppSettingsBgImage, newBookingSound, ...settingsData } = data;
        formData.append('jsonData', JSON.stringify(settingsData));

        if (appLogo instanceof File) formData.append('logo', appLogo);
        if (appFavicon instanceof File) formData.append('favicon', appFavicon);
        if (adminLogo instanceof File) formData.append('adminLogo', adminLogo);
        if (staffAppSettingsLogo instanceof File) formData.append('staffKioskLogo', staffAppSettingsLogo);
        if (staffAppSettingsBgImage instanceof File) formData.append('staffKioskBgImage', staffAppSettingsBgImage);
        if (newBookingSound instanceof File) formData.append('newBookingSound', newBookingSound);

        const result = await updateGeneralSettings(formData);

        if (result.success) {
            toast({
                title: 'Settings Updated!',
                description: 'General settings have been saved.',
            });
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Save Settings',
                description: errorMessage,
            });
        }
    }
    
    const handlePlaySound = () => {
        if (audioRef.current) {
            audioRef.current.play().catch(e => console.error("Audio playback error:", e));
        }
    };
    
    if(loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <div className='flex items-center gap-2'>
                            <Settings className="h-5 w-5" />
                            <CardTitle>General Settings</CardTitle>
                        </div>
                        <CardDescription>
                            Manage the global branding and identity of the application.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <FormField
                            control={form.control}
                            name="appName"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Application Name</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., Bestiller.com" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="appVersion"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Application Version</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., 1.4.0" {...field} value={field.value ?? ''} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                             <FormField
                                control={form.control}
                                name="appLogo"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Application Logo</FormLabel>
                                        <FormControl>
                                            <Input type="file" accept="image/svg+xml, image/png, image/jpeg, image/jpg" onChange={(e) => field.onChange(e.target.files?.[0])} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="adminLogo"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Admin Panel Logo</FormLabel>
                                        <FormControl>
                                            <Input type="file" accept="image/svg+xml, image/png, image/jpeg, image/jpg" onChange={(e) => field.onChange(e.target.files?.[0])} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="staffKioskLogo"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Staff App Logo</FormLabel>
                                        <FormControl>
                                            <Input type="file" accept="image/svg+xml, image/png, image/jpeg, image/jpg" onChange={(e) => field.onChange(e.target.files?.[0])} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="staffKioskBgImage"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Staff App Background Image</FormLabel>
                                        <FormControl>
                                            <Input type="file" accept="image/jpeg,image/jpg,image/png,image/webp" onChange={(e) => field.onChange(e.target.files?.[0])} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="appFavicon"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Application Favicon</FormLabel>
                                        <FormControl>
                                            <Input type="file" accept="image/x-icon, image/png, image/svg+xml" onChange={(e) => field.onChange(e.target.files?.[0])}/>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="newBookingSound"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>New Booking Notification Sound</FormLabel>
                                        <div className="flex items-center gap-2">
                                            <FormControl>
                                                <Input type="file" accept=".wav" onChange={(e) => field.onChange(e.target.files?.[0])} />
                                            </FormControl>
                                            <Button type="button" variant="outline" size="icon" onClick={handlePlaySound} disabled={!soundPreviewUrl}>
                                                <Play className="h-4 w-4"/>
                                            </Button>
                                        </div>
                                         <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save General Settings
                        </Button>
                    </CardFooter>
                </form>
            </Form>
            {soundPreviewUrl && <audio ref={audioRef} src={soundPreviewUrl} preload="auto" />}
        </Card>
    );
}

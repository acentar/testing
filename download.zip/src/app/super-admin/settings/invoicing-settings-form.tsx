
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { getGlobalSettings, updateInvoicingSettings } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, FileText } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { invoicingSettingsSchema, type InvoicingSettingsFormData } from './schema';

export function InvoicingSettingsForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);

    const form = useForm<InvoicingSettingsFormData>({
        resolver: zodResolver(invoicingSettingsSchema),
        defaultValues: {
            companyName: '',
            taxId: '',
            address: '',
            bankDetails: '',
            invoiceNotes: '',
        }
    });

    React.useEffect(() => {
        async function loadSettings() {
            setLoading(true);
            const settings = await getGlobalSettings();
            if (settings.invoicing) {
                form.reset(settings.invoicing);
            }
            setLoading(false);
        }
        loadSettings();
    }, [form]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: InvoicingSettingsFormData) => {
        const result = await updateInvoicingSettings(data);
        if (result.success) {
            toast({
                title: 'Settings Updated!',
                description: 'Invoicing details have been saved.',
            });
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Save Settings',
                description: errorMessage,
            });
        }
    }
    
    if(loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <div className='flex items-center gap-2'>
                            <FileText className="h-5 w-5" />
                            <CardTitle>Invoicing Settings</CardTitle>
                        </div>
                        <CardDescription>
                            Enter your company's details to be displayed on all invoices.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="companyName"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Company Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Your Company LLC" {...field} value={field.value ?? ''} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="taxId"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Tax ID / VAT Number</FormLabel>
                                        <FormControl>
                                            <Input placeholder="Your Tax ID" {...field} value={field.value ?? ''} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={form.control}
                            name="address"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Company Address</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="123 Main Street&#10;Anytown, ST 12345" {...field} value={field.value ?? ''} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="bankDetails"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Bank Details</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="Bank Name&#10;Account Number / IBAN" {...field} value={field.value ?? ''} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="invoiceNotes"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Default Invoice Notes</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="e.g., Thank you for your business. Payment is due within 30 days." {...field} value={field.value ?? ''} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Invoicing Details
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    );
}


'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { getGlobalSmsSettings, updateGlobalSmsSettings } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Bell } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { PhoneInput } from '@/components/phone-input';
import { Textarea } from '@/components/ui/textarea';
import { smsAlertingSchema, type SmsAlertingFormData } from './schema';

export function SmsAlertingForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);

    const form = useForm<SmsAlertingFormData>({
        resolver: zodResolver(smsAlertingSchema),
        defaultValues: {
            monthlySmsCapacity: 1080,
            alertPhoneNumber: '',
            alertEmail: '',
        }
    });

    React.useEffect(() => {
        async function loadSettings() {
            setLoading(true);
            const settings = await getGlobalSmsSettings();
            form.reset({
                monthlySmsCapacity: settings.monthlySmsCapacity || 1080,
                alertPhoneNumber: settings.alertPhoneNumber || '',
                alertEmail: settings.alertEmail || ''
            });
            setLoading(false);
        }
        loadSettings();
    }, [form]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: SmsAlertingFormData) => {
        const result = await updateGlobalSmsSettings(data);
        if (result.success) {
            toast({
                title: 'Settings Updated!',
                description: 'SMS capacity and alert settings have been saved.',
            });
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Save Settings',
                description: errorMessage,
            });
        }
    }
    
    if(loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <div className='flex items-center gap-2'>
                            <Bell className="h-5 w-5" />
                            <CardTitle>SMS Capacity & Alerts</CardTitle>
                        </div>
                        <CardDescription>
                            Set the monthly system-wide SMS limit and configure low-balance warnings.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <FormField
                            control={form.control}
                            name="monthlySmsCapacity"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Monthly SMS Capacity</FormLabel>
                                    <FormControl>
                                        <Input type="number" placeholder="e.g., 1080" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="alertPhoneNumber"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Alert Phone Number (Optional)</FormLabel>
                                    <FormControl>
                                        <PhoneInput {...field} allowedCountries={['DK', 'BA']} defaultCountry="BA" />
                                    </FormControl>
                                     <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="alertEmail"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Alert Email(s) (Optional)</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="e.g., admin@example.com, tech@example.com" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                        Enter one or more email addresses, separated by commas, to receive system notifications.
                                    </FormDescription>
                                     <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Settings
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    );
}

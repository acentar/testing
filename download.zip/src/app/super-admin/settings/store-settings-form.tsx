
'use client';

import * as React from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { getGlobalSettings, updateStoreSettings } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Store, Euro, Dna, Banknote, Landmark, Percent } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { storeSettingsSchema, type StoreSettingsFormData } from './schema';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

const currencyIcons = {
    EUR: <Euro className="h-4 w-4" />,
    DKK: <Dna className="h-4 w-4" />, // Placeholder
    BAM: <Landmark className="h-4 w-4" />, // Placeholder
};


export function StoreSettingsForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);

    const form = useForm<StoreSettingsFormData>({
        resolver: zodResolver(storeSettingsSchema),
        defaultValues: {
            en: { currency: 'EUR', pricePerCalendar: 0, setupFee: 0, vatRate: 0 },
            da: { currency: 'DKK', pricePerCalendar: 0, setupFee: 0, vatRate: 0 },
            bs: { currency: 'BAM', pricePerCalendar: 0, setupFee: 0, vatRate: 0 },
        }
    });
    
    React.useEffect(() => {
        async function loadSettings() {
            setLoading(true);
            const settings = await getGlobalSettings();
            if (settings.store) {
                 const currentSettings = settings.store;
                 form.reset({
                    en: {
                        currency: currentSettings.en?.currency || 'EUR',
                        pricePerCalendar: currentSettings.en?.pricePerCalendar || 0,
                        setupFee: currentSettings.en?.setupFee || 0,
                        vatRate: currentSettings.en?.vatRate || 0,
                    },
                    da: {
                        currency: currentSettings.da?.currency || 'DKK',
                        pricePerCalendar: currentSettings.da?.pricePerCalendar || 0,
                        setupFee: currentSettings.da?.setupFee || 0,
                        vatRate: currentSettings.da?.vatRate || 0,
                    },
                    bs: {
                        currency: currentSettings.bs?.currency || 'BAM',
                        pricePerCalendar: currentSettings.bs?.pricePerCalendar || 0,
                        setupFee: currentSettings.bs?.setupFee || 0,
                        vatRate: currentSettings.bs?.vatRate || 0,
                    },
                 });
            }
            setLoading(false);
        }
        loadSettings();
    }, [form]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: StoreSettingsFormData) => {
        const result = await updateStoreSettings(data);
        if (result.success) {
            toast({
                title: 'Store Settings Updated!',
                description: 'Pricing and currency settings have been saved.',
            });
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Save Settings',
                description: errorMessage,
            });
        }
    }
    
    if(loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-24 w-full" />
                </CardContent>
            </Card>
        )
    }

    const renderRegionTab = (region: 'en' | 'da' | 'bs') => {
        const currency = form.watch(`${region}.currency`);
        return (
            <div className="space-y-4">
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                        control={form.control}
                        name={`${region}.pricePerCalendar`}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Price per calendar</FormLabel>
                                <FormControl>
                                    <div className="relative">
                                        <Input type="number" placeholder="e.g., 9" {...field} className="pl-8"/>
                                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">
                                          {currencyIcons[currency]}
                                        </div>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name={`${region}.setupFee`}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>One-time setup fee</FormLabel>
                                <FormControl>
                                   <div className="relative">
                                        <Input type="number" placeholder="e.g., 45" {...field} className="pl-8"/>
                                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">
                                          {currencyIcons[currency]}
                                        </div>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                 </div>
                 <FormField
                    control={form.control}
                    name={`${region}.vatRate`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>VAT Rate</FormLabel>
                             <FormControl>
                                   <div className="relative">
                                        <Input type="number" placeholder="e.g., 25" {...field} className="pr-8"/>
                                        <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground">
                                          <Percent className="h-4 w-4" />
                                        </div>
                                    </div>
                                </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                    />
            </div>
        )
    }

    return (
        <Card>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <div className='flex items-center gap-2'>
                            <Store className="h-5 w-5" />
                            <CardTitle>Store Settings</CardTitle>
                        </div>
                        <CardDescription>
                            Manage pricing, currencies, and other order-related settings.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                         <Tabs defaultValue="en" className="w-full">
                            <TabsList className="grid w-full grid-cols-3">
                                <TabsTrigger value="en">English (EUR)</TabsTrigger>
                                <TabsTrigger value="da">Danish (DKK)</TabsTrigger>
                                <TabsTrigger value="bs">Bosnian (BAM)</TabsTrigger>
                            </TabsList>
                            <TabsContent value="en" className="pt-4">{renderRegionTab('en')}</TabsContent>
                            <TabsContent value="da" className="pt-4">{renderRegionTab('da')}</TabsContent>
                            <TabsContent value="bs" className="pt-4">{renderRegionTab('bs')}</TabsContent>
                        </Tabs>
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Store Settings
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    );
}


import { z } from 'zod';

export const smsAlertingSchema = z.object({
  monthlySmsCapacity: z.coerce.number().int().min(1, 'Capacity must be at least 1.'),
  alertPhoneNumber: z.string().optional().or(z.literal('')),
  alertEmail: z.string().optional().or(z.literal('')),
});

export type SmsAlertingFormData = z.infer<typeof smsAlertingSchema>;


const regionSettingSchema = z.object({
    currency: z.enum(['EUR', 'DKK', 'BAM']),
    pricePerCalendar: z.coerce.number().positive(),
    setupFee: z.coerce.number().min(0, 'Setup fee must be a positive number or zero.'),
    vatRate: z.coerce.number().min(0).max(100).default(0),
});

export const storeSettingsSchema = z.object({
    en: regionSettingSchema,
    da: regionSettingSchema,
    bs: regionSettingSchema,
});

export type StoreSettingsFormData = z.infer<typeof storeSettingsSchema>;

export const invoicingSettingsSchema = z.object({
    companyName: z.string().optional(),
    taxId: z.string().optional(),
    address: z.string().optional(),
    bankDetails: z.string().optional(),
    invoiceNotes: z.string().optional(),
});

export type InvoicingSettingsFormData = z.infer<typeof invoicingSettingsSchema>;

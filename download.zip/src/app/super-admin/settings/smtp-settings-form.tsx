
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { getSmtpSettings, updateSmtpSettings, sendTestEmail } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Mail, Send } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';

const smtpSettingsSchema = z.object({
  server: z.string().min(1, "Server is required."),
  smtpPort: z.coerce.number().int().positive("SMTP Port must be a positive number."),
  imapPort: z.coerce.number().int().positive("IMAP Port must be a positive number."),
  username: z.string().min(1, "Username is required."),
  password: z.string().min(1, "Password is required."),
  fromName: z.string().optional(),
  fromEmail: z.string().email("Please enter a valid 'From' email."),
});

type SmtpFormData = z.infer<typeof smtpSettingsSchema>;

const testEmailSchema = z.object({
    recipient: z.string().email("A valid email is required."),
});
type TestEmailFormData = z.infer<typeof testEmailSchema>;

export function SmtpSettingsForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);
    const [isSendingTest, setIsSendingTest] = React.useState(false);

    const form = useForm<SmtpFormData>({
        resolver: zodResolver(smtpSettingsSchema),
        defaultValues: {
            server: '',
            smtpPort: 587,
            imapPort: 993,
            username: '',
            password: '',
            fromName: '',
            fromEmail: '',
        }
    });

    const testForm = useForm<TestEmailFormData>({
        resolver: zodResolver(testEmailSchema),
        defaultValues: { recipient: '' }
    });

    React.useEffect(() => {
        async function loadSettings() {
            setLoading(true);
            const settings = await getSmtpSettings();
            if (settings) {
                form.reset(settings);
            }
            setLoading(false);
        }
        loadSettings();
    }, [form]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: SmtpFormData) => {
        const result = await updateSmtpSettings(data);
        if (result.success) {
            toast({
                title: 'Settings Updated!',
                description: 'SMTP settings have been saved.',
            });
        } else {
            toast({
                variant: 'destructive',
                title: 'Failed to Save Settings',
                description: (result.errors as any)?._root?.[0] || 'An unknown error occurred.',
            });
        }
    }

    const handleSendTestEmail = async (data: TestEmailFormData) => {
        setIsSendingTest(true);
        const result = await sendTestEmail(data);
        if (result.success) {
            toast({
                title: 'Test Email Sent!',
                description: `An email has been sent to ${data.recipient}.`,
            });
        } else {
            toast({
                variant: 'destructive',
                title: 'Failed to Send Email',
                description: result.error || 'Please check your SMTP settings and try again.',
            });
        }
        setIsSendingTest(false);
    }
    
    if(loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                    <Skeleton className="h-4 w-3/4" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardHeader>
                        <div className='flex items-center gap-2'>
                            <Mail className="h-5 w-5" />
                            <CardTitle>Email (SMTP) Settings</CardTitle>
                        </div>
                        <CardDescription>
                           Configure the system email account for sending notifications and alerts.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <FormField
                            control={form.control}
                            name="server"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>SMTP Server</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., smtp.example.com" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <div className="grid grid-cols-2 gap-4">
                             <FormField
                                control={form.control}
                                name="smtpPort"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>SMTP Port</FormLabel>
                                        <FormControl><Input type="number" {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="imapPort"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>IMAP Port</FormLabel>
                                        <FormControl><Input type="number" {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                         <div className="grid grid-cols-2 gap-4">
                            <FormField
                                control={form.control}
                                name="fromName"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>From Name (Optional)</FormLabel>
                                        <FormControl><Input placeholder="e.g., Bestiller.com" {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="fromEmail"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>From Email Address</FormLabel>
                                        <FormControl><Input type="email" placeholder="e.g., no-reply@example.com" {...field} /></FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                         <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl><Input placeholder="Your email username" {...field} /></FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name="password"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Password</FormLabel>
                                    <FormControl><Input type="password" placeholder="••••••••" {...field} /></FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                    <CardFooter>
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save SMTP Settings
                        </Button>
                    </CardFooter>
                </form>
            </Form>
            <Separator className="my-6" />
            <CardHeader className="pt-0">
                <CardTitle className="text-base">Send a Test Email</CardTitle>
                <CardDescription>Verify your settings by sending a test message.</CardDescription>
            </CardHeader>
            <Form {...testForm}>
                <form onSubmit={testForm.handleSubmit(handleSendTestEmail)}>
                    <CardContent>
                         <FormField
                            control={testForm.control}
                            name="recipient"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Recipient Email</FormLabel>
                                    <div className="flex gap-2">
                                        <FormControl>
                                            <Input type="email" placeholder="recipient@example.com" {...field} />
                                        </FormControl>
                                         <Button type="submit" variant="secondary" disabled={isSendingTest}>
                                            {isSendingTest ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                                            Send
                                        </Button>
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </CardContent>
                </form>
            </Form>
        </Card>
    );
}

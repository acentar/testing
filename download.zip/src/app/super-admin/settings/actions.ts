
'use server';

import { z } from 'zod';
import admin from '@/lib/firebase-admin';
import { storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { revalidatePath } from 'next/cache';
import { getBusiness } from '../businesses/actions';
import { startOfMonth, getUnixTime, format } from 'date-fns';
import { Vonage } from '@vonage/server-sdk';
import { Auth } from '@vonage/auth';
import nodemailer from 'nodemailer';
import { generateSystemEmailHtml } from '@/lib/email-template';
import sharp from 'sharp';
import { smsAlertingSchema, storeSettingsSchema, type StoreSettingsFormData, invoicingSettingsSchema, InvoicingSettingsFormData } from './schema';
import type { Invoice } from '../invoices/schema';

async function streamToBuffer(stream: ReadableStream<Uint8Array>): Promise<Buffer> {
    const reader = stream.getReader();
    const chunks: Uint8Array[] = [];
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}


// --- General Platform Settings ---
const generalSettingsSchema = z.object({
    appName: z.string().min(2, "App name must be at least 2 characters."),
    appVersion: z.string().optional(),
});

async function handleFileUpload(file: File): Promise<string> {
    if (!file) return '';

    const buffer = await streamToBuffer(file.stream());
    const fileName = file.name.split('.')[0];
    let processedBuffer: Buffer;
    let contentType: string;
    let extension: string;

    if (file.type === 'audio/wav') {
        processedBuffer = buffer;
        contentType = 'audio/wav';
        extension = 'wav';
    } else if (file.type === 'image/svg+xml') {
        processedBuffer = buffer;
        contentType = 'image/svg+xml';
        extension = 'svg';
    } else if (file.type === 'image/png') {
        processedBuffer = await sharp(buffer).png({ quality: 80 }).toBuffer();
        contentType = 'image/png';
        extension = 'png';
    } else if (file.type === 'image/jpeg' || file.type === 'image/jpg') {
        processedBuffer = await sharp(buffer).jpeg({ quality: 80 }).toBuffer();
        contentType = 'image/jpeg';
        extension = 'jpg';
    } else if (file.type === 'image/webp') {
        processedBuffer = await sharp(buffer).webp({ quality: 80 }).toBuffer();
        contentType = 'image/webp';
        extension = 'webp';
    }
     else {
         processedBuffer = await sharp(buffer).webp({ quality: 80 }).toBuffer();
        contentType = 'image/webp';
        extension = 'webp';
        
    }

    const filePath = `uploads/settings/${Date.now()}_${fileName}.${extension}`;
    const fileStorageRef = storageRef(storage, filePath);

    const uploadResult = await uploadBytes(fileStorageRef, processedBuffer, { contentType });
    return getDownloadURL(uploadResult.ref);
}

export async function updateGeneralSettings(formData: FormData) {
    const jsonData = formData.get('jsonData') as string;
    if (!jsonData) {
        return { success: false, errors: { _root: ["Missing form data."] } };
    }
    const data = JSON.parse(jsonData);

    const validationResult = generalSettingsSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    const uploadedFiles: { [key: string]: string } = {};
    const fileFields = ['logo', 'favicon', 'adminLogo', 'staffKioskLogo', 'staffKioskBgImage', 'newBookingSound'];
    const urlMap: { [key: string]: string } = {
        logo: 'appLogoUrl',
        favicon: 'appFaviconUrl',
        adminLogo: 'adminLogoUrl',
        staffKioskLogo: 'staffKioskLogoUrl',
        staffKioskBgImage: 'staffKioskBgImageUrl',
        newBookingSound: 'newBookingSoundUrl',
    };

    for (const field of fileFields) {
        const file = formData.get(field) as File | null;
        if (file) {
            uploadedFiles[urlMap[field]] = await handleFileUpload(file);
        }
    }

    try {
        const settingsRef = admin.database().ref('globalSettings/general');
        await settingsRef.update({ ...validationResult.data, ...uploadedFiles });
        revalidatePath('/super-admin/settings');
        revalidatePath('/'); // Revalidate home page
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update general settings.'] } };
    }
}


// --- TextBee Device Management ---

const textbeeDeviceSchema = z.object({
  name: z.string().min(2, 'Device name must be at least 2 characters.'),
  apiKey: z.string().min(10, 'API Key is required.'),
  deviceId: z.string().min(5, 'Device ID is required.'),
});

export type TextbeeDevice = z.infer<typeof textbeeDeviceSchema> & { id: string };
export type TextbeeDeviceFormData = z.infer<typeof textbeeDeviceSchema>;

export async function getTextbeeDevices(): Promise<TextbeeDevice[]> {
    try {
        const devicesRef = admin.database().ref('globalSettings/textbeeDevices');
        const snapshot = await devicesRef.once('value');
        if (snapshot.exists()) {
            const devices: TextbeeDevice[] = [];
            snapshot.forEach(child => {
                devices.push({ id: child.key!, ...child.val() });
            });
            return devices.sort((a,b) => a.name.localeCompare(b.name));
        }
        return [];
    } catch (error) {
        console.error("Error fetching TextBee devices:", error);
        return [];
    }
}

export async function addTextbeeDevice(data: TextbeeDeviceFormData) {
    const validationResult = textbeeDeviceSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const devicesRef = admin.database().ref('globalSettings/textbeeDevices');
        const newDeviceRef = devicesRef.push();
        await newDeviceRef.set({ ...validationResult.data, createdAt: admin.database.ServerValue.TIMESTAMP });
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to add device.'] } };
    }
}

export async function updateTextbeeDevice(id: string, data: TextbeeDeviceFormData) {
    const validationResult = textbeeDeviceSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const deviceRef = admin.database().ref(`globalSettings/textbeeDevices/${id}`);
        await deviceRef.update({ ...validationResult.data, updatedAt: admin.database.ServerValue.TIMESTAMP });
        revalidatePath('/super-admin/settings');
        return { success: true, id };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update device.'] } };
    }
}


export async function deleteTextbeeDevice(id: string) {
    try {
        const deviceRef = admin.database().ref(`globalSettings/textbeeDevices/${id}`);
        await deviceRef.remove();
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to delete device.'] } };
    }
}


// --- Other Settings ---

const customSmsSchema = z.object({
  to: z.string().min(1, 'Recipient phone number is required.'),
  text: z.string().min(1, 'SMS content cannot be empty.'),
});

export async function sendCustomSms(data: z.infer<typeof customSmsSchema>) {
    const validationResult = customSmsSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        // Note: This assumes a default/global device for sending. 
        // This could be enhanced to allow selecting which device to send from.
        const smsClient = await getSmsClient('__global__', 'textbee');
        
        if (!smsClient) {
            return { success: false, errors: { _root: ['A default Textbee device is not configured in global settings.'] } };
        }
        
        await smsClient.send({ 
            to: validationResult.data.to, 
            text: validationResult.data.text,
            from: 'Bestiller' // This is not used by TextBee but required by the interface
        });

        return { success: true };
    } catch (error: any) {
        return { success: false, errors: { _root: [error.message || 'Failed to send SMS.'] } };
    }
}

// Domain Management Actions
const domainSchema = z.object({
  domain: z.string().min(3, 'Domain must be at least 3 characters long.').regex(/^[a-zA-Z0-9.-]+$/, 'Invalid domain format.'),
});

export async function getDomains(): Promise<{id: string, domain: string}[]> {
    try {
        const domainsRef = admin.database().ref('globalSettings/domains');
        const snapshot = await domainsRef.once('value');
        if (snapshot.exists()) {
            const domains: {id: string, domain: string}[] = [];
            snapshot.forEach(child => {
                domains.push({ id: child.key!, domain: child.val().domain });
            });
            return domains;
        }
        return [];
    } catch (error) {
        console.error("Error fetching domains:", error);
        return [];
    }
}

export async function addDomain(data: { domain: string }) {
    const validationResult = domainSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const domainsRef = admin.database().ref('globalSettings/domains');
        const newDomainRef = domainsRef.push();
        await newDomainRef.set({ domain: validationResult.data.domain, createdAt: admin.database.ServerValue.TIMESTAMP });
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to add domain.'] } };
    }
}

export async function deleteDomain(id: string) {
    try {
        const domainRef = admin.database().ref(`globalSettings/domains/${id}`);
        await domainRef.remove();
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to delete domain.'] } };
    }
}


// --- SMS Usage & Alerting ---

export async function getGlobalSettings() {
    try {
        const settingsRef = admin.database().ref('globalSettings');
        const snapshot = await settingsRef.once('value');
        if (snapshot.exists()) {
            return snapshot.val();
        }
        return {
            general: { appName: 'Bestiller.com', appVersion: '1.4.0' },
            sms: {
                monthlySmsCapacity: 1080,
                alertPhoneNumber: '',
                alertEmail: '',
            },
            smtp: {},
            store: {
                en: { currency: 'EUR', pricePerCalendar: 9, setupFee: 45, vatRate: 0 },
                da: { currency: 'DKK', pricePerCalendar: 69, setupFee: 350, vatRate: 0 },
                bs: { currency: 'BAM', pricePerCalendar: 15, setupFee: 80, vatRate: 0 },
            },
            invoicing: {},
        };
    } catch (error) {
        console.error("Error fetching global settings:", error);
        return {};
    }
}


export async function getGlobalSmsSettings() {
    try {
        const settingsRef = admin.database().ref('globalSettings/sms');
        const snapshot = await settingsRef.once('value');
        if (snapshot.exists()) {
            return snapshot.val();
        }
        return {
            monthlySmsCapacity: 1080,
            alertPhoneNumber: '',
            alertEmail: '',
        };
    } catch (error) {
        console.error("Error fetching global SMS settings:", error);
        return {};
    }
}

export async function updateGlobalSmsSettings(data: z.infer<typeof smsAlertingSchema>) {
    const validationResult = smsAlertingSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const settingsRef = admin.database().ref('globalSettings/sms');
        await settingsRef.update(validationResult.data);

        // Trigger an alert check after updating settings
        await checkSmsCapacityAndAlert();

        revalidatePath('/super-admin/settings');
        revalidatePath('/super-admin/reports');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update settings.'] } };
    }
}

export async function checkSmsCapacityAndAlert() {
    const settings = await getGlobalSmsSettings();
    if (!settings.alertPhoneNumber && !settings.alertEmail) {
        return; // No one to alert
    }

    const now = new Date();
    const startOfCurrentMonth = startOfMonth(now);
    const startOfCurrentMonthUnix = getUnixTime(startOfCurrentMonth) * 1000;

    const logsRef = admin.database().ref('sms_logs');
    const q = logsRef.orderByChild('timestamp').startAt(startOfCurrentMonthUnix);
    const snapshot = await q.once('value');

    const currentMonthUsage = snapshot.exists() ? snapshot.numChildren() : 0;
    const remainingSms = settings.monthlySmsCapacity - currentMonthUsage;
    const globalSettings = await getGlobalSettings();
    const appName = globalSettings.general?.appName || 'Bestiller.com';

    if (remainingSms < 100) {
        const alertSentRef = admin.database().ref(`globalSettings/sms/alerts/${format(now, 'yyyy-MM')}`);
        const alertSnapshot = await alertSentRef.once('value');
        if (!alertSnapshot.exists()) { // Only send once per month
            const message = `${appName} Alert: SMS capacity is low. Remaining: ${remainingSms}. Used this month: ${currentMonthUsage}. Capacity: ${settings.monthlySmsCapacity}.`;
            if (settings.alertPhoneNumber) {
                const smsClient = await getSmsClient('__global__', 'textbee');
                if (smsClient) {
                    await smsClient.send({ to: settings.alertPhoneNumber, from: 'Bestiller', text: message });
                }
            }
            if (settings.alertEmail) {
                const emails = settings.alertEmail.split(',').map((e: string) => e.trim()).filter(Boolean);
                if (emails.length > 0) {
                     await sendSystemEmail(
                        emails,
                        'Low SMS Capacity Alert',
                        `<p>This is an automated alert to inform you that your system-wide SMS capacity is running low.</p>
                         <ul>
                           <li>Monthly Capacity: <strong>${settings.monthlySmsCapacity}</strong></li>
                           <li>SMS Used This Month: <strong>${currentMonthUsage}</strong></li>
                           <li>Remaining SMS: <strong>${remainingSms}</strong></li>
                         </ul>
                         <p>Please top up your SMS provider account to avoid service interruptions.</p>`,
                         undefined,
                         undefined,
                         appName
                    );
                }
            }
            await alertSentRef.set({ timestamp: admin.database.ServerValue.TIMESTAMP });
        }
    }
}

// --- Store Settings ---
export async function updateStoreSettings(data: StoreSettingsFormData) {
    const validationResult = storeSettingsSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const settingsRef = admin.database().ref('globalSettings/store');
        await settingsRef.update(validationResult.data);
        revalidatePath('/super-admin/settings');
        revalidatePath('/order');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update store settings.'] } };
    }
}

// --- Invoicing Settings ---
export async function updateInvoicingSettings(data: InvoicingSettingsFormData) {
    const validationResult = invoicingSettingsSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const settingsRef = admin.database().ref('globalSettings/invoicing');
        await settingsRef.update(validationResult.data);
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update invoicing settings.'] } };
    }
}


// --- SMS Client Factory ---

async function logSms(businessId: string, provider: string, status: 'sent' | 'failed') {
    const logRef = admin.database().ref('sms_logs');
    const newLogRef = logRef.push();
    await newLogRef.set({
        businessId: businessId,
        provider: provider,
        status: status,
        timestamp: admin.database.ServerValue.TIMESTAMP
    });
}

export interface SmsClient {
    send(params: { to: string; from: string; text: string }): Promise<any>;
}

class VonageSmsClient implements SmsClient {
    private vonage: Vonage;
    private businessId: string;
    constructor(apiKey: string, apiSecret: string, businessId: string) {
        const credentials = new Auth({ apiKey, apiSecret });
        this.vonage = new Vonage(credentials);
        this.businessId = businessId;
    }
    async send(params: { to: string; from: string; text: string }): Promise<any> {
        try {
            const result = await this.vonage.sms.send(params);
            await logSms(this.businessId, 'vonage', 'sent');
            return result;
        } catch (error) {
            await logSms(this.businessId, 'vonage', 'failed');
            throw error;
        }
    }
}

class TextBeeSmsClient implements SmsClient {
    private apiKey: string;
    private deviceId: string;
    private businessId: string;

    constructor(apiKey: string, deviceId: string, businessId: string) {
        this.apiKey = apiKey;
        this.deviceId = deviceId;
        this.businessId = businessId;
    }

    async send(params: { to: string; from: string; text: string }): Promise<any> {
        try {
            const response = await fetch(`https://api.textbee.dev/api/v1/gateway/devices/${this.deviceId}/send-sms`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': this.apiKey,
                },
                body: JSON.stringify({
                    recipients: [params.to],
                    message: params.text,
                }),
            });
            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.message || 'TextBee API request failed');
            }
            await logSms(this.businessId, 'textbee', 'sent');
            return result;
        } catch (error) {
            await logSms(this.businessId, 'textbee', 'failed');
            throw error;
        }
    }
}


export async function getSmsClient(businessId: string, providerOverride?: 'vonage' | 'textbee'): Promise<SmsClient | null> {
    const business = businessId === '__global__' ? null : await getBusiness(businessId);
    const globalSettings = await getGlobalSettings();
    const provider = providerOverride || business?.smsProvider || 'vonage'; // Default to Vonage

    if (provider === 'vonage') {
        let apiKey = business?.vonageApiKey || globalSettings.sms?.vonageApiKey || process.env.VONAGE_API_KEY;
        let apiSecret = business?.vonageApiSecret || globalSettings.sms?.vonageApiSecret || process.env.VONAGE_API_SECRET;

        if (!apiKey || !apiSecret) {
            return null;
        }
        return new VonageSmsClient(apiKey, apiSecret, businessId);
    }

    if (provider === 'textbee') {
        const allDevices = globalSettings.textbeeDevices ? Object.values(globalSettings.textbeeDevices) as TextbeeDevice[] : [];
        let deviceToUse: TextbeeDevice | undefined = undefined;
        
        if (business?.textbeeDeviceId) {
            deviceToUse = allDevices.find(d => d.id === business.textbeeDeviceId);
        }
        
        if (!deviceToUse && allDevices.length > 0) {
            deviceToUse = allDevices[0]; // Fallback to first available global device
        }

        if (deviceToUse) {
            return new TextBeeSmsClient(deviceToUse.apiKey, deviceToUse.deviceId, businessId);
        }
    }

    return null;
}

// --- SMTP Settings ---
const smtpSettingsSchema = z.object({
  server: z.string().min(1, "Server is required."),
  smtpPort: z.coerce.number().int().positive("SMTP Port must be a positive number."),
  imapPort: z.coerce.number().int().positive("IMAP Port must be a positive number."),
  username: z.string().min(1, "Username is required."),
  password: z.string().min(1, "Password is required."),
  fromName: z.string().optional(),
  fromEmail: z.string().email("Please enter a valid 'From' email."),
});

export async function getSmtpSettings() {
    try {
        const settingsRef = admin.database().ref('globalSettings/smtp');
        const snapshot = await settingsRef.once('value');
        return snapshot.exists() ? snapshot.val() : {};
    } catch (error) {
        console.error("Error fetching SMTP settings:", error);
        return {};
    }
}

export async function updateSmtpSettings(data: z.infer<typeof smtpSettingsSchema>) {
    const validationResult = smtpSettingsSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }
    try {
        const settingsRef = admin.database().ref('globalSettings/smtp');
        await settingsRef.update(validationResult.data);
        revalidatePath('/super-admin/settings');
        return { success: true };
    } catch (error) {
        return { success: false, errors: { _root: ['Failed to update SMTP settings.'] } };
    }
}

const testEmailSchema = z.object({
  recipient: z.string().email("Please enter a valid recipient email."),
});

export async function sendSystemEmail(to: string | string[], subject: string, body: string, cta?: { text: string; link: string; }, invoice?: Invoice, appName?: string, language: 'en' | 'bs' | 'da' = 'bs') {
    const smtpSettings = await getSmtpSettings();
    
    if (!smtpSettings.server || !smtpSettings.fromEmail) {
        throw new Error('SMTP settings are not configured.');
    }
    
    const globalSettings = await getGlobalSettings();
    const finalAppName = appName || globalSettings.general?.appName || 'Bestiller.com';


    const transporter = nodemailer.createTransport({
        host: smtpSettings.server,
        port: smtpSettings.smtpPort,
        secure: smtpSettings.smtpPort === 465,
        auth: {
            user: smtpSettings.username,
            pass: smtpSettings.password,
        },
    });

    const emailHtml = generateSystemEmailHtml({
        title: subject,
        body: body,
        cta: cta,
        logoUrl: globalSettings.general?.appLogoUrl,
        invoice: invoice,
        appName: finalAppName,
        language: language,
    });

    await transporter.sendMail({
        from: `"${smtpSettings.fromName || finalAppName}" <${smtpSettings.fromEmail}>`,
        to: Array.isArray(to) ? to.join(', ') : to,
        subject: `${finalAppName} - ${subject}`,
        html: emailHtml,
    });
}

export async function sendTestEmail(data: z.infer<typeof testEmailSchema>) {
    const validationResult = testEmailSchema.safeParse(data);
    if (!validationResult.success) {
        return { success: false, errors: validationResult.error.flatten().fieldErrors };
    }

    try {
        await sendSystemEmail(
            validationResult.data.recipient,
            'SMTP Configuration Test',
            `<p>This is a test email to confirm that your SMTP settings are configured correctly.</p>
             <p>If you have received this, no further action is required.</p>`,
            undefined
        );
        return { success: true };
    } catch(error: any) {
        console.error("Error sending test email:", error);
        return { success: false, error: error.message || 'Failed to send test email.' };
    }
}



    

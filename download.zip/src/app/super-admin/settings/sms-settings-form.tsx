
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import {
  getTextbeeDevices,
  addTextbeeDevice,
  updateTextbeeDevice,
  deleteTextbeeDevice,
  type TextbeeDevice,
  type TextbeeDeviceFormData,
} from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, MessageSquare, PlusCircle, Trash2, Edit } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const textbeeDeviceSchema = z.object({
  name: z.string().min(2, 'Device name must be at least 2 characters.'),
  apiKey: z.string().min(10, 'API Key is required.'),
  deviceId: z.string().min(5, 'Device ID is required.'),
});

interface DeviceFormDialogProps {
  device?: TextbeeDevice;
  onSave: () => void;
  children: React.ReactNode;
}

function DeviceFormDialog({ device, onSave, children }: DeviceFormDialogProps) {
  const [open, setOpen] = React.useState(false);
  const { toast } = useToast();
  const isEditMode = !!device;
  const form = useForm<TextbeeDeviceFormData>({
    resolver: zodResolver(textbeeDeviceSchema),
    defaultValues: {
      name: '',
      apiKey: '',
      deviceId: '',
    },
  });
  
  React.useEffect(() => {
    if (open) {
        form.reset(
          device
            ? { name: device.name, apiKey: device.apiKey, deviceId: device.deviceId }
            : { name: '', apiKey: '', deviceId: '' }
        );
    }
  }, [open, device, form]);

  const onSubmit = async (data: TextbeeDeviceFormData) => {
    const result = isEditMode
      ? await updateTextbeeDevice(device.id, data)
      : await addTextbeeDevice(data);
    
    if (result.success) {
        toast({ title: `Device ${isEditMode ? 'updated' : 'added'} successfully!` });
        setOpen(false);
        onSave();
    } else {
        toast({ variant: 'destructive', title: 'Error saving device', description: (result.errors as any)?._root?.[0] || 'An unknown error occurred.' });
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>{children}</DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Edit' : 'Add'} TextBee Device</DialogTitle>
          </DialogHeader>
           <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                          <FormItem>
                              <FormLabel>Device Name</FormLabel>
                              <FormControl><Input placeholder="e.g., Main Android Phone" {...field} /></FormControl>
                              <FormMessage />
                          </FormItem>
                      )}
                  />
                  <FormField
                      control={form.control}
                      name="apiKey"
                      render={({ field }) => (
                          <FormItem>
                              <FormLabel>API Key</FormLabel>
                              <FormControl><Input placeholder="Your TextBee API Key" {...field} /></FormControl>
                              <FormMessage />
                          </FormItem>
                      )}
                  />
                  <FormField
                      control={form.control}
                      name="deviceId"
                      render={({ field }) => (
                          <FormItem>
                              <FormLabel>Device ID</FormLabel>
                              <FormControl><Input placeholder="Your TextBee Device ID" {...field} /></FormControl>
                              <FormMessage />
                          </FormItem>
                      )}
                  />
                   <DialogFooter className="pt-4">
                      <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
                      <Button type="submit" disabled={form.formState.isSubmitting}>
                          {form.formState.isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                          Save Device
                      </Button>
                  </DialogFooter>
              </form>
           </Form>
        </DialogContent>
    </Dialog>
  );
}


export function SmsSettingsForm() {
    const [loading, setLoading] = React.useState(true);
    const [devices, setDevices] = React.useState<TextbeeDevice[]>([]);
    const { toast } = useToast();

    const loadDevices = React.useCallback(async () => {
        setLoading(true);
        const fetchedDevices = await getTextbeeDevices();
        setDevices(fetchedDevices);
        setLoading(false);
    }, []);

    React.useEffect(() => {
        loadDevices();
    }, [loadDevices]);

    const handleDelete = async (id: string, name: string) => {
        const result = await deleteTextbeeDevice(id);
        if (result.success) {
            toast({ title: 'Device Removed!', description: `The device "${name}" has been removed.` });
            loadDevices();
        } else {
            toast({ variant: 'destructive', title: 'Failed to Remove Device', description: (result.errors as any)?._root?.[0] || 'An unknown error occurred.' });
        }
    };
    
    if (loading) {
        return (
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-4 w-2/3" />
                </CardHeader>
                <CardContent className="space-y-4">
                    <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader>
                <div className='flex items-center gap-2'>
                    <MessageSquare className="h-5 w-5" />
                    <CardTitle>TextBee.dev Device Management</CardTitle>
                </div>
                <CardDescription>
                    Configure TextBee devices that businesses can use to send SMS.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {devices.length > 0 ? (
                    <ul className="space-y-2">
                        {devices.map(device => (
                            <li key={device.id} className="flex items-center justify-between rounded-md border p-3">
                                <div>
                                    <p className="font-medium">{device.name}</p>
                                    <p className="text-sm text-muted-foreground">Device ID: {device.deviceId}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                     <DeviceFormDialog device={device} onSave={loadDevices}>
                                        <Button variant="ghost" size="icon"><Edit className="h-4 w-4" /></Button>
                                    </DeviceFormDialog>
                                    <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                            <Button variant="ghost" size="icon"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                            <AlertDialogHeader>
                                                <AlertDialogTitle>Delete "{device.name}"?</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                    This action cannot be undone. Businesses using this device will no longer be able to send SMS.
                                                </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                <AlertDialogAction onClick={() => handleDelete(device.id, device.name)}>Delete</AlertDialogAction>
                                            </AlertDialogFooter>
                                        </AlertDialogContent>
                                    </AlertDialog>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-sm text-muted-foreground text-center py-4">No TextBee devices configured yet.</p>
                )}
            </CardContent>
            <CardFooter>
                <DeviceFormDialog onSave={loadDevices}>
                    <Button>
                        <PlusCircle className="mr-2 h-4 w-4" /> Add New Device
                    </Button>
                </DeviceFormDialog>
            </CardFooter>
        </Card>
    );
}

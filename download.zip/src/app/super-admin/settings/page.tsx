
import { SmsSettingsForm } from "./sms-settings-form";
import { SendSmsForm } from "./send-sms-form";
import { Separator } from "@/components/ui/separator";
import { DomainSettingsForm } from "./domain-settings-form";
import { SmsAlertingForm } from "./sms-alerting-form";
import { SmtpSettingsForm } from "./smtp-settings-form";
import { GeneralSettingsForm } from "./general-settings-form";
import { StoreSettingsForm } from "./store-settings-form";
import { InvoicingSettingsForm } from "./invoicing-settings-form";

export default function SuperAdminSettingsPage() {
  return (
     <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Global Settings</h2>
          <p className="text-muted-foreground">
            Manage platform-wide settings and tools.
          </p>
        </div>
      </div>
      <div className="pt-4 space-y-8">
        <GeneralSettingsForm />
        <Separator />
        <StoreSettingsForm />
        <Separator />
        <InvoicingSettingsForm />
        <Separator />
        <div className="grid md:grid-cols-2 gap-8">
          <DomainSettingsForm />
          <SmsAlertingForm />
        </div>
        <Separator />
        <SmtpSettingsForm />
        <Separator />
        <SmsSettingsForm />
        <Separator />
        <SendSmsForm />
      </div>
    </>
  );
}

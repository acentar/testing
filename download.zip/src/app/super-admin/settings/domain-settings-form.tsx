
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { getDomains, addDomain, deleteDomain } from './actions';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Globe, PlusCircle, Trash2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const domainSchema = z.object({
  domain: z.string().min(3, 'Domain must be at least 3 characters long.').regex(/^[a-zA-Z0-9.-]+$/, 'Invalid domain format.'),
});

type DomainFormData = z.infer<typeof domainSchema>;

export function DomainSettingsForm() {
    const { toast } = useToast();
    const [loading, setLoading] = React.useState(true);
    const [domains, setDomains] = React.useState<{id: string, domain: string}[]>([]);

    const form = useForm<DomainFormData>({
        resolver: zodResolver(domainSchema),
        defaultValues: {
            domain: '',
        }
    });

    const loadDomains = React.useCallback(async () => {
        setLoading(true);
        const fetchedDomains = await getDomains();
        setDomains(fetchedDomains);
        setLoading(false);
    }, []);

    React.useEffect(() => {
        loadDomains();
    }, [loadDomains]);

    const { isSubmitting } = form.formState;

    const onSubmit = async (data: DomainFormData) => {
        const result = await addDomain(data);
        if (result.success) {
            toast({
                title: 'Domain Added!',
                description: `The domain "${data.domain}" is now available for businesses.`,
            });
            form.reset();
            loadDomains();
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Add Domain',
                description: errorMessage,
            });
        }
    }

    const handleDelete = async (id: string, domainName: string) => {
        const result = await deleteDomain(id);
         if (result.success) {
            toast({
                title: 'Domain Removed!',
                description: `The domain "${domainName}" has been removed.`,
            });
            loadDomains();
        } else {
            const errorMessage = (result.errors as any)?._root?.[0] || 'An unknown error occurred.';
            toast({
                variant: 'destructive',
                title: 'Failed to Remove Domain',
                description: errorMessage,
            });
        }
    }

    return (
        <Card>
            <CardHeader>
                <div className='flex items-center gap-2'>
                    <Globe className="h-5 w-5" />
                    <CardTitle>Domain Management</CardTitle>
                </div>
                <CardDescription>
                    Configure domains that businesses can use for their subdomains.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div>
                    <h4 className="font-medium mb-2">Available Domains</h4>
                    {loading ? (
                         <div className="space-y-2">
                            <Skeleton className="h-10 w-full" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                    ) : domains.length > 0 ? (
                        <ul className="space-y-2">
                            {domains.map(d => (
                                <li key={d.id} className="flex items-center justify-between rounded-md border p-2 pl-4">
                                    <span className="font-mono">{d.domain}</span>
                                    <Button variant="ghost" size="icon" onClick={() => handleDelete(d.id, d.domain)}>
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-muted-foreground text-center py-4">No domains configured yet.</p>
                    )}
                </div>
                
                 <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-end gap-2">
                        <FormField
                            control={form.control}
                            name="domain"
                            render={({ field }) => (
                                <FormItem className="flex-1">
                                    <FormLabel>Add New Domain</FormLabel>
                                    <FormControl>
                                        <Input placeholder="e.g., bestiller.com" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                         <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                            Add
                        </Button>
                    </form>
                </Form>
            </CardContent>
            <CardFooter>
                <p className="text-xs text-muted-foreground">
                    Note: For subdomains to work, you must configure a wildcard DNS record (e.g., `*.yourdomain.com`) to point to your application server.
                </p>
            </CardFooter>
        </Card>
    );
}


'use client';

import Link from 'next/link';
import { usePathname, useParams } from 'next/navigation';

import { cn } from '@/lib/utils';
import { SidebarMenu, SidebarMenuItem, SidebarMenuButton } from '@/components/ui/sidebar';
import { LayoutDashboard, Building, Users, Book, BarChart, Settings, ShoppingCart, Image as ImageIcon } from 'lucide-react';
import * as React from 'react';

export function SuperAdminNav({
  className,
  ...props
}: React.HTMLAttributes<HTMLElement>) {
  const pathname = usePathname();
  const params = useParams();
  
  const mainRoutes = [
    { href: '/super-admin', label: 'Dashboard', icon: <LayoutDashboard /> },
    { href: '/super-admin/businesses', label: 'Businesses', icon: <Building /> },
    { href: '/super-admin/orders', label: 'Orders', icon: <ShoppingCart /> },
    { href: '/super-admin/customers', label: 'Customers', icon: <Users /> },
    { href: '/super-admin/bookings', label: 'Bookings', icon: <Book /> },
    { href: '/super-admin/media', label: 'Media', icon: <ImageIcon /> },
    { href: '/super-admin/reports', label: 'Reports', icon: <BarChart /> },
    { href: '/super-admin/users', label: 'User Management', icon: <Users /> },
    { href: '/super-admin/settings', label: 'Settings', icon: <Settings /> },
  ];

  return (
    <SidebarMenu className={cn(className)} {...props}>
      {mainRoutes.map((route) => (
        <SidebarMenuItem key={route.href}>
          <SidebarMenuButton 
            asChild 
            isActive={
              (pathname === route.href) || 
              (pathname.startsWith(route.href) && route.href !== '/super-admin')
            }
          >
            <Link href={route.href}>
              {route.icon}
              {route.label}
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );
}

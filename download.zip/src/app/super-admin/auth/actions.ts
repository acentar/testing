
'use server';

import { cookies } from 'next/headers';
import admin from '@/lib/firebase-admin';
import type { AdminUser } from '../users/actions';

// This is a simplified server action.
// In a real app, you would fetch user data from a database.
export async function signInWithEmailAndPassword(idToken: string) {
    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        const { uid } = decodedToken;
        
        const adminsRef = admin.database().ref('admins');
        const snapshot = await adminsRef.orderByChild('uid').equalTo(uid).once('value');

        if (!snapshot.exists()) {
             return { success: false, error: "You do not have permission to access this area." };
        }
        
        const adminData = Object.values(snapshot.val())[0] as any;
        const role = adminData.role;

        // Final check to ensure only superadmins can access this panel
        if (role !== 'superadmin') {
            return { success: false, error: "You do not have permission to access this area." };
        }

        // The session cookie logic is now handled by the API route.
        // This action just confirms the user is valid.
        return { success: true };
    } catch (error: any) {
        console.error("Sign-in server action error:", error);
        return { success: false, error: 'Authentication failed on the server.' };
    }
}

export async function signOut() {
  const cookieStore = cookies();
  cookieStore.delete('firebase-auth-token');
}

export async function getAdminUser(uid: string): Promise<AdminUser | null> {
    try {
        const adminsRef = admin.database().ref('admins');
        const snapshot = await adminsRef.orderByChild('uid').equalTo(uid).once('value');
        if (snapshot.exists()) {
            const adminData = snapshot.val();
            const adminId = Object.keys(adminData)[0];
            return { id: adminId, ...adminData[adminId] };
        }
        return null;
    } catch (error) {
        console.error('Error fetching admin user:', error);
        return null;
    }
}

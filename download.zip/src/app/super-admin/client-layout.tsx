
'use client';

import * as React from 'react';
import Link from 'next/link';
import { SuperAdminNav } from './super-admin-nav';
import { Sidebar, SidebarContent, SidebarHeader, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { SuperAdminBreadcrumb } from './super-admin-breadcrumb';
import Image from 'next/image';
import { Loader2, LogOut, User as UserIcon, ChevronDown } from 'lucide-react';
import { AuthProvider, useAuth } from './auth/provider';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getAuth } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { useRouter, usePathname } from 'next/navigation';

function UserMenu() {
    const { user, adminUser } = useAuth();
    const router = useRouter();

    const handleSignOut = async () => {
        const auth = getAuth(app);
        try {
            await auth.signOut();
            await fetch('/api/auth/session/sign-out', { method: 'POST' });
            router.push('/super-admin/login');
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };

    if (!user) {
        return null;
    }

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 h-10">
                     <Avatar className="h-8 w-8">
                        <AvatarImage src={user.photoURL ?? undefined} alt={user.displayName || user.email || 'User'} />
                        <AvatarFallback>{(adminUser?.name || user.email || 'A').charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                     <div className="text-left hidden sm:block">
                        <p className="text-sm font-medium leading-none">{adminUser?.name || 'Super Admin'}</p>
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{adminUser?.name || 'Super Admin'}</p>
                        <p className="text-xs leading-none text-muted-foreground">
                            {user.email}
                        </p>
                    </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}


function SuperAdminLayoutContent({ children, globalSettings }: { children: React.ReactNode, globalSettings: any }) {
    const { loading: authLoading } = useAuth();
    const pathname = usePathname();

    const appName = globalSettings.appName || 'Bestiller.com';
    const appLogoUrl = globalSettings.adminLogoUrl || globalSettings.appLogoUrl;
    const appVersion = globalSettings.appVersion || '1.4.0';
    
    const isLoginPage = pathname === '/super-admin/login';
    const isBusinessSpecificPage = /^\/super-admin\/businesses\/[^/]+/.test(pathname);


    if (authLoading) {
        return (
            <div className="flex h-screen w-full items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin" />
            </div>
        )
    }

    if (isLoginPage) {
        return <>{children}</>;
    }

    if (isBusinessSpecificPage) {
        // Business-specific layout doesn't need the main sidebar
        return (
             <div className="flex min-h-screen">
                <div className="flex flex-1 flex-col">
                    <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
                        <div className="w-full flex-1 flex justify-end">
                            <UserMenu />
                        </div>
                    </header>
                    <main className="flex-1">
                        {children}
                    </main>
                </div>
            </div>
        )
    }


    return (
        <SidebarProvider>
            <div className="flex min-h-screen">
            <Sidebar>
                <SidebarContent>
                    <SidebarHeader className='p-4'>
                        <Link href="/super-admin" className="relative h-12 w-full">
                            {appLogoUrl ? (
                                <Image src={appLogoUrl ?? ''} alt={`${appName} logo`} fill className="object-contain object-left" priority unoptimized />
                            ) : (
                                <div className="text-lg font-semibold">{appName}</div>
                            )}
                        </Link>
                    </SidebarHeader>
                    <SuperAdminNav />
                </SidebarContent>
            </Sidebar>
            <div className="flex flex-1 flex-col">
                <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
                    <SidebarTrigger className='sm:hidden' />
                    <div className="w-full flex-1 flex justify-end">
                      <UserMenu />
                    </div>
                </header>
                <main className="flex-1 space-y-4 p-4 pt-6 md:p-8">
                    <SuperAdminBreadcrumb />
                    {children}
                </main>
                <footer className="text-center p-4 text-muted-foreground" style={{ fontSize: '12px' }}>
                    Version: {appVersion}
                </footer>
            </div>
        </div>
        </SidebarProvider>
    )
}

export default function SuperAdminClientLayout({ children, globalSettings }: { children: React.ReactNode, globalSettings: any }) {
    return (
        <AuthProvider>
            <SuperAdminLayoutContent globalSettings={globalSettings}>{children}</SuperAdminLayoutContent>
        </AuthProvider>
    );
}

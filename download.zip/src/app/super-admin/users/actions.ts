
'use server';

import { z } from 'zod';
import admin from '@/lib/firebase-admin';
import { revalidatePath } from 'next/cache';

const adminUserSchema = z.object({
  id: z.string().optional(),
  uid: z.string().optional(),
  email: z.string().email(),
  name: z.string().optional(),
  role: z.enum(['superadmin', 'business_admin']).default('business_admin'),
  assignedBusinesses: z.array(z.string()).optional(),
  // For creation only
  password: z.string().min(6, "Password must be at least 6 characters.").optional(),
});

export type AdminUserFormData = z.infer<typeof adminUserSchema>;
export type AdminUser = Omit<AdminUserFormData, 'password'> & { id: string, uid?: string };

async function createAuthUser(email: string, password?: string) {
    try {
        const user = await admin.auth().createUser({ email, password });
        return { success: true, user };
    } catch (error: any) {
        if (error.code === 'auth/email-already-exists') {
            return { success: false, error: 'A user with this email already exists in Firebase Authentication.' };
        }
        return { success: false, error: error.message };
    }
}


async function updateUserPassword(uid: string, password?: string) {
    if (!password) return;
    await admin.auth().updateUser(uid, { password });
}

async function deleteAuthUser(uid: string) {
    try {
        await admin.auth().deleteUser(uid);
    } catch(error: any) {
        if (error.code === 'auth/user-not-found') {
            console.warn(`User with uid ${uid} not found in Firebase Auth. Proceeding with DB deletion.`);
            return;
        }
        throw error;
    }
}

export async function getUsers(): Promise<AdminUser[]> {
  try {
    const adminsRef = admin.database().ref('admins');
    const snapshot = await adminsRef.once('value');
    if (!snapshot.exists()) {
        return [];
    }

    const usersFromDb: AdminUser[] = [];
    snapshot.forEach((childSnapshot) => {
        usersFromDb.push({ id: childSnapshot.key!, ...childSnapshot.val() });
    });
    
    return usersFromDb.sort((a,b) => (a.name || a.email).localeCompare(b.name || b.email));

  } catch (error: any) {
    console.error("Error fetching users:", error);
    if (error.code === 'PERMISSION_DENIED') {
         throw new Error("Server does not have permission to access the database. Check service account credentials.");
    }
    return [];
  }
}

export async function addUser(data: AdminUserFormData) {
    const validationResult = adminUserSchema.safeParse(data);
    
  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }
  
  const { email, password, role, assignedBusinesses, name } = validationResult.data;

  try {
    const existingUserByEmail = await admin.database().ref('admins').orderByChild('email').equalTo(email).once('value');
    if (existingUserByEmail.exists()) {
        return { success: false, errors: { email: ["A user with this email already exists in the database."] } };
    }

    if (!password) {
        return { success: false, errors: { password: ["Password is required to create a new user."] } };
    }
    
    const authResult = await createAuthUser(email, password);
    if (!authResult.success) {
        return { success: false, errors: { email: [authResult.error!] } };
    }
    const authUid = authResult.user.uid;
    const authEmail = authResult.user.email!;
    
    // Set custom claims
    await admin.auth().setCustomUserClaims(authUid, { role, admin: role === 'superadmin' });

    const adminsRef = admin.database().ref('admins');
    const newAdminRef = await adminsRef.push();
    
    await newAdminRef.set({
      uid: authUid,
      email: authEmail,
      name: name || '',
      role,
      assignedBusinesses: role === 'superadmin' ? [] : (assignedBusinesses || []),
      createdAt: new Date().toISOString(),
    });

    revalidatePath('/super-admin/users');
    return { success: true };
  } catch (error: any) {
    return { success: false, errors: { _root: [error.message || 'Failed to add user.'] } };
  }
}

// Helper schema for edit mode where password is not required
const editUserSchema = adminUserSchema.partial().extend({
    password: z.string().min(6, "Password must be at least 6 characters.").optional().or(z.literal('')),
});


export async function updateUser(id: string, data: Partial<AdminUserFormData>) {
  const validationResult = editUserSchema.safeParse(data);
  
  if (!validationResult.success) {
    return { success: false, errors: validationResult.error.flatten().fieldErrors };
  }
  
  const { password, role, ...userData } = validationResult.data;

  try {
    const adminRef = admin.database().ref(`admins/${id}`);
    const snapshot = await adminRef.once('value');
    if (!snapshot.exists()) {
        return { success: false, errors: { _root: ['User not found.'] } };
    }
    
    const existingUser = snapshot.val();
    
    if (password) {
      await updateUserPassword(existingUser.uid, password);
    }
    
    const updatePayload: any = { ...userData };
    if (role) {
        await admin.auth().setCustomUserClaims(existingUser.uid, { role, admin: role === 'superadmin' });
        updatePayload.role = role;
    }

    if (updatePayload.role === 'superadmin') {
        updatePayload.assignedBusinesses = [];
    }

    await adminRef.update({
        ...updatePayload,
        updatedAt: new Date().toISOString()
    });

    revalidatePath('/super-admin/users');
    return { success: true };
  } catch (error: any) {
    return { success: false, errors: { _root: [error.message || 'Failed to update user.'] } };
  }
}

export async function deleteUser(id: string) {
    try {
        const adminRef = admin.database().ref(`admins/${id}`);
        const snapshot = await adminRef.once('value');
        if (!snapshot.exists()) {
            return { success: false, error: 'User not found in database.' };
        }
        
        const user = snapshot.val();
        await deleteAuthUser(user.uid);
        await adminRef.remove();

        revalidatePath('/super-admin/users');
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message || 'Failed to delete user.' };
    }
}

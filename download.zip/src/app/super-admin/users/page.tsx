
import * as React from 'react';
import { UsersClientPage } from './client-page';
import { getUsers } from './actions';
import { getBusinesses } from '../businesses/actions';

export default async function SuperAdminUsersPage() {
  const [users, businesses] = await Promise.all([
    getUsers(),
    getBusinesses()
  ]);

  return (
     <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">User management</h2>
          <p className="text-muted-foreground">
            Invite, edit, and manage user permissions for the platform.
          </p>
        </div>
      </div>
      <UsersClientPage initialUsers={users} allBusinesses={businesses} />
    </>
  );
}

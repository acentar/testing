
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { addUser, updateUser, type AdminUser, type AdminUserFormData } from './actions';
import { type Business } from '../businesses/actions';
import { Loader2 } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';

const userFormSchema = z.object({
  email: z.string().email('Please enter a valid email address.'),
  name: z.string().optional(),
  password: z.string().optional(),
  role: z.enum(['superadmin', 'business_admin']).default('business_admin'),
  assignedBusinesses: z.array(z.string()).optional(),
  uid: z.string().optional(),
});

interface UserFormDialogProps {
  user?: AdminUser | null;
  allBusinesses: Business[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: () => void;
}

export function UserFormDialog({ user, allBusinesses, open, onOpenChange, onSave }: UserFormDialogProps) {
  const { toast } = useToast();
  const isEditMode = !!user;

  const form = useForm<AdminUserFormData>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      email: '',
      name: '',
      password: '',
      role: 'business_admin',
      assignedBusinesses: [],
      uid: '',
    },
  });

  React.useEffect(() => {
    if (open) {
      if (user) {
        form.reset({
          email: user.email,
          name: user.name || '',
          password: '',
          role: user.role,
          assignedBusinesses: user.assignedBusinesses || [],
          uid: user.uid,
        });
      } else {
        form.reset({
          email: '',
          name: '',
          password: '',
          role: 'business_admin',
          assignedBusinesses: [],
          uid: '',
        });
      }
    }
  }, [user, open, form]);
  
  const watchRole = form.watch('role');

  const { isSubmitting } = form.formState;

  const onSubmit = async (data: AdminUserFormData) => {
    let result;
    if (isEditMode) {
        if (!data.password) {
            delete data.password;
        }
        result = await updateUser(user.id, data);
    } else {
        if (!data.password && !data.uid) {
             form.setError('password', { message: 'Password is required if no UID is provided.' });
             return;
        }
        result = await addUser(data);
    }

    if (result.success) {
      toast({
        title: `User ${isEditMode ? 'updated' : 'added'} successfully`,
        description: `${isEditMode ? 'Details for' : 'An account has been created for'} ${data.email}.`,
      });
      onSave();
    } else {
      const formErrors = result.errors as any;
      if (formErrors) {
        Object.entries(formErrors).forEach(([key, value]) => {
            form.setError(key as keyof AdminUserFormData, { message: (value as string[])[0] });
        });
      }
      toast({
        variant: 'destructive',
        title: `Error ${isEditMode ? 'updating' : 'adding'} user`,
        description: formErrors?._root?.[0] || 'An unknown error occurred.',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <DialogHeader>
              <DialogTitle>{isEditMode ? `Edit ${user.email}` : 'Add new user'}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., John Doe" {...field} value={field.value ?? ''} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="user@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                    <Input type="password" {...field} value={field.value ?? ''}/>
                    </FormControl>
                    <FormDescription>
                        {isEditMode ? "Leave blank to keep the current password." : "Set a password for the new user."}
                    </FormDescription>
                    <FormMessage />
                </FormItem>
                )}
              />

              <Separator />
               <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Super Admin</FormLabel>
                        <FormDescription>
                            Grants access to the entire platform.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value === 'superadmin'}
                          onCheckedChange={(checked) => field.onChange(checked ? 'superadmin' : 'business_admin')}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
               {watchRole === 'business_admin' && (
                  <FormField
                    control={form.control}
                    name="assignedBusinesses"
                    render={() => (
                        <FormItem>
                            <div className="mb-4">
                                <FormLabel className="text-base">Assigned businesses</FormLabel>
                                <FormDescription>
                                    Select which businesses this user can access.
                                </FormDescription>
                            </div>
                            <ScrollArea className="h-48 rounded-md border">
                                <div className="p-4 space-y-2">
                                    {allBusinesses.length === 0 && <p className="text-sm text-center text-muted-foreground py-4">No businesses created yet.</p>}
                                    {allBusinesses.map((business) => (
                                        <FormField
                                            key={business.id}
                                            control={form.control}
                                            name="assignedBusinesses"
                                            render={({ field }) => {
                                                return (
                                                <FormItem
                                                    key={business.id}
                                                    className="flex flex-row items-start space-x-3 space-y-0"
                                                >
                                                    <FormControl>
                                                    <Checkbox
                                                        checked={field.value?.includes(business.id)}
                                                        onCheckedChange={(checked) => {
                                                        return checked
                                                            ? field.onChange([...(field.value || []), business.id])
                                                            : field.onChange(
                                                                field.value?.filter(
                                                                (value) => value !== business.id
                                                                )
                                                            )
                                                        }}
                                                    />
                                                    </FormControl>
                                                    <FormLabel className="font-normal">
                                                    {business.businessName}
                                                    </FormLabel>
                                                </FormItem>
                                                )
                                            }}
                                        />
                                    ))}
                                </div>
                            </ScrollArea>
                            <FormMessage />
                        </FormItem>
                    )}
                />
               )}

            </div>

            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancel</Button>
              </DialogClose>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isEditMode ? 'Save changes' : 'Add User'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}


'use client';

import * as React from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { MoreHorizontal, PlusCircle, Trash2 } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table.tsx';
import { Card, CardContent, CardHeader } from '@/components/ui/card.tsx';
import { Badge } from '@/components/ui/badge.tsx';
import { Button } from '@/components/ui/button.tsx';
import { type AdminUser, getUsers, deleteUser } from './actions.ts';
import { type Business } from '../businesses/actions.ts';
import { useToast } from '@/hooks/use-toast.ts';
import { UserFormDialog } from './user-form-dialog.tsx';
import { Skeleton } from '@/components/ui/skeleton.tsx';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu.tsx';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog.tsx';

interface UsersClientPageProps {
  initialUsers: AdminUser[];
  allBusinesses: Business[];
}

export function UsersClientPage({ initialUsers, allBusinesses }: UsersClientPageProps) {
    const [users, setUsers] = React.useState(initialUsers);
    const [loading, setLoading] = React.useState(true);
    const [selectedUser, setSelectedUser] = React.useState<AdminUser | null>(null);
    const [dialogOpen, setDialogOpen] = React.useState(false);
    const { toast } = useToast();

    React.useEffect(() => {
        setUsers(initialUsers);
        setLoading(false);
    }, [initialUsers]);

    const refreshUsers = async () => {
        setLoading(true);
        const fetchedUsers = await getUsers();
        setUsers(fetchedUsers);
        setLoading(false);
    };

    const handleEditUser = (user: AdminUser) => {
        setSelectedUser(user);
        setDialogOpen(true);
    };

    const handleAddUser = () => {
        setSelectedUser(null);
        setDialogOpen(true);
    };

    const handleDeleteUser = async (user: AdminUser) => {
        const result = await deleteUser(user.id);
         if (result.success) {
            toast({
                title: "User Deleted",
                description: `${user.email} has been deleted.`
            });
            refreshUsers();
        } else {
            toast({
                variant: 'destructive',
                title: "Error",
                description: result.error || "Failed to delete user."
            })
        }
    }

    const onFormSave = () => {
        setDialogOpen(false);
        refreshUsers();
    };

    const columns: ColumnDef<AdminUser>[] = [
    {
      accessorKey: "name",
      header: "User",
      cell: ({ row }) => (
          <div>
            <div className="font-medium">{row.original.name || 'N/A'}</div>
            <div className="text-sm text-muted-foreground">{row.original.email}</div>
          </div>
      ),
    },
    {
      accessorKey: "role",
      header: "Role",
       cell: ({ row }) => {
            const role = row.getValue("role");
            return <Badge variant={role === 'superadmin' ? 'default' : 'secondary'}>
                {role === 'superadmin' ? 'Super Admin' : 'Business Admin'}
            </Badge>
        },
    },
    {
        accessorKey: "assignedBusinesses",
        header: "Assigned Businesses",
        cell: ({ row }) => {
            const role = row.original.role;
            const assignedIds = row.original.assignedBusinesses || [];
            if (role === 'superadmin') {
                return <Badge>All Businesses</Badge>
            }
            if (assignedIds.length === 0) {
                return <span className="text-muted-foreground">None</span>
            }
            return <Badge variant="outline">{assignedIds.length} assigned</Badge>
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const user = row.original;
            return (
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditUser(user)}>Edit</DropdownMenuItem>
                         <DropdownMenuSeparator />
                         <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}>
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete User
                                </DropdownMenuItem>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This will permanently delete the user {user.email}. This action cannot be undone.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDeleteUser(user)} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                         </AlertDialog>
                    </DropdownMenuContent>
                </DropdownMenu>
            )
        },
    }
  ]

  const table = useReactTable({
    data: users,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-end">
             <Button onClick={handleAddUser}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add User
             </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
                <TableRow><TableCell colSpan={columns.length} className="h-24 text-center"><Skeleton className="h-10 w-full" /></TableCell></TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No users found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
      </CardContent>
      <UserFormDialog
        user={selectedUser}
        allBusinesses={allBusinesses}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSave={onFormSave}
      />
    </Card>
  );
}


import * as React from 'react';
import { getBusinesses } from './businesses/actions';
import { getBookingsAcrossBusinesses } from './bookings/actions';
import { getSmsUsage } from './reports/actions';
import { getGlobalSmsSettings } from './settings/actions';
import { getOrders } from './orders/actions';
import { DashboardClientPage } from './dashboard-client';

export default async function SuperAdminDashboard() {
  const [businesses, bookings, smsUsage, smsSettings, orders] = await Promise.all([
    getBusinesses(),
    getBookingsAcrossBusinesses(),
    getSmsUsage(),
    getGlobalSmsSettings(),
    getOrders(),
  ]);

  return (
    <DashboardClientPage
      businesses={businesses}
      bookings={bookings}
      smsUsage={smsUsage}
      smsSettings={smsSettings}
      orders={orders}
    />
  );
}

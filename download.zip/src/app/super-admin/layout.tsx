
import type { Metadata } from 'next';
import SuperAdminClientLayout from './client-layout';
import "../globals.css";
import { getGlobalSettings } from './settings/actions';
import { StaffScreenProviderWrapper } from './staff-screen-provider-wrapper';

export async function generateMetadata(): Promise<Metadata> {
  const globalSettings = await getGlobalSettings();
  const appName = globalSettings.general?.appName || 'Bestiller.com';
  const faviconUrl = globalSettings.general?.appFaviconUrl || '/favicon.ico';
 
  return {
    title: `Super Admin | ${appName}`,
    description: 'Super Admin Dashboard',
    icons: {
      icon: [faviconUrl],
    }
  }
}

export default async function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const globalSettings = await getGlobalSettings();

  return (
    <StaffScreenProviderWrapper>
      <SuperAdminClientLayout globalSettings={globalSettings.general || {}}>
        {children}
      </SuperAdminClientLayout>
    </StaffScreenProviderWrapper>
  );
}


import * as React from 'react';
import { OrdersClientPage } from './client-page.tsx';
import { getOrders } from './actions.ts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.tsx';
import { InvoicesClientPage } from '../invoices/client-page.tsx';
import { getInvoices } from '../invoices/actions.ts';
import { SubscriptionsClientPage } from '../subscriptions/client-page.tsx';
import { getSubscriptions } from '../subscriptions/actions.ts';
import { Button } from '@/components/ui/button.tsx';
import { PlusCircle } from 'lucide-react';
import { CreateOrderDialog } from './create-order-dialog.tsx';

export default async function SuperAdminOrdersPage() {
  const [orders, invoices, subscriptions] = await Promise.all([
    getOrders(),
    getInvoices(),
    getSubscriptions(),
  ]);

  return (
    <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Billing & Orders</h2>
          <p className="text-muted-foreground">
            View and manage all incoming customer orders and subscriptions.
          </p>
        </div>
        <CreateOrderDialog>
          <Button>
              <PlusCircle className="mr-2 h-4 w-4" /> Create Order
          </Button>
        </CreateOrderDialog>
      </div>
       <Tabs defaultValue="orders" className="space-y-4 pt-4">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
        </TabsList>
        <TabsContent value="orders" className="space-y-4">
            <OrdersClientPage initialOrders={orders} initialSubscriptions={subscriptions} />
        </TabsContent>
         <TabsContent value="invoices" className="space-y-4">
            <InvoicesClientPage initialInvoices={invoices} />
        </TabsContent>
        <TabsContent value="subscriptions" className="space-y-4">
            <SubscriptionsClientPage initialSubscriptions={subscriptions} />
        </TabsContent>
      </Tabs>
    </>
  );
}

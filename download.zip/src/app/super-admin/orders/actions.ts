
'use server';

import admin from '@/lib/firebase-admin';
import { revalidatePath } from 'next/cache';
import { createBusiness } from '../businesses/new/actions';
import { OrderFormData } from '@/app/order/schema';

export type Order = OrderFormData & {
    id: string;
    status: 'new' | 'in-progress' | 'completed' | 'cancelled';
    createdAt: string;
};

export async function getOrders(): Promise<Order[]> {
    try {
        const ordersRef = admin.database().ref('orders');
        const ordersQuery = ordersRef.orderByChild('createdAt');
        const snapshot = await ordersQuery.once('value');

        if (!snapshot.exists()) {
            return [];
        }

        const orders: Order[] = [];
        snapshot.forEach((childSnapshot) => {
            orders.push({ id: childSnapshot.key!, ...childSnapshot.val() });
        });
        
        return orders.reverse(); // Show newest first
    } catch (error) {
        console.error("Error fetching orders:", error);
        return [];
    }
}

export async function updateOrderStatus(orderId: string, status: Order['status']): Promise<{ success: boolean; error?: string }> {
    try {
        const orderRef = admin.database().ref(`orders/${orderId}`);
        await orderRef.update({ status });
        revalidatePath('/super-admin/orders');
        return { success: true };
    } catch (error) {
        console.error("Error updating order status:", error);
        return { success: false, error: 'Failed to update order status.' };
    }
}

export async function processOrderAndCreateBusiness(orderId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const orderRef = admin.database().ref(`orders/${orderId}`);
        const snapshot = await orderRef.once('value');

        if (!snapshot.exists()) {
            return { success: false, error: 'Order not found.' };
        }
        const orderData = snapshot.val();
        
        // This will create the business and redirect.
        // We will be redirected away from the orders page, which is acceptable UX for this action.
        await createBusiness({ businessName: orderData.legalCompanyName });

        // Update the order status to 'completed'
        await orderRef.update({ status: 'completed' });
        
        return { success: true };

    } catch (error) {
        console.error("Error creating business from order:", error);
        return { success: false, error: 'An unexpected error occurred.' };
    }
}

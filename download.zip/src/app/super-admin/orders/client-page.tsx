
'use client';

import * as React from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getSortedRowModel,
  SortingState,
} from "@tanstack/react-table"
import { ArrowUpDown, Building, CheckCircle, MoreHorizontal, Hourglass, XCircle, FilePlus, Loader2, Eye, FileText, Repeat, Send, Languages } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { type Order, updateOrderStatus, processOrderAndCreateBusiness, getOrders } from './actions';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { FormattedPrice } from '@/components/formatted-price';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { createInvoiceFromOrder, sendOrderConfirmationEmail } from '../invoices/actions';
import Link from 'next/link';
import { createSubscriptionFromOrder, type Subscription } from '../subscriptions/actions';

interface OrdersClientPageProps {
  initialOrders: Order[];
  initialSubscriptions: Subscription[];
}

const statusConfig: Record<Order['status'], { icon: React.ElementType, color: string }> = {
    'new': { icon: FilePlus, color: 'text-blue-500' },
    'in-progress': { icon: Hourglass, color: 'text-amber-500' },
    'completed': { icon: CheckCircle, color: 'text-green-600' },
    'cancelled': { icon: XCircle, color: 'text-red-500' },
}

export function OrdersClientPage({ initialOrders, initialSubscriptions }: OrdersClientPageProps) {
    const [orders, setOrders] = React.useState(initialOrders);
    const [subscriptions, setSubscriptions] = React.useState(initialSubscriptions);
    const [loading, setLoading] = React.useState(true);
    const [sorting, setSorting] = React.useState<SortingState>([{ id: 'createdAt', desc: true }]);
    const [actionLoading, setActionLoading] = React.useState<Record<string, boolean>>({});
    const [selectedOrder, setSelectedOrder] = React.useState<Order | null>(null);
    const [detailsOpen, setDetailsOpen] = React.useState(false);
    const { toast } = useToast();

    const refreshOrders = async () => {
        setLoading(true);
        const fetchedOrders = await getOrders();
        setOrders(fetchedOrders);
        setLoading(false);
    }

    React.useEffect(() => {
        setOrders(initialOrders);
        setSubscriptions(initialSubscriptions);
        setLoading(false);
    }, [initialOrders, initialSubscriptions]);
    
    const handleStatusChange = async (orderId: string, status: Order['status']) => {
        setActionLoading(prev => ({ ...prev, [orderId]: true }));
        const result = await updateOrderStatus(orderId, status);
        if (result.success) {
            refreshOrders();
            if(selectedOrder?.id === orderId) {
                setSelectedOrder(prev => prev ? {...prev, status} : null);
            }
            toast({ title: "Order Status Updated" });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
        setActionLoading(prev => ({ ...prev, [orderId]: false }));
    }
    
    const handleCreateBusiness = async (order: Order) => {
        setActionLoading(prev => ({ ...prev, [order.id]: true }));
        const result = await processOrderAndCreateBusiness(order.id);
         if (result.error) {
            toast({ variant: 'destructive', title: "Error", description: result.error });
            setActionLoading(prev => ({ ...prev, [order.id]: false }));
        }
        // On success, a redirect happens, so no need to update state here.
    }

    const handleCreateInvoice = async (order: Order) => {
        setActionLoading(prev => ({ ...prev, [order.id]: true }));
        const result = await createInvoiceFromOrder(order, true);
        if (result.success) {
            toast({ title: "Invoice Created", description: "A new invoice has been generated and emailed for this order." });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
        setActionLoading(prev => ({ ...prev, [order.id]: false }));
    }

    const handleSendConfirmation = async (order: Order) => {
        setActionLoading(prev => ({ ...prev, [`confirm_${order.id}`]: true }));
        const result = await sendOrderConfirmationEmail(order.id);
        if (result.success) {
            toast({ title: "Email Sent", description: "The order confirmation email has been sent." });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
        setActionLoading(prev => ({ ...prev, [`confirm_${order.id}`]: false }));
    }

    const handleCreateSubscription = async (order: Order) => {
        setActionLoading(prev => ({ ...prev, [order.id]: true }));
        const result = await createSubscriptionFromOrder(order);
        if (result.success) {
            toast({ title: "Subscription Created", description: "A new subscription has been created for this order." });
            setSubscriptions(prev => [...prev, { ...result.subscription!, id: result.subscriptionId! }]);
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
        setActionLoading(prev => ({ ...prev, [order.id]: false }));
    }
    
    const orderHasSubscription = (orderId: string) => {
        return subscriptions.some(sub => sub.orderId === orderId);
    }

    const columns: ColumnDef<Order>[] = [
    {
      accessorKey: "legalCompanyName",
      header: "Company Name",
      cell: ({ row }) => <div className="font-medium">{row.original.legalCompanyName}</div>,
    },
    {
      accessorKey: "customerName",
      header: "Contact Person",
      cell: ({ row }) => (
          <div>
            <div>{row.original.customerName}</div>
            <div className="text-sm text-muted-foreground">{row.original.email}</div>
          </div>
      ),
    },
    {
        accessorKey: "totalAmount",
        header: "Total Price",
        cell: ({ row }) => <FormattedPrice price={row.original.totalAmount} currency={row.original.currency} />,
    },
    {
        accessorKey: "createdAt",
        header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Order Date <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
        cell: ({ row }) => format(new Date(row.original.createdAt), 'LLL d, yyyy')
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status;
            const { icon: Icon, color } = statusConfig[status];
            return (
                <Badge variant="outline" className={color}>
                    <Icon className="mr-2 h-4 w-4"/>
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                </Badge>
            )
        }
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const order = row.original;
            return (
                 <Button variant="outline" size="sm" onClick={() => { setSelectedOrder(order); setDetailsOpen(true); }}>
                    <Eye className="mr-2 h-4 w-4" />
                    View Details
                </Button>
            )
        },
    }
  ]

  const table = useReactTable({
    data: orders,
    columns,
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    state: { sorting },
  });

  const languageLabels: Record<string, string> = {
    en: 'English',
    bs: 'Bosnian',
    da: 'Danish'
  };

  return (
    <>
    <Card>
      <CardHeader></CardHeader>
      <CardContent>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
                <TableRow><TableCell colSpan={columns.length} className="h-24 text-center"><Skeleton className="h-10 w-full" /></TableCell></TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No orders found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
      </CardContent>
    </Card>

     <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
                <DialogTitle>Order Details</DialogTitle>
                <DialogDescription>
                    Full details for the order from {selectedOrder?.legalCompanyName}.
                </DialogDescription>
            </DialogHeader>
            {selectedOrder && (
                <div className="max-h-[70vh] overflow-y-auto p-1 pr-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <h4 className="font-semibold text-lg">Customer Information</h4>
                            <div className="text-sm space-y-2">
                                <p><strong>Contact Name:</strong> {selectedOrder.customerName}</p>
                                <p><strong>Contact Email:</strong> {selectedOrder.email}</p>
                                <p><strong>Contact Phone:</strong> {selectedOrder.phone}</p>
                            </div>
                            <Separator />
                            <h4 className="font-semibold text-lg">Billing Details</h4>
                             <div className="text-sm space-y-2">
                                <p><strong>Legal Company Name:</strong> {selectedOrder.legalCompanyName}</p>
                                <p><strong>Address:</strong> {selectedOrder.address.street}, {selectedOrder.address.postalCode} {selectedOrder.address.city}, {selectedOrder.address.country}</p>
                                <p><strong>Accountant Email:</strong> {selectedOrder.accountantEmail || 'N/A'}</p>
                                <p><strong>Tax ID:</strong> {selectedOrder.taxId || 'N/A'}</p>
                                <div className="flex items-center gap-2"><strong>Language:</strong> <Badge variant="outline"><Languages className="mr-2 h-4 w-4"/> {languageLabels[selectedOrder.language] || 'N/A'}</Badge></div>
                            </div>
                        </div>
                         <div className="space-y-4">
                            <h4 className="font-semibold text-lg">Order Summary</h4>
                             <div className="text-sm space-y-2 border rounded-md p-4">
                                <p className="flex justify-between"><span>Calendars:</span> <strong>{selectedOrder.calendars}</strong></p>
                                <p className="flex justify-between"><span>Monthly Price:</span> <strong><FormattedPrice price={selectedOrder.monthlyPrice} currency={selectedOrder.currency} /></strong></p>
                                <p className="flex justify-between"><span>Setup Fee:</span> <strong><FormattedPrice price={selectedOrder.setupFee} currency={selectedOrder.currency} /></strong></p>
                                <p className="flex justify-between"><span>VAT ({selectedOrder.vatRate}%):</span> <strong><FormattedPrice price={selectedOrder.vatAmount} currency={selectedOrder.currency} /></strong></p>
                                 <Separator />
                                <p className="flex justify-between font-bold"><span>Total Due:</span> <span><FormattedPrice price={selectedOrder.totalAmount} currency={selectedOrder.currency} /></span></p>
                            </div>
                             <h4 className="font-semibold text-lg pt-4">Actions</h4>
                             <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                    <span className="font-medium">Status:</span>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="outline" disabled={actionLoading[selectedOrder.id]}>
                                                {actionLoading[selectedOrder.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <MoreHorizontal className="mr-2 h-4 w-4"/>}
                                                {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent>
                                            {Object.keys(statusConfig).map(status => (
                                                <DropdownMenuItem key={status} onSelect={() => handleStatusChange(selectedOrder!.id, status as Order['status'])}>
                                                    {status.charAt(0).toUpperCase() + status.slice(1)}
                                                </DropdownMenuItem>
                                            ))}
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>
                                <Button onClick={() => handleSendConfirmation(selectedOrder)} disabled={actionLoading[`confirm_${selectedOrder.id}`]}>
                                    {actionLoading[`confirm_${selectedOrder.id}`] ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Send className="mr-2 h-4 w-4"/>}
                                    Send Confirmation Email
                                </Button>
                                <Button onClick={() => handleCreateInvoice(selectedOrder)} disabled={actionLoading[selectedOrder.id]}>
                                    {actionLoading[selectedOrder.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <FileText className="mr-2 h-4 w-4"/>}
                                    Create Invoice
                                </Button>
                                <Button onClick={() => handleCreateSubscription(selectedOrder)} disabled={actionLoading[selectedOrder.id] || orderHasSubscription(selectedOrder.id)}>
                                    {actionLoading[selectedOrder.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Repeat className="mr-2 h-4 w-4"/>}
                                    {orderHasSubscription(selectedOrder.id) ? 'Subscription Exists' : 'Create Subscription'}
                                </Button>
                                 <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button disabled={selectedOrder.status === 'completed' || actionLoading[selectedOrder.id]}>
                                            {actionLoading[selectedOrder.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Building className="mr-2 h-4 w-4"/>}
                                            Create Business Account
                                        </Button>
                                    </AlertDialogTrigger>
                                     <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>Create business for "{selectedOrder.legalCompanyName}"?</AlertDialogTitle>
                                            <AlertDialogDescription>
                                                This will create a new business account and redirect you to its edit page. The order status will be marked as 'completed'.
                                            </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => handleCreateBusiness(selectedOrder)}>Create</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                             </div>
                        </div>
                    </div>
                </div>
            )}
            <DialogFooter className="pt-4">
                <DialogClose asChild>
                    <Button type="button" variant="outline">Close</Button>
                </DialogClose>
            </DialogFooter>
        </DialogContent>
     </Dialog>
    </>
  );
}

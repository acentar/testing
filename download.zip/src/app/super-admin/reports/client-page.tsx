
'use client';

import * as React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { OverallSmsUsage } from './actions';
import { MessageSquare, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Skeleton } from '@/components/ui/skeleton';

interface SmsUsageClientPageProps {
  initialUsage: OverallSmsUsage;
  initialSettings: {
    monthlySmsCapacity: number;
    [key: string]: any;
  };
}

function StatCard({ title, value, change, changeType }: { title: string, value: string, change: string, changeType: 'increase' | 'decrease' | 'same' }) {
    const Icon = changeType === 'increase' ? TrendingUp : changeType === 'decrease' ? TrendingDown : Minus;
    const colorClass = changeType === 'increase' ? 'text-red-500' : changeType === 'decrease' ? 'text-green-500' : 'text-muted-foreground';

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <p className={`text-xs ${colorClass} flex items-center`}>
                    <Icon className="h-4 w-4 mr-1" />
                    {change}
                </p>
            </CardContent>
        </Card>
    );
}

export function SmsUsageClientPage({ initialUsage, initialSettings }: SmsUsageClientPageProps) {
  const [usage, setUsage] = React.useState(initialUsage);
  const [settings, setSettings] = React.useState(initialSettings);
  const [loading, setLoading] = React.useState(false); // Can be used later for real-time updates

  const { system, byBusiness } = usage;
  const { monthlySmsCapacity } = settings;

  const currentMonthProgress = Math.min((system.currentMonth / monthlySmsCapacity) * 100, 100);
  const changeFromLastMonth = system.currentMonth - system.lastMonth;
  const changeType = changeFromLastMonth > 0 ? 'increase' : changeFromLastMonth < 0 ? 'decrease' : 'same';
  const changeText = `${Math.abs(changeFromLastMonth)} SMS ${changeFromLastMonth >= 0 ? 'more' : 'less'} than last month`;
  
  if (loading) {
    return <Skeleton className="h-96 w-full" />
  }

  return (
    <div className="space-y-6">
        <Card>
            <CardHeader>
                <div className='flex items-center gap-2'>
                    <MessageSquare className="h-5 w-5" />
                    <CardTitle>System-Wide SMS Usage</CardTitle>
                </div>
                <CardDescription>
                    Overview of SMS messages sent across the entire platform.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                     <StatCard
                        title="Current Month Usage"
                        value={`${system.currentMonth} / ${monthlySmsCapacity}`}
                        change={changeText}
                        changeType={changeType}
                    />
                    <StatCard
                        title="Last Month Usage"
                        value={String(system.lastMonth)}
                        change="Total for previous calendar month"
                        changeType="same"
                    />
                    <StatCard
                        title="All-Time Usage"
                        value={String(system.total)}
                        change="Total since system launch"
                        changeType="same"
                    />
                </div>
                <div>
                    <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-muted-foreground">Current Month Capacity Usage</span>
                        <span className="text-sm font-medium">{currentMonthProgress.toFixed(1)}%</span>
                    </div>
                    <Progress value={currentMonthProgress} className="h-3" />
                </div>
            </CardContent>
        </Card>
        
        <Card>
            <CardHeader>
                <CardTitle>SMS Usage by Business</CardTitle>
                <CardDescription>Breakdown of SMS messages sent by each business account.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Business Name</TableHead>
                                <TableHead className="text-right">Current Month</TableHead>
                                <TableHead className="text-right">Last Month</TableHead>
                                <TableHead className="text-right">Total Sent</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {byBusiness.length > 0 ? (
                                byBusiness.map(biz => (
                                    <TableRow key={biz.id}>
                                        <TableCell className="font-medium">{biz.name}</TableCell>
                                        <TableCell className="text-right font-mono">{biz.currentMonth}</TableCell>
                                        <TableCell className="text-right font-mono">{biz.lastMonth}</TableCell>
                                        <TableCell className="text-right font-mono font-semibold">{biz.total}</TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={4} className="h-24 text-center">
                                        No SMS usage data available.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    </div>
  );
}

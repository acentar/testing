
import { getGlobalSmsSettings } from "../settings/actions.ts";
import { getSmsUsage } from "./actions.ts";
import { SmsUsageClientPage } from "./client-page.tsx";

export default async function SuperAdminReportsPage() {
    const [smsUsage, smsSettings] = await Promise.all([
        getSmsUsage(),
        getGlobalSmsSettings()
    ]);
    
    return (
        <>
            <div className="flex items-center justify-between space-y-2">
                <div>
                    <h2 className="text-3xl font-bold tracking-tight">Reports</h2>
                    <p className="text-muted-foreground">
                        View platform-wide usage statistics.
                    </p>
                </div>
            </div>
            <div className="pt-4 space-y-8">
                <SmsUsageClientPage 
                    initialUsage={smsUsage} 
                    initialSettings={smsSettings} 
                />
            </div>
        </>
    );
}

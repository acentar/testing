
'use server';

import admin from '@/lib/firebase-admin';
import { startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { getBusinesses } from '../businesses/actions';

export type SmsUsageStats = {
    total: number;
    currentMonth: number;
    lastMonth: number;
};

export type BusinessSmsUsage = {
    id: string;
    name: string;
    total: number;
    currentMonth: number;
    lastMonth: number;
};

export type OverallSmsUsage = {
    system: SmsUsageStats;
    byBusiness: BusinessSmsUsage[];
};

export async function getSmsUsage(): Promise<OverallSmsUsage> {
    const now = new Date();
    const startOfCurrentMonth = startOfMonth(now);
    const endOfCurrentMonth = endOfMonth(now);
    const startOfLastMonth = startOfMonth(subMonths(now, 1));
    const endOfLastMonth = endOfMonth(subMonths(now, 1));

    try {
        const logsRef = admin.database().ref('sms_logs');
        const logsSnapshot = await logsRef.once('value');
        const allLogs: any[] = [];
        if (logsSnapshot.exists()) {
            logsSnapshot.forEach(child => {
                allLogs.push({ id: child.key!, ...child.val() });
            });
        }
        
        const businesses = await getBusinesses();
        const usageByBusiness: { [key: string]: BusinessSmsUsage } = {};

        businesses.forEach(b => {
            usageByBusiness[b.id] = {
                id: b.id,
                name: b.businessName,
                total: 0,
                currentMonth: 0,
                lastMonth: 0,
            };
        });
        
        let systemCurrentMonth = 0;
        let systemLastMonth = 0;

        for (const log of allLogs) {
            if (log.status !== 'sent') continue;

            const businessId = log.businessId;
            if (usageByBusiness[businessId]) {
                usageByBusiness[businessId].total++;
            }
            
            const logDate = new Date(log.timestamp);
            if (logDate >= startOfCurrentMonth && logDate <= endOfCurrentMonth) {
                if (usageByBusiness[businessId]) usageByBusiness[businessId].currentMonth++;
                systemCurrentMonth++;
            } else if (logDate >= startOfLastMonth && logDate <= endOfLastMonth) {
                if (usageByBusiness[businessId]) usageByBusiness[businessId].lastMonth++;
                systemLastMonth++;
            }
        }

        return {
            system: {
                total: allLogs.filter(l => l.status === 'sent').length,
                currentMonth: systemCurrentMonth,
                lastMonth: systemLastMonth,
            },
            byBusiness: Object.values(usageByBusiness).sort((a,b) => b.total - a.total),
        };

    } catch (error) {
        console.error("Error fetching SMS usage:", error);
        return {
            system: { total: 0, currentMonth: 0, lastMonth: 0 },
            byBusiness: [],
        };
    }
}

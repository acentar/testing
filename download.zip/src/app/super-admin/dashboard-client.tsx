
'use client';

import * as React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, Building2, Users, ShoppingCart, MessageSquare } from 'lucide-react';
import Link from 'next/link';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { type Business } from './businesses/actions';
import { type AggregatedBooking } from './bookings/actions';
import { type OverallSmsUsage } from './reports/actions';
import { Progress } from '@/components/ui/progress';
import { ActiveUsersWidget } from './active-users-widget';
import { type Order } from './orders/actions';
import { startOfWeek, endOfWeek, parseISO } from 'date-fns';
import { useAuth } from './auth/provider';

interface DashboardClientPageProps {
  businesses: Business[];
  bookings: AggregatedBooking[];
  smsUsage: OverallSmsUsage;
  smsSettings: any;
  orders: Order[];
}

export function DashboardClientPage({ businesses, bookings, smsUsage, smsSettings, orders }: DashboardClientPageProps) {
  const { user, adminUser } = useAuth();
  
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };
  
  const getUserName = () => {
    if (adminUser?.name) return adminUser.name;
    if (user?.email) return user.email.split('@')[0];
    return 'Admin';
  }

  const totalBusinesses = businesses.length;
  const totalBookings = bookings.length;
  const { system } = smsUsage;
  const monthlySmsCapacity = smsSettings?.monthlySmsCapacity || 0;
  
  const currentMonthProgress = monthlySmsCapacity > 0
    ? Math.min((system.currentMonth / monthlySmsCapacity) * 100, 100)
    : 0;

  const now = new Date();
  const start = startOfWeek(now, { weekStartsOn: 1 });
  const end = endOfWeek(now, { weekStartsOn: 1 });
  
  const newOrdersThisWeek = orders.filter(order => {
      const orderDate = typeof order.createdAt === 'string'
          ? parseISO(order.createdAt)
          : new Date(order.createdAt);
      return orderDate >= start && orderDate <= end;
  }).length;

  return (
    <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{getGreeting()}, {getUserName()}! 👋</h2>
        </div>
        <div className="flex items-center space-x-2">
          <Link href="/super-admin/businesses/new">
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" /> Add new business
            </Button>
          </Link>
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics" disabled>Analytics</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
           <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total businesses
                </CardTitle>
                <Building2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalBusinesses}</div>
                <p className="text-xs text-muted-foreground">
                  Currently active on the platform.
                </p>
              </CardContent>
            </Card>
             <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  New Orders This Week
                </CardTitle>
                <ShoppingCart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{newOrdersThisWeek}</div>
                <p className="text-xs text-muted-foreground">
                  New orders since Monday.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total bookings
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalBookings}</div>
                 <p className="text-xs text-muted-foreground">
                  All-time bookings across all businesses.
                </p>
              </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Monthly SMS Usage</CardTitle>
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{system.currentMonth} / {monthlySmsCapacity > 0 ? monthlySmsCapacity : '∞'}</div>
                    <p className="text-xs text-muted-foreground">
                        {currentMonthProgress.toFixed(1)}% of monthly capacity used.
                    </p>
                    <Progress value={currentMonthProgress} className="h-2 mt-2" />
                </CardContent>
             </Card>
          </div>
          <ActiveUsersWidget />
        </TabsContent>
         <TabsContent value="analytics" className="space-y-4">
          <p>Analytics coming soon.</p>
        </TabsContent>
      </Tabs>
    </>
  );
}

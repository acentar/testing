import * as React from 'react';
import LoginPageClient from './client-page';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: "Sign in to super admin",
};

export default function LoginPage() {
    return <LoginPageClient />;
}

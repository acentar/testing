
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { signInWithEmailAndPassword as firebaseSignIn } from 'firebase/auth';
import { getAuth } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { app } from '@/lib/firebase';
import { getGlobalSettings } from '../settings/actions';
import { signInWithEmailAndPassword } from '../auth/actions';

const auth = getAuth(app);

const loginSchema = z.object({
  email: z.string().email('Please enter a valid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function LoginPageClient() {
  const router = useRouter();
  const { toast } = useToast();
  const [globalSettings, setGlobalSettings] = React.useState<any>({});
  const [loadingSettings, setLoadingSettings] = React.useState(true);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const { isSubmitting } = form.formState;

  React.useEffect(() => {
    async function fetchSettings() {
      setLoadingSettings(true);
      const settings = await getGlobalSettings();
      setGlobalSettings(settings.general || {});
      setLoadingSettings(false);
    }
    fetchSettings();
  }, []);

  const onSubmit = async (data: LoginFormData) => {
    try {
      const userCredential = await firebaseSignIn(auth, data.email, data.password);
      const idToken = await userCredential.user.getIdToken();
      
      const response = await fetch('/api/auth/session/sign-in', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken }),
      });

      if (response.ok) {
          toast({ title: 'Sign-in successful!' });
          router.push('/super-admin');
      } else {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Session creation failed.');
      }
    } catch (error: any) {
      console.error(error);
      const errorCode = error.code;
      let errorMessage = 'Sign-in failed. Please check your credentials and try again.';
      if (errorCode === 'auth/user-not-found' || errorCode === 'auth/wrong-password' || errorCode === 'auth/invalid-credential') {
        errorMessage = 'Invalid email or password.';
      }
      toast({
        variant: 'destructive',
        title: 'Sign-in Failed',
        description: errorMessage,
      });
    }
  };
  
  const appName = globalSettings.appName || 'Bestiller.com';
  const appLogoUrl = globalSettings.adminLogoUrl || globalSettings.appLogoUrl;

  return (
    <div className="w-full min-h-screen bg-white lg:grid lg:grid-cols-2">
      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="mx-auto grid w-full max-w-sm gap-6">
          <div className="grid gap-2 text-center">
            {loadingSettings ? (
              <div className="h-12 w-48 bg-gray-200 animate-pulse rounded-md mx-auto mb-4" />
            ) : (
              <Link href="/" className="mb-4 inline-block relative h-12 w-60 mx-auto">
                {appLogoUrl ? (
                  <Image src={appLogoUrl} alt={`${appName} logo`} fill className="object-contain" priority unoptimized />
                ) : (
                  <h1 className="text-3xl font-bold">{appName}</h1>
                )}
              </Link>
            )}
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4">
                <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                        <Input type="email" placeholder="admin@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                    <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                    </FormItem>
                    )}
                />
                <Button type="submit" className="w-full mt-2" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Sign in
                </Button>
            </form>
          </Form>
        </div>
      </div>
      <div className="hidden bg-muted lg:block">
        <Image
          src="https://picsum.photos/seed/login/1200/1800"
          alt="Abstract decorative image"
          fill
          className="h-screen w-full object-cover"
          data-ai-hint="office building abstract"
          priority
        />
      </div>
    </div>
  );
}


import { MediaLibraryClient } from './client-page';

export default function MediaPage() {
  return (
    <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Media Library</h2>
          <p className="text-muted-foreground">
            Manage all uploaded images for your platform.
          </p>
        </div>
      </div>
      <div className="pt-4">
        <MediaLibraryClient />
      </div>
    </>
  );
}

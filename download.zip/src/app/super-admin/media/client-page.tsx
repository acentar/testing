
'use client';

import * as React from 'react';
import { getMedia, deleteMedia, uploadMedia, type MediaItem } from './actions';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ImageUp, Trash2, Copy, Check, Info, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';
import Image from 'next/image';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function MediaLibraryClient() {
  const [mediaItems, setMediaItems] = React.useState<MediaItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [selectedMedia, setSelectedMedia] = React.useState<MediaItem | null>(null);
  const [uploading, setUploading] = React.useState(false);
  const [copiedId, setCopiedId] = React.useState(false);
  const [copiedUrl, setCopiedUrl] = React.useState(false);
  const { toast } = useToast();
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const loadMedia = React.useCallback(async () => {
    setLoading(true);
    const items = await getMedia();
    setMediaItems(items);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    loadMedia();
  }, [loadMedia]);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    
    const formData = new FormData();
    Array.from(files).forEach(file => {
      formData.append('files', file);
    });

    try {
      await uploadMedia(formData);
      toast({ title: 'Upload complete!', description: `${files.length} image(s) have been added to the library.` });
      loadMedia();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Upload failed', description: 'Could not upload images. Please try again.' });
    } finally {
      setUploading(false);
      if(fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDelete = async (mediaId: string, url: string) => {
    const result = await deleteMedia(mediaId, url);
    if (result.success) {
      toast({ title: 'Image deleted' });
      setMediaItems(prev => prev.filter(item => item.id !== mediaId));
      setSelectedMedia(null);
    } else {
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to delete image.' });
    }
  };
  
  const copyToClipboard = (text: string, type: 'id' | 'url') => {
    navigator.clipboard.writeText(text);
    if(type === 'id') {
        setCopiedId(true);
        setTimeout(() => setCopiedId(false), 2000);
    } else {
        setCopiedUrl(true);
        setTimeout(() => setCopiedUrl(false), 2000);
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-end mb-4">
          <Button onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ImageUp className="mr-2 h-4 w-4" />}
            {uploading ? 'Uploading...' : 'Upload New Media'}
          </Button>
          <Input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileChange}
            multiple
            accept="image/png, image/jpeg, image/gif, image/webp"
          />
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <Skeleton key={i} className="aspect-square rounded-md" />
            ))}
          </div>
        ) : mediaItems.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground border rounded-lg">
             <p className="font-semibold">No media found.</p>
             <p className="text-sm">Upload your first image to get started.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {mediaItems.map(item => (
              <div
                key={item.id}
                className="aspect-square rounded-md overflow-hidden relative group cursor-pointer"
                onClick={() => setSelectedMedia(item)}
              >
                <Image src={item.url} alt={item.fileName} layout="fill" objectFit="cover" className="transition-transform group-hover:scale-105" />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
              </div>
            ))}
          </div>
        )}

        <Dialog open={!!selectedMedia} onOpenChange={(open) => !open && setSelectedMedia(null)}>
          <DialogContent className="sm:max-w-3xl">
            {selectedMedia && (
              <>
                <DialogHeader>
                  <DialogTitle>Media Details</DialogTitle>
                </DialogHeader>
                <div className="grid md:grid-cols-2 gap-6 py-4">
                  <div className="relative aspect-video rounded-md overflow-hidden">
                     <Image src={selectedMedia.url} alt={selectedMedia.fileName} layout="fill" objectFit="contain" />
                  </div>
                  <div className="space-y-4">
                    <div>
                        <Label htmlFor="fileName">File Name</Label>
                        <p id="fileName" className="text-sm text-muted-foreground">{selectedMedia.fileName}</p>
                    </div>
                     <div>
                        <Label htmlFor="uploadedAt">Uploaded On</Label>
                        <p id="uploadedAt" className="text-sm text-muted-foreground">{format(new Date(selectedMedia.createdAt), 'PPP p')}</p>
                    </div>
                    <div>
                        <Label htmlFor="fileUrl">File URL</Label>
                        <div className="flex items-center gap-2">
                            <Input id="fileUrl" readOnly value={selectedMedia.url} className="text-xs" />
                            <Button size="icon" variant="outline" onClick={() => copyToClipboard(selectedMedia.url, 'url')}>
                               {copiedUrl ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                            </Button>
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="mediaId">Unique ID</Label>
                         <div className="flex items-center gap-2">
                            <Input id="mediaId" readOnly value={selectedMedia.id} className="text-xs font-mono" />
                             <Button size="icon" variant="outline" onClick={() => copyToClipboard(selectedMedia.id, 'id')}>
                               {copiedId ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                            </Button>
                        </div>
                    </div>
                  </div>
                </div>
                <DialogFooter className="sm:justify-between">
                     <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive">
                                <Trash2 className="mr-2 h-4 w-4" /> Delete Permanently
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the image from your storage. Any part of your application referencing this URL will break.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(selectedMedia.id, selectedMedia.url)} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                                    Delete Image
                                </AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                     </AlertDialog>
                  <DialogClose asChild>
                    <Button variant="outline">Close</Button>
                  </DialogClose>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}

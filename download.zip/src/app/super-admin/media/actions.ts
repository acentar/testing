
'use server';

import admin from '@/lib/firebase-admin';
import { storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { revalidatePath } from 'next/cache';
import sharp from 'sharp';

export interface MediaItem {
  id: string;
  fileName: string;
  url: string;
  createdAt: string;
  size: number;
  contentType: string;
}

async function streamToBuffer(stream: ReadableStream<Uint8Array>): Promise<Buffer> {
    const reader = stream.getReader();
    const chunks: Uint8Array[] = [];
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
    }
    return Buffer.concat(chunks);
}

export async function getMedia(): Promise<MediaItem[]> {
  try {
    const mediaRef = admin.database().ref('media');
    const snapshot = await mediaRef.orderByChild('createdAt').once('value');
    if (!snapshot.exists()) {
      return [];
    }
    const mediaData = snapshot.val();
    const items: MediaItem[] = Object.keys(mediaData).map(key => ({
      id: key,
      ...mediaData[key],
    }));
    return items.reverse();
  } catch (error) {
    console.error("Error fetching media:", error);
    return [];
  }
}

export async function uploadMedia(formData: FormData) {
  const db = admin.database();
  const mediaRef = db.ref('media');
  const files = formData.getAll('files') as File[];

  const uploadPromises = files.map(async (file) => {
    const fileBuffer = await streamToBuffer(file.stream() as any);
    const webpBuffer = await sharp(fileBuffer).webp({ quality: 80 }).toBuffer();
    const uniqueFileName = `${Date.now()}_${file.name.split('.')[0]}.webp`;
    const filePath = `media/${uniqueFileName}`;
    const fileStorageRef = storageRef(storage, filePath);

    await uploadBytes(fileStorageRef, webpBuffer, { contentType: 'image/webp' });
    const downloadURL = await getDownloadURL(fileStorageRef);
    
    const newMediaRef = mediaRef.push();
    await newMediaRef.set({
      fileName: uniqueFileName,
      url: downloadURL,
      createdAt: admin.database.ServerValue.TIMESTAMP,
      size: webpBuffer.length,
      contentType: 'image/webp',
    });
  });

  await Promise.all(uploadPromises);
  revalidatePath('/super-admin/media');
}


export async function deleteMedia(mediaId: string, fileUrl: string): Promise<{ success: boolean }> {
  try {
    // Delete from Storage
    const fileRef = storageRef(storage, fileUrl);
    await deleteObject(fileRef);

    // Delete from Realtime Database
    const dbRef = admin.database().ref(`media/${mediaId}`);
    await dbRef.remove();
    
    revalidatePath('/super-admin/media');
    return { success: true };
  } catch (error: any) {
    if (error.code === 'storage/object-not-found') {
        console.warn(`Object not found in storage, deleting from database anyway: ${fileUrl}`);
        const dbRef = admin.database().ref(`media/${mediaId}`);
        await dbRef.remove();
        revalidatePath('/super-admin/media');
        return { success: true };
    }
    console.error("Error deleting media:", error);
    return { success: false };
  }
}

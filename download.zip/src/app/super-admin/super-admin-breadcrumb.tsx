'use client';

import React, { useEffect, useState } from 'react';
import { usePathname, useParams } from 'next/navigation';
import Link from 'next/link';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import { getBusiness } from './businesses/actions';

const formatSegment = (segment: string) => {
  if (!segment) return '';
  return segment
    .replace(/-/g, ' ')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

export function SuperAdminBreadcrumb() {
  const pathname = usePathname();
  const params = useParams();
  const [businessName, setBusinessName] = useState('');

  const segments = pathname.split('/').filter(Boolean);

  useEffect(() => {
    const fetchBusinessName = async () => {
      const businessId = params.id as string;
      if (businessId && segments.includes(businessId)) {
        const business = await getBusiness(businessId);
        if (business) {
          setBusinessName(business.businessName);
        }
      }
    };
    if (params.id) {
        fetchBusinessName();
    }
  }, [params, segments]);
  
  if (segments.length <= 1) {
    return null;
  }

  return (
    <Breadcrumb className="hidden md:flex mb-4">
      <BreadcrumbList>
        {segments.map((segment, index) => {
          const href = '/' + segments.slice(0, index + 1).join('/');
          const isLast = index === segments.length - 1;
          let label = formatSegment(segment);
          
          if (segment === 'super-admin' && index === 0) {
              label = 'Dashboard';
          }
          if (params.id && segment === params.id) {
            label = businessName || '...';
          }

          return (
            <React.Fragment key={href}>
              {index > 0 && <BreadcrumbSeparator />}
              <BreadcrumbItem>
                {isLast ? (
                  <BreadcrumbPage>{label}</BreadcrumbPage>
                ) : (
                  <BreadcrumbLink asChild>
                    <Link href={href}>{label}</Link>
                  </BreadcrumbLink>
                )}
              </BreadcrumbItem>
            </React.Fragment>
          );
        })}
      </BreadcrumbList>
    </Breadcrumb>
  );
}

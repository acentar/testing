
'use server';

import { rtdb } from '@/lib/firebase';
import { ref, get, query, orderByChild, equalTo } from 'firebase/database';
import { getBusiness } from '../businesses/actions';

export type AggregatedCustomer = {
    id: string; // combination of businessId and customerId
    businessId: string;
    businessName: string;
    customerId: string;
    name: string;
    phone: string;
    totalBookings: number;
    completedBookings: number;
    cancelledBookings: number;
};

export async function getCustomersAcrossBusinesses(): Promise<AggregatedCustomer[]> {
  try {
    const businessesRef = ref(rtdb, 'businesses');
    const businessesSnapshot = await get(businessesRef);

    if (!businessesSnapshot.exists()) {
      return [];
    }
    
    const schedulesRef = ref(rtdb, 'schedules');
    const schedulesSnapshot = await get(schedulesRef);
    const allSchedules = schedulesSnapshot.exists() ? schedulesSnapshot.val() : {};

    const allCustomers: AggregatedCustomer[] = [];
    const businessesData = businessesSnapshot.val();

    for (const businessId in businessesData) {
      const business = businessesData[businessId];
      const customers = business.customers || {};
      const businessSchedules = allSchedules[businessId] || {};

      const bookingsByCustomer: { [key: string]: any[] } = {};

      for (const staffId in businessSchedules) {
        const staffSchedule = businessSchedules[staffId];
        Object.values(staffSchedule).forEach((booking: any) => {
          if (booking.type === 'booking' && booking.customerId) {
            if (!bookingsByCustomer[booking.customerId]) {
              bookingsByCustomer[booking.customerId] = [];
            }
            bookingsByCustomer[booking.customerId].push(booking);
          }
        });
      }
      
      for (const customerId in customers) {
        const customer = customers[customerId];
        const customerBookings = bookingsByCustomer[customerId] || [];
        
        allCustomers.push({
          id: `${businessId}-${customerId}`,
          businessId,
          businessName: business.businessName,
          customerId,
          name: customer.name || 'N/A',
          phone: customer.phone,
          totalBookings: customerBookings.length,
          completedBookings: customerBookings.filter(b => b.status === 'completed').length,
          cancelledBookings: customerBookings.filter(b => b.status === 'cancelled').length,
        });
      }
    }

    return allCustomers.sort((a, b) => a.name.localeCompare(b.name));
  } catch (error) {
    console.error("Error fetching customers across businesses:", error);
    return [];
  }
}


import * as React from 'react';
import { getCustomersAcrossBusinesses } from './actions.ts';
import { CustomerClientPage } from './client-page.tsx';

export default async function SuperAdminCustomersPage() {
  const customers = await getCustomersAcrossBusinesses();

  return (
     <>
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Customer directory</h2>
          <p className="text-muted-foreground">
            View and manage all customers across the platform.
          </p>
        </div>
      </div>
      <CustomerClientPage customers={customers} />
    </>
  );
}

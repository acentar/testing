
'use client';

import * as React from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getSortedRowModel,
  SortingState,
} from "@tanstack/react-table"
import { ArrowUpDown, CheckCircle, MoreHorizontal, Hourglass, XCircle, FileText, Trash2, PlayCircle, PauseCircle } from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { type Subscription, updateSubscriptionStatus, getSubscriptions, deleteSubscription } from './actions';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { FormattedPrice } from '@/components/formatted-price';
import Link from 'next/link';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';


interface SubscriptionsClientPageProps {
  initialSubscriptions: Subscription[];
}

const statusConfig: Record<Subscription['status'], { icon: React.ElementType, color: string }> = {
    'active': { icon: PlayCircle, color: 'text-green-600' },
    'paused': { icon: PauseCircle, color: 'text-amber-500' },
    'cancelled': { icon: XCircle, color: 'text-red-500' },
    'trial': { icon: Hourglass, color: 'text-blue-500' },
}

export function SubscriptionsClientPage({ initialSubscriptions }: SubscriptionsClientPageProps) {
    const [subscriptions, setSubscriptions] = React.useState(initialSubscriptions);
    const [loading, setLoading] = React.useState(true);
    const [sorting, setSorting] = React.useState<SortingState>([{ id: 'startDate', desc: true }]);
    const { toast } = useToast();

    const refreshSubscriptions = React.useCallback(async () => {
        setLoading(true);
        const fetchedSubscriptions = await getSubscriptions();
        setSubscriptions(fetchedSubscriptions);
        setLoading(false);
    }, []);

    React.useEffect(() => {
        setSubscriptions(initialSubscriptions);
        setLoading(false);
    }, [initialSubscriptions]);
    
    const handleStatusChange = async (subscriptionId: string, status: Subscription['status']) => {
        const result = await updateSubscriptionStatus(subscriptionId, status);
        if (result.success) {
            refreshSubscriptions();
            toast({ title: "Subscription Status Updated" });
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
    }
    
    const handleDeleteSubscription = async (subscriptionId: string) => {
        const result = await deleteSubscription(subscriptionId);
        if (result.success) {
            toast({ title: "Subscription Deleted" });
            refreshSubscriptions();
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.error });
        }
    }
    
    const columns: ColumnDef<Subscription>[] = [
    {
      accessorKey: "customerName",
      header: "Customer",
      cell: ({ row }) => <div className="font-medium">{row.original.customerName || 'N/A'}</div>,
    },
    {
        accessorKey: "monthlyPrice",
        header: "Monthly Price",
        cell: ({ row }) => <FormattedPrice price={row.original.monthlyPrice} currency={row.original.currency} />,
    },
    {
        accessorKey: "startDate",
        header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Start Date <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
        cell: ({ row }) => format(new Date(row.original.startDate), 'LLL d, yyyy')
    },
    {
        accessorKey: "nextBillingDate",
        header: "Next Billing",
        cell: ({ row }) => format(new Date(row.original.nextBillingDate), 'LLL d, yyyy'),
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status;
            const { icon: Icon, color } = statusConfig[status];
            return (
                <Badge variant="outline" className={color}>
                    <Icon className="mr-2 h-4 w-4"/>
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                </Badge>
            )
        }
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const subscription = row.original;
            return (
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem asChild>
                             <Link href={`/super-admin/orders?orderId=${subscription.orderId}`}>View Order</Link>
                        </DropdownMenuItem>
                        <DropdownMenuSub>
                            <DropdownMenuSubTrigger>Change status</DropdownMenuSubTrigger>
                            <DropdownMenuSubContent>
                                <DropdownMenuItem onClick={() => handleStatusChange(subscription.id, 'active')}>Active</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleStatusChange(subscription.id, 'paused')}>Paused</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleStatusChange(subscription.id, 'cancelled')}>Cancelled</DropdownMenuItem>
                            </DropdownMenuSubContent>
                        </DropdownMenuSub>
                        <DropdownMenuSeparator />
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <DropdownMenuItem className="text-red-500" onSelect={(e) => e.preventDefault()}>
                                    <Trash2 className="mr-2 h-4 w-4" /> Delete Subscription
                                </DropdownMenuItem>
                            </AlertDialogTrigger>
                             <AlertDialogContent>
                                <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This will permanently delete the subscription for {subscription.customerName}. This action cannot be undone.
                                </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteSubscription(subscription.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                 </DropdownMenu>
            )
        },
    }
  ]

  const table = useReactTable({
    data: subscriptions,
    columns,
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    state: { sorting },
  });

  return (
    <Card>
        <CardHeader>
            <CardTitle>Subscription Management</CardTitle>
            <CardDescription>
                View and manage all active, paused, and cancelled subscriptions.
            </CardDescription>
        </CardHeader>
      <CardContent>
        <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
                <TableRow><TableCell colSpan={columns.length} className="h-24 text-center"><Skeleton className="h-10 w-full" /></TableCell></TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No subscriptions found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        </div>
      </CardContent>
    </Card>
  );
}

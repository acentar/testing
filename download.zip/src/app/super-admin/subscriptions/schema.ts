
import { z } from 'zod';

export const subscriptionSchema = z.object({
  id: z.string(),
  orderId: z.string(),
  businessId: z.string().optional(),
  customerName: z.string().optional(),
  status: z.enum(['active', 'paused', 'cancelled', 'trial']),
  startDate: z.string().datetime(),
  nextBillingDate: z.string().datetime(),
  monthlyPrice: z.number(),
  currency: z.enum(['EUR', 'DKK', 'BAM']),
});

export type Subscription = z.infer<typeof subscriptionSchema>;

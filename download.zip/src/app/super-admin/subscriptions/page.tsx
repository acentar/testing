
import * as React from 'react';
import { getSubscriptions } from './actions';
import { SubscriptionsClientPage } from './client-page';

export default async function SuperAdminSubscriptionsPage() {
    const subscriptions = await getSubscriptions();
    return <SubscriptionsClientPage initialSubscriptions={subscriptions} />;
}

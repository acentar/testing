
'use server';

import admin from '@/lib/firebase-admin';
import { revalidatePath } from 'next/cache';
import type { Order } from '../orders/actions';
import { type Subscription, subscriptionSchema } from './schema';
import { add } from 'date-fns';

export async function getSubscriptions(): Promise<Subscription[]> {
  try {
    const subscriptionsRef = admin.database().ref('subscriptions');
    const snapshot = await subscriptionsRef.orderByChild('startDate').once('value');
    if (!snapshot.exists()) {
      return [];
    }
    const subscriptionsData = snapshot.val();
    const subscriptions: Subscription[] = Object.keys(subscriptionsData).map(key => ({
      id: key,
      ...subscriptionsData[key],
    }));
    return subscriptions.reverse();
  } catch (error) {
    console.error("Error fetching subscriptions:", error);
    return [];
  }
}

export async function createSubscriptionFromOrder(order: Order): Promise<{ success: boolean, subscription?: Subscription, subscriptionId?: string, error?: string }> {
    try {
        const subscriptionsRef = admin.database().ref('subscriptions');
        const existingSubQuery = subscriptionsRef.orderByChild('orderId').equalTo(order.id);
        const snapshot = await existingSubQuery.once('value');

        if (snapshot.exists()) {
            return { success: false, error: 'A subscription for this order already exists.' };
        }

        const startDate = new Date();
        const nextBillingDate = add(startDate, { months: 1 });
        
        const businessSnapshot = await admin.database().ref('businesses').orderByChild('businessName').equalTo(order.legalCompanyName).once('value');
        let businessId = '';
        if (businessSnapshot.exists()) {
            businessId = Object.keys(businessSnapshot.val())[0];
        }


        const newSubscriptionData: Omit<Subscription, 'id'> = {
            orderId: order.id,
            businessId: businessId,
            customerName: order.legalCompanyName,
            status: 'active',
            startDate: startDate.toISOString(),
            nextBillingDate: nextBillingDate.toISOString(),
            monthlyPrice: order.monthlyPrice,
            currency: order.currency,
        };

        const validation = subscriptionSchema.omit({ id: true }).safeParse(newSubscriptionData);
        if (!validation.success) {
            console.error("Subscription validation failed", validation.error);
            return { success: false, error: "Failed to validate subscription data."};
        }

        const newSubscriptionRef = await subscriptionsRef.push();
        const newSubscriptionId = newSubscriptionRef.key!;
        await newSubscriptionRef.set(validation.data);

        revalidatePath('/super-admin/orders');
        return { success: true, subscription: { id: newSubscriptionId, ...validation.data }, subscriptionId: newSubscriptionId };
    } catch (error) {
        console.error("Error creating subscription from order:", error);
        return { success: false, error: 'Failed to create subscription.' };
    }
}

export async function updateSubscriptionStatus(subscriptionId: string, status: Subscription['status']): Promise<{ success: boolean, error?: string }> {
    try {
        const subRef = admin.database().ref(`subscriptions/${subscriptionId}`);
        await subRef.update({ status });
        revalidatePath('/super-admin/orders');
        return { success: true };
    } catch (error) {
        console.error("Error updating subscription status:", error);
        return { success: false, error: "Failed to update status." };
    }
}

export async function deleteSubscription(subscriptionId: string): Promise<{ success: boolean; error?: string }> {
    try {
        const subRef = admin.database().ref(`subscriptions/${subscriptionId}`);
        await subRef.remove();
        revalidatePath('/super-admin/orders');
        return { success: true };
    } catch (error) {
        console.error("Error deleting subscription:", error);
        return { success: false, error: "Failed to delete subscription." };
    }
}


'use client';

import * as React from 'react';
import { onValue, ref } from 'firebase/database';
import { rtdb } from '@/lib/firebase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Smartphone, Building } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';

interface ActiveUser {
    id: string;
    name?: string;
    phone?: string;
    businessName: string;
    businessId: string;
    page: 'Booking Page (I3)' | 'Staff Kiosk (I2)';
    timestamp: string;
}

export function ActiveUsersWidget() {
    const [activeUsers, setActiveUsers] = React.useState<ActiveUser[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        const presenceRef = ref(rtdb, 'presence');
        const unsubscribe = onValue(presenceRef, (snapshot) => {
            const users: ActiveUser[] = [];
            if (snapshot.exists()) {
                snapshot.forEach(childSnapshot => {
                    users.push({ id: childSnapshot.key!, ...childSnapshot.val() });
                });
            }
            setActiveUsers(users);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    return (
        <Card>
            <CardHeader>
                <CardTitle>Real-Time Active Users</CardTitle>
                <CardDescription>
                    A live view of users currently interacting with the platform.
                </CardDescription>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="space-y-2">
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                ) : activeUsers.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">No active users right now.</p>
                ) : (
                    <ul className="space-y-3">
                        {activeUsers.map(user => (
                            <li key={user.id} className="flex items-center justify-between p-3 rounded-md border">
                                <div className="flex items-center gap-4">
                                     <div className="flex flex-col">
                                        <span className="font-semibold">{user.name || 'Staff Member'}</span>
                                        <span className="text-sm text-muted-foreground">{user.phone || 'Kiosk Mode'}</span>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <Badge variant={user.page.includes('I2') ? 'default' : 'secondary'}>{user.page}</Badge>
                                    <p className="text-xs text-muted-foreground mt-1">
                                        on <Link href={`/super-admin/businesses/${user.businessId}/edit/general`} className="hover:underline font-medium">{user.businessName}</Link>
                                    </p>
                                </div>
                            </li>
                        ))}
                    </ul>
                )}
            </CardContent>
        </Card>
    );
}


'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Input, type InputProps } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { Check, ChevronsUpDown } from 'lucide-react';

type Country = {
  value: 'DK' | 'BA';
  label: string;
  prefix: string;
  flag: string;
  length: number | number[];
};

const countries: Country[] = [
  { value: 'DK', label: 'Denmark', prefix: '+45', flag: '🇩🇰', length: 8 },
  { value: 'BA', label: 'Bosnia', prefix: '+387', flag: '🇧🇦', length: [8, 9] },
];

interface PhoneInputProps extends Omit<InputProps, 'onChange' | 'value' | 'maxLength'> {
  value?: string;
  onChange?: (value: string) => void;
  allowedCountries?: ('DK' | 'BA')[];
  defaultCountry?: 'DK' | 'BA';
}

export function PhoneInput({ value = '', onChange, allowedCountries = [], defaultCountry, ...props }: PhoneInputProps) {
  const [open, setOpen] = React.useState(false);

  const availableCountries = React.useMemo(() => {
    return allowedCountries.length > 0 
      ? countries.filter(c => allowedCountries.includes(c.value))
      : countries;
  }, [allowedCountries]);
  
  const detectCountryAndNumber = React.useCallback((phone: string) => {
    const foundCountry = availableCountries.find(c => phone.startsWith(c.prefix));
    if (foundCountry) {
      return { country: foundCountry, number: phone.substring(foundCountry.prefix.length) };
    }
    
    // Fallback to defaultCountry prop if provided
    if (defaultCountry) {
      const defaultC = availableCountries.find(c => c.value === defaultCountry);
      if (defaultC) {
        return { country: defaultC, number: phone };
      }
    }

    // Fallback to the first available country if no prefix matches
    const escapedPrefixes = countries.map(c => c.prefix.replace('+', '\\+')).join('|');
    return { country: availableCountries[0], number: phone.replace(new RegExp(`^(${escapedPrefixes})`), '') };
  }, [availableCountries, defaultCountry]);

  const [selectedCountry, setSelectedCountry] = React.useState<Country>(() => detectCountryAndNumber(value).country);
  const [nationalNumber, setNationalNumber] = React.useState<string>(() => detectCountryAndNumber(value).number);
  
  const handleCountrySelect = (countryValue: string) => {
    const country = availableCountries.find(c => c.value === countryValue);
    if (country) {
      setSelectedCountry(country);
      const newFullNumber = country.prefix + nationalNumber;
      onChange?.(newFullNumber);
    }
    setOpen(false);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let rawValue = e.target.value.replace(/\D/g, '');
    
    // If the current nationalNumber is empty and the user types '0', ignore it.
    if (nationalNumber === '' && rawValue === '0') {
      return;
    }
    
    setNationalNumber(rawValue);
    onChange?.(selectedCountry.prefix + rawValue);
  };

  React.useEffect(() => {
    const { country, number } = detectCountryAndNumber(value);
    setSelectedCountry(country);
    setNationalNumber(number);
  }, [value, detectCountryAndNumber]);
  
  const getMaxLength = () => {
    if (Array.isArray(selectedCountry.length)) {
      return Math.max(...selectedCountry.length);
    }
    return selectedCountry.length;
  }

  if (availableCountries.length === 0) {
    return <Input {...props} type="tel" value={value} onChange={(e) => onChange?.(e.target.value)} />
  }

  return (
    <div className="flex items-center">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="justify-center w-28 rounded-r-none"
            disabled={props.disabled || availableCountries.length <= 1}
          >
            <span className="mr-2">{selectedCountry.flag}</span>
            <span className="font-mono">{selectedCountry.prefix}</span>
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[250px] p-0">
          <Command>
            <CommandList>
              <CommandEmpty>No country found.</CommandEmpty>
              <CommandGroup>
                {availableCountries.map((country) => (
                  <CommandItem
                    key={country.value}
                    value={country.value}
                    onSelect={handleCountrySelect}
                  >
                    <Check
                      className={cn(
                        'mr-2 h-4 w-4',
                        selectedCountry.value === country.value ? 'opacity-100' : 'opacity-0'
                      )}
                    />
                    {country.flag} {country.label} ({country.prefix})
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      <Input
        {...props}
        type="tel"
        value={nationalNumber}
        onChange={handleInputChange}
        className="rounded-l-none"
        placeholder={selectedCountry.value === 'DK' ? 'e.g. 12345678' : 'e.g. 61234567'}
        autoComplete="tel-national"
        maxLength={getMaxLength()}
      />
    </div>
  );
}

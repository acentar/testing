
'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

interface InteractiveCanvasContextType {
    scale: number;
    setScale: React.Dispatch<React.SetStateAction<number>>;
    position: { x: number; y: number };
    setPosition: React.Dispatch<React.SetStateAction<{ x: number; y: number }>>;
}

const InteractiveCanvasContext = React.createContext<InteractiveCanvasContextType | null>(null);

export function useInteractiveCanvas() {
    const context = React.useContext(InteractiveCanvasContext);
    if (!context) {
        throw new Error('useInteractiveCanvas must be used within an InteractiveCanvas');
    }
    return context;
}


interface InteractiveCanvasProps extends React.HTMLAttributes<HTMLDivElement> {}

export function InteractiveCanvas({ className, children, ...props }: InteractiveCanvasProps) {
    const [scale, setScale] = React.useState(1);
    const [position, setPosition] = React.useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = React.useState(false);
    const [startDrag, setStartDrag] = React.useState({ x: 0, y: 0 });
    const containerRef = React.useRef<HTMLDivElement>(null);
    const contentRef = React.useRef<HTMLDivElement>(null);
    
    const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
        e.preventDefault();
        const scaleAmount = -e.deltaY * 0.001;
        setScale(prev => Math.max(0.2, prev + scaleAmount));
    };

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragging(true);
        setStartDrag({ x: e.clientX - position.x, y: e.clientY - position.y });
        if (containerRef.current) {
            containerRef.current.style.cursor = 'grabbing';
        }
    };
    
    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!isDragging) return;
        e.preventDefault();
        setPosition({
            x: e.clientX - startDrag.x,
            y: e.clientY - startDrag.y
        });
    };
    
    const handleMouseUp = (e: React.MouseEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragging(false);
        if (containerRef.current) {
            containerRef.current.style.cursor = 'grab';
        }
    };
    
    const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
        if(isDragging) {
            handleMouseUp(e);
        }
    }

    const contextValue = React.useMemo(() => ({
        scale,
        setScale,
        position,
        setPosition,
    }), [scale, position]);

    return (
        <InteractiveCanvasContext.Provider value={contextValue}>
            <div
                ref={containerRef}
                className={cn("relative w-full h-full overflow-hidden bg-slate-50 border rounded-lg cursor-grab", className)}
                onWheel={handleWheel}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseLeave}
                {...props}
            >
                <div
                    ref={contentRef}
                    style={{
                        transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
                        transition: isDragging ? 'none' : 'transform 0.1s ease-out',
                        transformOrigin: 'center center',
                    }}
                >
                    {children}
                </div>
            </div>
        </InteractiveCanvasContext.Provider>
    );
}


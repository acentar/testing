
'use client';

import * as React from 'react';

interface FormattedPriceProps {
  price: number;
  currency: 'DKK' | 'BAM' | 'EUR';
  className?: string;
}

export function FormattedPrice({ price, currency, className }: FormattedPriceProps) {
  const [isClient, setIsClient] = React.useState(false);

  React.useEffect(() => {
    // This runs only on the client, after the initial render.
    setIsClient(true);
  }, []);

  if (typeof price !== 'number') {
    return <span className={className}>N/A</span>;
  }
  
  if (!isClient) {
    // On the server, and on the initial client render, render a simple, non-locale-specific string.
    return <span className={className}>{price.toFixed(2)}</span>;
  }

  // Once the client has mounted, we can safely use locale-specific formatting.
  const locale = currency === 'DKK' ? 'da-DK' : currency === 'BAM' ? 'bs-BA' : 'en-GB';
  const formattedPrice = new Intl.NumberFormat(locale, { style: 'currency', currency }).format(price);

  return <span className={className}>{formattedPrice}</span>;
}


'use client';

import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '../ui/scroll-area';

interface TermsOfServiceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TermsOfServiceModal({ open, onOpenChange }: TermsOfServiceModalProps) {
  const [lastUpdated, setLastUpdated] = React.useState('');

    React.useEffect(() => {
        if (open) {
            setLastUpdated(new Date().toLocaleDateString());
        }
    }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Terms of Service</DialogTitle>
          <DialogDescription>
             Last updated: {lastUpdated}
          </DialogDescription>
        </DialogHeader>
         <ScrollArea className="h-96 pr-6">
            <div className="space-y-4 text-sm text-muted-foreground">
                 <p>
                    Please read these terms and conditions carefully before using Our Service.
                </p>
                <h3 className="font-semibold text-foreground pt-2">Acknowledgment</h3>
                <p>
                    These are the Terms and Conditions governing the use of this Service and
                    the agreement that operates between You and the Company. These Terms and
                    Conditions set out the rights and obligations of all users regarding the
                    use of the Service.
                </p>
                <p>
                    Your access to and use of the Service is conditioned on Your acceptance of
                    and compliance with these Terms and Conditions. These Terms and Conditions
                    apply to all visitors, users and others who access or use the Service.
                </p>
                <p>
                    By accessing or using the Service You agree to be bound by these Terms and
                    Conditions. If You disagree with any part of these Terms and Conditions
                    then You may not access the Service.
                </p>
                <p>
                    You represent that you are over the age of 18. The Company does not
                    permit those under 18 to use the Service.
                </p>
                <p>
                    Your access to and use of the Service is also conditioned on Your
                    acceptance of and compliance with the Privacy Policy of the Company. Our
                    Privacy Policy describes Our policies and procedures on the collection,
                    use and disclosure of Your personal information when You use the
                    Application or the Website and tells You about Your privacy rights and how
                    the law protects You. Please read Our Privacy Policy carefully before
                    using Our Service.
                </p>
                <h3 className="font-semibold text-foreground pt-2">Links to Other Websites</h3>
                <p>
                    Our Service may contain links to third-party web sites or services that
                    are not owned or controlled by the Company.
                </p>
                <p>
                    The Company has no control over, and assumes no responsibility for, the
                    content, privacy policies, or practices of any third party web sites or
                    services. You further acknowledge and agree that the Company shall not be
                    responsible or liable, directly or indirectly, for any damage or loss
                    caused or alleged to be caused by or in connection with the use of or
                    reliance on any such content, goods or services available on or through
                    any such web sites or services.
                </p>
                 <p>
                    We strongly advise You to read the terms and conditions and privacy
                    policies of any third-party web sites or services that You visit.
                </p>

            </div>
        </ScrollArea>
        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

    

'use client';

import * as React from 'react';
import { useAvailability } from '@/app/[id]/client-app/providers';
import { findNextAvailableDay } from '@/app/[id]/client-app/actions';
import { type Staff } from '@/app/super-admin/businesses/[id]/(edit-business)/staff/schema';
import { add, addDays, addHours, addMinutes, getDay, getHours, getMinutes, isAfter, isBefore, isSameDay, parse, startOfDay, startOfMonth, format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';

const dayMap = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

interface SchedulerProps {
    business: any;
    allStaff: Staff[];
    totalDuration: number;
    existingBookingId?: string | null;
}

export function useScheduler({ business, allStaff, totalDuration, existingBookingId }: SchedulerProps) {
    const { availabilityData, isLoading: isLoadingAvailability } = useAvailability([]);
    const [selectedDate, setSelectedDate] = React.useState<Date | undefined>(undefined);
    const [currentMonth, setCurrentMonth] = React.useState(startOfMonth(new Date()));
    const [isFindingDay, setIsFindingDay] = React.useState(false);
    const [noSlotsFound, setNoSlotsFound] = React.useState(false);
    
    React.useEffect(() => {
        let isMounted = true;
        if (!selectedDate && allStaff.length > 0 && totalDuration > 0) {
          setIsFindingDay(true);
          findNextAvailableDay(business.id, totalDuration, allStaff).then(nextDay => {
            if (isMounted) {
              if (nextDay) {
                const date = parse(nextDay, 'yyyy-MM-dd', new Date());
                setSelectedDate(date);
                setCurrentMonth(startOfMonth(date));
              } else {
                setNoSlotsFound(true);
              }
              setIsFindingDay(false);
            }
          });
        }
        return () => { isMounted = false; };
    }, [business.id, totalDuration, allStaff, selectedDate]);


    const availableSlots = React.useMemo(() => {
        if (!selectedDate || !availabilityData || totalDuration <= 0) return [];

        const timeZone = business.timezone || 'UTC';
        const nowInTz = toZonedTime(new Date(), timeZone);
        let minBookingDateTime = nowInTz;

        if (business.leadTimeValue && business.leadTimeUnit) {
            const leadTimeFunctions = {
                minutes: addMinutes,
                hours: addHours,
                days: addDays,
            };
            const addFn = leadTimeFunctions[business.leadTimeUnit] || addMinutes;
            minBookingDateTime = addFn(nowInTz, business.leadTimeValue);
        }
        
        const dayOfWeekName = dayMap[getDay(selectedDate)];
        
        const todaysEvents = availabilityData.filter(event => {
            const eventDate = (event as any).date || event.startDate;
            if (!eventDate) return false;
            return isSameDay(parse(eventDate, 'yyyy-MM-dd', new Date()), selectedDate);
        });
        
        const bookedIntervalsByStaff: Record<string, { start: number, end: number, isAllDay: boolean }[]> = {};

        for (const staff of allStaff) {
            bookedIntervalsByStaff[staff.id] = [];
            const staffEvents = todaysEvents.filter(e => e.staffId === staff.id);
            
            for (const event of staffEvents) {
                if (event.status === 'cancelled' || (existingBookingId && event.id === existingBookingId)) continue;
    
                if (event.type === 'booking') {
                    const [hours, minutes] = event.time.split(':').map(Number);
                    const start = hours * 60 + minutes;
                    const end = start + event.totalDuration;
                    bookedIntervalsByStaff[staff.id].push({ start, end, isAllDay: false });
                } else if (event.type === 'timeOff' || event.type === 'manual' || event.type === 'break') {
                     const [startH, startM] = event.startTime.split(':').map(Number);
                     const startMinutes = startH * 60 + startM;
                     const endMinutes = startMinutes + event.duration;
                     const isAllDay = !event.startTime || event.startTime === '00:00';
                     if (event.type === 'timeOff' && isAllDay) {
                         bookedIntervalsByStaff[staff.id].push({ start: 0, end: 1440, isAllDay: true });
                     } else {
                        bookedIntervalsByStaff[staff.id].push({ start: startMinutes, end: endMinutes, isAllDay: false });
                     }
                }
            }
        }

        const availableStaff = allStaff.filter(staff => {
            const dayAvailability = staff.availability.find(a => a.day === dayOfWeekName);
            return dayAvailability?.working && !bookedIntervalsByStaff[staff.id]?.some(b => b.isAllDay);
        });

        if (availableStaff.length === 0) return [];

        const combinedSlots: Record<string, string[]> = {};
        const slotInterval = 15;

        for (const staff of availableStaff) {
            const dayAvailability = staff.availability.find(a => a.day === dayOfWeekName)!;
            if (!dayAvailability.workFrom || !dayAvailability.workTo) continue;

            const workStart = parse(dayAvailability.workFrom, 'HH:mm', new Date());
            const workEnd = parse(dayAvailability.workTo, 'HH:mm', new Date());
            
            let currentTime = workStart;

            if (isSameDay(selectedDate, nowInTz) && isBefore(currentTime, minBookingDateTime)) {
                currentTime = minBookingDateTime;
                const currentMinutes = getMinutes(currentTime);
                const remainder = currentMinutes % slotInterval;
                if (remainder > 0) {
                    currentTime = addMinutes(currentTime, slotInterval - remainder);
                }
            }

            while (isBefore(currentTime, workEnd)) {
                const slotStart = currentTime;
                const slotEnd = add(slotStart, { minutes: totalDuration });

                if (isAfter(slotEnd, workEnd)) break;

                const slotStartMinutes = getHours(slotStart) * 60 + getMinutes(slotStart);
                const slotEndMinutes = slotStartMinutes + totalDuration;

                if (bookedIntervalsByStaff[staff.id]?.some(b => slotStartMinutes < b.end && slotEndMinutes > b.start)) {
                    currentTime = add(currentTime, { minutes: slotInterval });
                    continue;
                }
                
                const timeStr = format(slotStart, "HH:mm");
                if (!combinedSlots[timeStr]) {
                    combinedSlots[timeStr] = [];
                }
                combinedSlots[timeStr].push(staff.id);

                currentTime = add(currentTime, { minutes: slotInterval });
            }
        }
        
        return Object.entries(combinedSlots)
            .map(([time, staffIds]) => ({ time, staffIds }))
            .sort((a,b) => a.time.localeCompare(b.time));

    }, [selectedDate, totalDuration, allStaff, business, availabilityData, existingBookingId]);

    return {
        selectedDate,
        setSelectedDate,
        currentMonth,
        setCurrentMonth,
        availableSlots,
        isLoadingAvailability: isLoadingAvailability || isFindingDay,
        noSlotsFound,
    };
}

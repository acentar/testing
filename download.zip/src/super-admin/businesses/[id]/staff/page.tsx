
import * as React from 'react';
import { notFound } from "next/navigation";
import { StaffManagementClient } from './staff-management-client';
import { getServicesAndExtensions } from '@/app/[id]/client-app/actions';

export default async function StaffPage({ params }: { params: { id: string } }) {
    const { id: businessId } = params;
    const { services, extensions } = await getServicesAndExtensions(businessId);
    const allServices = services.concat(extensions as any);

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between space-y-2">
                <div>
                <h2 className="text-3xl font-bold tracking-tight">Staff Members</h2>
                <p className="text-muted-foreground">
                    Manage your team members, their schedules, and the services they provide.
                </p>
                </div>
            </div>
            <StaffManagementClient businessId={businessId} allServices={allServices} />
        </div>
    );
}

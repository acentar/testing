
import { NextResponse, type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const sessionCookie = request.cookies.get('firebase-auth-token')?.value;
  const staffSession = request.cookies.get('staff-session')?.value;

  // Allow unauthenticated access to specific pages and API routes
  const publicPaths = ['/super-admin/login', '/staff/login', '/auth/action'];
  if (publicPaths.some(p => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Handle super-admin routes
  if (pathname.startsWith('/super-admin') && !sessionCookie) {
    const url = request.nextUrl.clone();
    url.pathname = '/super-admin/login';
    return NextResponse.redirect(url);
  }

  // Handle staff kiosk routes
  if (pathname.includes('/staff-app')) {
    // Super-admins can always access staff apps
    if (sessionCookie) {
      return NextResponse.next();
    }
    
    // Check for a valid staff session
    const businessId = pathname.split('/')[1];
    if (!staffSession) {
      const url = request.nextUrl.clone();
      url.pathname = '/staff/login';
      url.search = `?redirect=/${businessId}/staff-app`;
      return NextResponse.redirect(url);
    }

    try {
      const sessionData = JSON.parse(atob(staffSession));
      if (sessionData.businessId !== businessId) {
        // Logged into the wrong business, redirect to login
        const url = request.nextUrl.clone();
        url.pathname = '/staff/login';
        url.search = `?error=invalid_business&redirect=/${businessId}/staff-app`;
        return NextResponse.redirect(url);
      }
    } catch (e) {
      // Invalid session cookie, redirect to login
      const url = request.nextUrl.clone();
      url.pathname = '/staff/login';
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/super-admin/:path*',
    '/:id/staff-app/:path*',
    '/staff/login/:path*',
    '/auth/action/:path*',
    '/:id/client-app/:path*'
  ],
};

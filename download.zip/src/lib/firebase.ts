// Import the functions you need from the SDKs you need
import { getApp, getApps, initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getStorage } from 'firebase/storage';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBzF6X5vr9M_D-CwzHJk5_8IOgAcqoz6EU",
  authDomain: "queuepilot-hmh2j.firebaseapp.com",
  databaseURL: "https://queuepilot-hmh2j-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "queuepilot-hmh2j",
  storageBucket: "queuepilot-hmh2j.firebasestorage.app",
  messagingSenderId: "219509279228",
  appId: "1:219509279228:web:a8fbec765b0b7334530a79"
};

// Initialize Firebase for client-side usage
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const rtdb = getDatabase(app);
const storage = getStorage(app);

export { app, rtdb, storage };

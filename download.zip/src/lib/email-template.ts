
import type { Invoice } from "@/app/super-admin/invoices/schema";
import { format as formatDate } from 'date-fns';
import { enUS, bs, da } from 'date-fns/locale';

interface EmailTemplateProps {
  title: string;
  body: string; // Can contain HTML for more complex layouts
  cta?: {
    text: string;
    link: string;
  };
  logoUrl?: string;
  invoice?: Invoice;
  appName?: string;
  language: 'en' | 'bs' | 'da';
}

const translations = {
    en: {
        invoice: 'Invoice',
        description: 'Description',
        total: 'Total',
        subtotal: 'Subtotal',
        vat: 'VAT',
        rightsReserved: 'All rights reserved.'
    },
    bs: {
        invoice: 'Faktura',
        description: 'Opis',
        total: 'Ukupno',
        subtotal: 'Međuzbir',
        vat: 'PDV',
        rightsReserved: 'Sva prava zadržana.'
    },
    da: {
        invoice: 'Faktura',
        description: 'Beskrivelse',
        total: 'Total',
        subtotal: 'Subtotal',
        vat: 'MOMS',
        rightsReserved: 'Alle rettigheder forbeholdes.'
    }
};

const mainBackgroundColor = '#f0f2f5';
const containerBackgroundColor = '#ffffff';
const primaryColor = '#0a0a0a';
const textColor = '#333333';
const mutedColor = '#777777';

function formatPrice(price: number, currency: string, lang: 'en' | 'bs' | 'da') {
    const locale = currency === 'DKK' ? 'da-DK' : currency === 'BAM' ? 'bs-BA' : 'en-GB';
    return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(price);
}

export function generateSystemEmailHtml({ title, body, cta, logoUrl, invoice, appName = 'QueuePilot', language = 'bs' }: EmailTemplateProps): string {
  
  const t = translations[language] || translations.bs;
  const subtotal = invoice ? invoice.lineItems.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0) : 0;
  const vatAmount = invoice ? invoice.amount - subtotal : 0;
  const locale = language === 'bs' ? bs : language === 'da' ? da : enUS;

  return `
<!DOCTYPE html>
<html lang="${language}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap');
        body {
            margin: 0;
            padding: 0;
            background-color: ${mainBackgroundColor};
            font-family: 'PT Sans', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        .email-container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            background-color: ${containerBackgroundColor};
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid #e5e7eb;
        }
        .header {
            text-align: center;
            padding: 24px;
            background-color: #f8f9fa;
        }
        .header img {
            max-height: 50px;
            width: auto;
        }
        .content {
            padding: 32px;
            color: ${textColor};
            font-size: 16px;
            line-height: 1.6;
        }
        .content h2 {
             color: ${primaryColor};
             font-size: 24px;
             font-weight: 700;
             margin-top: 0;
        }
        .content p {
            margin: 0 0 16px 0;
        }
        .cta-button {
            display: inline-block;
            margin: 20px 0;
            padding: 12px 24px;
            background-color: ${primaryColor};
            color: #ffffff !important;
            text-decoration: none;
            font-weight: bold;
            border-radius: 6px;
            text-align: center;
        }
        .footer {
            text-align: center;
            padding: 24px;
            font-size: 12px;
            color: ${mutedColor};
            background-color: #f8f9fa;
        }
        .footer a {
            color: ${primaryColor};
            text-decoration: none;
        }
        .invoice-box {
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-top: 24px;
            padding: 20px;
        }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .invoice-table th, .invoice-table td {
            text-align: left;
            padding: 8px 0;
            border-bottom: 1px solid #e5e7eb;
        }
         .invoice-table th {
            color: ${mutedColor};
            font-weight: normal;
            font-size: 14px;
        }
        .text-right {
            text-align: right;
        }
        .total-section {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 2px solid #e5e7eb;
            width: 50%;
            margin-left: auto;
        }
         .total-section p {
            display: flex;
            justify-content: space-between;
            margin: 8px 0;
        }
         .total-section p strong {
             font-weight: bold;
             color: ${primaryColor};
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            ${logoUrl ? `<img src="${logoUrl}" alt="Application Logo">` : `<h1>${appName}</h1>`}
        </div>
        <div class="content">
            <h2>${title}</h2>
            ${body}

            ${invoice ? `
                <div class="invoice-box">
                    <h3 style="margin-top: 0;">${t.invoice} #${invoice.id.substring(0, 7)}...</h3>
                    <p style="font-size: 14px; color: ${mutedColor};">${formatDate(new Date(invoice.createdAt), 'PPP', { locale })}</p>
                    <table class="invoice-table">
                        <thead>
                            <tr>
                                <th>${t.description}</th>
                                <th class="text-right">${t.total}</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${invoice.lineItems.map(item => `
                                <tr>
                                    <td>${item.description} (x${item.quantity})</td>
                                    <td class="text-right">${formatPrice(item.unitPrice * item.quantity, invoice.currency, language)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="total-section">
                        <p><span>${t.subtotal}</span> <span>${formatPrice(subtotal, invoice.currency, language)}</span></p>
                        <p><span>${t.vat}</span> <span>${formatPrice(vatAmount, invoice.currency, language)}</span></p>
                        <p><strong>${t.total}</strong> <strong>${formatPrice(invoice.amount, invoice.currency, language)}</strong></p>
                    </div>
                </div>
            ` : ''}

            ${cta ? `<a href="${cta.link}" class="cta-button" style="color: #ffffff;">${cta.text}</a>` : ''}
        </div>
        <div class="footer">
            &copy; ${new Date().getFullYear()} ${appName}. ${t.rightsReserved}
        </div>
    </div>
</body>
</html>
  `;
}
